# v9 Workers, Redis Cache, Persistence, and 1-Minute Ingestion

## What changed

- RSS, HTML, and sitemap sources are fetched concurrently with worker threads.
- Database writes remain sequential to avoid SQLite lock issues.
- Scheduler interval default is now 60 seconds.
- `DATABASE_URL` now defaults to `sqlite:///./data/newsintel.db` so the DB survives VS Code restarts inside the same project folder.
- Redis cache is used as a fallback when the UI refreshes but the DB has no fresh rows.
- Refresh button triggers ingestion and then reloads dashboard APIs.

## Important

If you unzip into a completely new folder every time, SQLite data from the old folder will not automatically move. To keep historic data, keep using the same project folder or copy `backend/data/newsintel.db` into the new project folder.

## Run

```powershell
cd backend
copy .env.example .env
python -m app.db.init_db
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

## Redis

If Redis is running, cached dashboard/news data is used as fallback. If Redis is not running, the app still works without cache.

## Verify

```powershell
curl -X POST http://127.0.0.1:8000/api/admin/ingest
curl http://127.0.0.1:8000/api/stats
curl "http://127.0.0.1:8000/api/news?limit=20&unique=false"
```
