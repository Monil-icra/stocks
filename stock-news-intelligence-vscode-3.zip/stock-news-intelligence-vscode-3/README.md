# Indian Stock Market News Intelligence — v3.0

**Full-stack platform:** FastAPI · SQLAlchemy · SQLite/PostgreSQL · Redis ·
React/Vite · Selenium · APScheduler · yfinance · Finance Model 1 · Signal Model 2

---

## Quick start (Windows, VS Code)

```powershell
# 1. Backend
cd backend
python -m venv .venv && .\.venv\Scripts\activate
pip install --upgrade pip setuptools wheel
pip install -r requirements-py314.txt
copy .env.example .env          # edit DATABASE_URL if needed
python -m app.db.init_db        # creates tables + seeds 250 stocks + all sources
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000

# 2. Frontend (new terminal)
cd frontend
npm install
npm run dev
```

Open UI: http://127.0.0.1:5173  
Open API docs: http://127.0.0.1:8000/docs

---

## TLS note

All external HTTP calls use `verify=False` (IT team policy):
- `httpx.Client(verify=False)` in `html_connector.py`, `sitemap_connector.py`, `ingest.py`
- `requests.Session(verify=False)` injected into yfinance in `quote_service.py`
- `SSL_VERIFY=false` in `.env.example`

---

## What's included

### News sources (20 total)
Economic Times (Markets, Trade, Earnings, Companies),
**CNBC TV18** (Markets, Economy, Companies),
**NDTV Profit** (Markets, Economy, Results),
**Zee Business** (Markets, Companies, IPO),
Business Standard (Markets, Economy, Companies),
Mint, BusinessLine, Trade Brains, Investing.com,
**Moneycontrol** (Selenium sitemap, mandatory Chrome)

### Stock universe
250 NSE stocks — Nifty 50, Nifty Next 50, Nifty Midcap 150, Nifty Smallcap 50

### Finance Model 1 (finance_model.py)
5-pillar weighted score per stock (0–100):
- Earnings Quality 30 % — YoY revenue/profit growth, margins, beat estimate
- Holding Pattern 20 % — promoter stake, FII/DII momentum, pledge %
- Corporate Events 15 % — bonus, buyback, dividend, order wins vs negatives
- News Sentiment 25 % — weighted average of article sentiment (exp decay 7d half-life)
- Technical Snapshot 10 % — 52-week position, beta, PE, daily change

### Signal Model 2 (signal_model.py)
RandomForest on 22-feature vectors:
- Output: **BULLISH / NEUTRAL / BEARISH** + confidence % + ATR price target range
- Cold start: 2000 synthetic samples from domain rules
- Feedback loop: retrains on `TradeSignal.actual_signal` (fill after horizon elapses)
- Persisted to `stable_data_dir/signal_model.pkl`

### APScheduler jobs (4)
| Job | Interval | What it does |
|-----|----------|-------------|
| rss_ingestion_due | 60 s | Ingest all due RSS + Selenium sources |
| quote_refresh | 5 min | Refresh all 250 yfinance quotes |
| signal_refresh | 30 min | Recompute Finance Model 1 + Signal Model 2 |
| signal_retrain | 24 h | Retrain model on feedback data |

---

## All bugs fixed (across all sessions)

### Backend
1. `ingest.py` — `selenium_sitemap_index` fell through to RSS → 0 Moneycontrol articles
2. `ingest.py` — `run.summary` datetime serialisation crash
3. `ingest.py` — `cache_set_json('news:last', latest)` passed raw ORM objects
4. `ingest.py` — per-article persist error left session broken without rollback
5. `sitemap_connector.py` — child sitemaps fetched with httpx (403) instead of Selenium
6. `selenium_connector.py` — Chrome XML viewer page_source only checked `<urlset`, not `<sitemapindex`
7. `selenium_connector.py` — body_text (plain text, no XML tags) replaced page_source for sitemapindex
8. `selenium_connector.py` — 3-strategy XML extraction: XHR → div JS → regex fallback
9. `lock.py` — no `db.rollback()` on release failure → session left broken
10. `scheduler.py` — lock release inside inner try, skipped on exception
11. `bootstrap.py` — same lock-release-in-wrong-block issue
12. `cache.py` — `invalidate_api_cache`, `cache_delete_pattern`, `cached_or_compute` missing
13. `config.py` — `database_url` pointed to volatile `./data/`, TTL settings undeclared
14. `routes.py` — SSE `/api/events` called route functions directly → SlowAPI crash
15. `routes.py` — `/api/ingestion-runs` serialisation without `jsonable_encoder`
16. `main.jsx` — `loadAll` useCallback deps included state vars → infinite re-render loop
17. `main.jsx` — `Promise.all` blanked UI on single endpoint failure → `Promise.allSettled`
18. `main.jsx` — dates not formatted in IST

---

## API reference

### News & dashboard
`GET /health` `GET /api/dashboard` `GET /api/news` `GET /api/news/search`
`GET /api/stats` `GET /api/categories` `GET /api/source-health`
`GET /api/source-stats` `GET /api/ingestion-runs` `GET /api/events` (SSE)
`POST /api/admin/ingest` `POST /api/admin/ingest-due`
`GET /api/debug/selenium-moneycontrol` `GET /api/debug/selenium-moneycontrol-deep`

### Stock intelligence
`GET /api/stocks/universe` `GET /api/stocks/universe/sectors`
`GET /api/stocks/quote/{symbol}` `GET /api/stocks/quotes`
`GET /api/stocks/quotes/nifty250` `GET /api/stocks/history/{symbol}`
`GET /api/stocks/earnings/{symbol}` `POST /api/stocks/earnings/{symbol}`
`GET /api/stocks/holdings/{symbol}` `POST /api/stocks/holdings/{symbol}`
`GET /api/stocks/events/{symbol}` `GET /api/stocks/events`
`POST /api/stocks/events/{symbol}`
`GET /api/stocks/finance-score/{symbol}` `GET /api/stocks/finance-scores`
`GET /api/stocks/signal/{symbol}` `GET /api/stocks/signals`
`GET /api/stocks/signals/history/{symbol}` `GET /api/stocks/signals/summary`
`POST /api/stocks/signals/retrain` `GET /api/stocks/model/info`
`GET /api/stocks/detail/{symbol}`

---

## Validation (offline, no server needed)

```powershell
cd backend
python validate.py        # 11 checks, all pass without network/Chrome/Redis
pytest tests/ -v --tb=short
```

---

## Troubleshooting

**0 Moneycontrol articles**
```powershell
curl "http://127.0.0.1:8000/api/debug/selenium-moneycontrol-deep?max_children=2"
# Check: "verdict": "OK: N articles ready to insert..."
# If not: check ./logs/selenium_moneycontrol.log for XHR_SUCCESS/XHR_MISS
```

**ChromeDriver version mismatch**
Check Chrome version → download matching ChromeDriver from
https://googlechromelabs.github.io/chrome-for-testing/ → add to PATH.

**`stock_universe` table not found**
```powershell
python -m app.db.init_db   # creates all 6 new tables
```

**yfinance 401 / rate-limited**
Quotes are cached 90 s in Redis. The app shows `—` from cache when Yahoo
blocks. Increase `QUOTE_CACHE_TTL_SECONDS=300` in `.env` to reduce frequency.

**Signal always NEUTRAL**
Model bootstraps on synthetic data. Fill `actual_signal` in `trade_signals`
after 20 trading days, then: `curl -X POST http://127.0.0.1:8000/api/stocks/signals/retrain`

**Finance score 50 for all stocks**
Correct on empty DB. Improves as: (1) news ingestion links articles to NSE
symbols, (2) you add earnings/holdings rows, (3) yfinance quotes load.
