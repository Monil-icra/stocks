# Moneycontrol Sitemap, IST Dates, and Source Health Fix

## What changed

- Moneycontrol blocked RSS/homepage sources are disabled in `python -m app.db.init_db`.
- `Moneycontrol News Sitemap` is enabled as `source_type=sitemap_xml`.
- Sitemap parser now reads `news:title`, `news:publication_date`, `news:keywords`, `lastmod`, and image URL.
- Moneycontrol sitemap articles can be stored even if the article page is blocked, because sitemap metadata is enough for initial sentiment/event detection.
- `/api/source-health` hides disabled sources by default, so old blocked Moneycontrol RSS/HTML cards do not confuse the UI.
- News APIs sort by `published_at` first and `fetched_at` fallback, newest first.
- UI dates are displayed in IST using `Asia/Kolkata`.
- Old stuck ingestion runs are marked `stale` after lock TTL.

## Required command after applying

```powershell
cd backend
python -m app.db.init_db
```

## Debug commands

```powershell
curl http://127.0.0.1:8000/api/source-health
curl "http://127.0.0.1:8000/api/source-health?include_disabled=true"
curl http://127.0.0.1:8000/api/debug/html-source/SOURCE_ID
curl -X POST http://127.0.0.1:8000/api/admin/ingest
curl "http://127.0.0.1:8000/api/news?limit=20&unique=false"
```
