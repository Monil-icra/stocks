# Startup RSS + Selenium Backfill Design

## What happens now

- RSS sources and Moneycontrol Selenium source are active.
- Old Moneycontrol RSS, HTML, and XML/httpx sources are disabled.
- On backend startup, a bootstrap ingestion thread starts immediately.
- The UI can show whatever data is already in SQLite while bootstrap ingestion is still running.
- RSS and Selenium data are fetched by workers in the same ingestion run.
- Moneycontrol uses Selenium mandatorily through source type `selenium_sitemap_index`.
- Moneycontrol sitemap index is used to pull backdated sitemap files for up to 6 days, limited by `MONEYCONTROL_SELENIUM_CHILD_SITEMAP_LIMIT`.
- Moneycontrol article pages are not fetched by default. Sitemap metadata is stored immediately for speed.

## Why you saw 130 first

The UI initially shows what already exists in SQLite or Redis cache. When ingestion finishes, the counts rise. If you unzip into a different folder or change SQLite DB path, the app starts with a fresh database.

## Stable DB path

`.env.example` uses:

`DATABASE_URL=sqlite:///C:/monil/stock-news-intelligence-data/newsintel.db`

This keeps data across ZIP replacements as long as you use the same `.env` setting.

## Debug logs

- Selenium: `backend/logs/selenium_moneycontrol.log`
- Startup bootstrap: `backend/logs/startup_bootstrap.log`

## Commands

```powershell
python -m app.db.init_db
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
curl http://127.0.0.1:8000/api/debug/selenium-moneycontrol
curl -X POST http://127.0.0.1:8000/api/admin/ingest
curl "http://127.0.0.1:8000/api/news?limit=20&unique=false"
```
