// import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
// import { createRoot } from 'react-dom/client';
// import {
//   Activity, AlertTriangle, BarChart3, Bell, Building2, CalendarClock,
//   ChevronDown, CircleDot, Database, Filter, Globe2, Layers3,
//   Menu, Newspaper, RefreshCcw, Search, Settings, ShieldCheck,
//   SlidersHorizontal, TrendingUp, Wifi, WifiOff, X, Zap,
//   ArrowLeft, DollarSign, Users, Award,
// } from 'lucide-react';
// import {
//   Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Line, LineChart,
//   Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine,
// } from 'recharts';
// import './styles.css';

// const API = import.meta.env.VITE_API_BASE || 'http://127.0.0.1:8000';
// const SIGNAL_COLORS = { BULLISH:'#22c55e', BEARISH:'#ef4444', NEUTRAL:'#f97316' };
// const CHART_COLORS = ['#60a5fa','#22c55e','#f97316','#ef4444','#a78bfa','#14b8a6','#facc15'];
// const NAV_ITEMS = [
//   {id:'dashboard',label:'Dashboard',icon:Activity},
//   {id:'news',label:'Live News',icon:Newspaper},
//   {id:'stocks',label:'Nifty 250',icon:Building2},
//   {id:'signals',label:'Trade Signals',icon:Zap},
//   {id:'finance',label:'Finance Scores',icon:Award},
//   {id:'sentiment',label:'Sentiment',icon:BarChart3},
//   {id:'sectors',label:'Sectors',icon:Layers3},
//   {id:'ipo',label:'IPO Monitor',icon:CalendarClock},
//   {id:'trade',label:'Trade Events',icon:Globe2},
//   {id:'sources',label:'Sources',icon:Database},
//   {id:'runs',label:'Ingestion Runs',icon:Settings},
// ];

// const safeArr=v=>Array.isArray(v)?v:[];
// const toNum=(v,fb=0)=>{const n=Number(v);return isFinite(n)?n:fb;};
// const asText=(v,fb='')=>v==null?fb:String(v);
// const getDate=v=>{if(!v)return null;const d=new Date(v);return isNaN(d)?null:d;};
// const fmtDate=v=>{const d=getDate(v);if(!d)return '—';return new Intl.DateTimeFormat('en-IN',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Kolkata'}).format(d);};
// const timeAgo=v=>{const d=getDate(v);if(!d)return '—';const s=Math.max(1,Math.floor((Date.now()-d)/1000));if(s<60)return `${s}s ago`;if(s<3600)return `${Math.floor(s/60)}m ago`;if(s<86400)return `${Math.floor(s/3600)}h ago`;return `${Math.floor(s/86400)}d ago`;};
// const fmtPrice=v=>v!=null?`₹${toNum(v).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}`:'—';
// const fmtPct=v=>v!=null?`${toNum(v)>=0?'+':''}${toNum(v).toFixed(2)}%`:'—';
// const fmtNum=(v,d=2)=>v!=null?toNum(v).toFixed(d):'—';
// const changeTone=v=>toNum(v)>0?'change-pos':toNum(v)<0?'change-neg':'change-flat';
// const sigBadge=s=>s==='BULLISH'?'badge-bullish':s==='BEARISH'?'badge-bearish':'badge-neutral';
// const normStory=t=>(t||'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\b(live|latest|update|news|market|stock)\b/g,' ').replace(/\s+/g,' ').trim().slice(0,160);
// function dedupe(articles){const seen=new Set();const out=[];for(const a of articles){const k=normStory(a.title||'')||a.id;if(!seen.has(k)){seen.add(k);out.push(a);}}return out;}
// function mapArticle(a){return{id:a?.id??a?.url??Math.random(),title:asText(a?.title,'Untitled'),summary:asText(a?.summary||a?.content,''),url:asText(a?.url,'#'),category:asText(a?.category,'market_news'),publishedAt:a?.published_at||a?.fetched_at||null,fetchedAt:a?.fetched_at||null};}
// function statusTone(s){const v=asText(s).toLowerCase();if(['healthy','completed','positive','connected','bullish'].includes(v))return 'success';if(['degraded','running','neutral','reconnecting'].includes(v))return 'warning';if(['blocked','disabled','failed','negative','disconnected','bearish'].includes(v))return 'danger';return 'default';}
// function pillarColor(score){if(score>=70)return '#22c55e';if(score>=50)return '#60a5fa';if(score>=35)return '#f97316';return '#ef4444';}

// function Card({title,icon:Icon,children,className='',actions=null}){return(<section className={`card ${className}`}><div className="card-title"><span className="card-icon">{Icon&&<Icon size={19}/>}</span><h2>{title}</h2><div className="card-actions">{actions}</div></div>{children}</section>);}
// function Pill({children,tone='default'}){return<span className={`pill ${tone}`}>{children}</span>;}
// function EmptyState({title='No data',detail='Data appears after ingestion completes.'}){return<div className="empty-state"><CircleDot size={22}/><strong>{title}</strong><span>{detail}</span></div>;}
// function ErrorBanner({message,onRetry}){if(!message)return null;return<div className="error-banner" role="alert"><AlertTriangle size={18}/><span>{message}</span>{onRetry&&<button onClick={onRetry}>Retry</button>}</div>;}
// function LoadingBlock({label='Loading…'}){return<div className="loading-block"><span className="spinner"/>{label}</div>;}
// function KpiCard({label,value,icon:Icon,tone='default',helper}){return<div className={`kpi-card ${tone}`} tabIndex="0"><div className="kpi-icon">{Icon&&<Icon size={22}/>}</div><div><span>{label}</span><strong>{value}</strong>{helper&&<small>{helper}</small>}</div></div>;}
// function LiveIndicator({state}){const tone=statusTone(state);const Icon=state==='connected'?Wifi:WifiOff;return<div className={`live-indicator ${tone}`}><Icon size={16}/><span>{state}</span></div>;}
// function StatusLine({label,value,tone='default'}){return<div className="status-line"><span>{label}</span><span>{value}</span></div>;}
// function NewsCard({item}){const tone=item.category==='ipo'?'warning':item.category==='trade'?'success':'default';return<article className="news-card"><div className="news-meta"><Pill tone={tone}>{item.category.replaceAll('_',' ')}</Pill><span>{timeAgo(item.publishedAt||item.fetchedAt)}</span></div><h3><a href={item.url} target="_blank" rel="noreferrer">{item.title}</a></h3>{item.summary&&<p>{item.summary}</p>}<div className="news-footer"><span>{fmtDate(item.publishedAt||item.fetchedAt)}</span><a href={item.url} target="_blank" rel="noreferrer">Open ↗</a></div></article>;}
// function PillarBar({name,score}){return<div className="pillar-row"><span>{name}</span><div className="pillar-bar-wrap"><div className="pillar-bar"><i style={{width:`${score}%`,background:pillarColor(score)}}/></div><strong style={{fontSize:12,minWidth:28}}>{fmtNum(score,0)}</strong></div></div>;}

// function SignalCard({signal,onClick}){
//   const ps=signal.pillar_scores||{};const pr=signal.price_range||{};
//   return(<div className={`signal-card ${signal.signal}`} onClick={()=>onClick&&onClick(signal.symbol)} style={{cursor:'pointer'}}>
//     <div className="signal-header"><div><div className="sym">{signal.symbol}</div><h3>{asText(signal.name,'').slice(0,26)}</h3></div><span className={sigBadge(signal.signal)}>{signal.signal}</span></div>
//     <div className="signal-meta"><span style={{color:'#9fb0c7',fontSize:13}}>Score:</span><strong style={{color:pillarColor(toNum(signal.finance_score,50))}}>{fmtNum(signal.finance_score,1)}</strong><span style={{color:'#9fb0c7',fontSize:13}}>Conf:</span><strong>{fmtNum(signal.confidence,1)}%</strong></div>
//     <div className="conf-bar"><i style={{width:`${signal.confidence}%`}}/></div>
//     <div className="signal-pillars">{Object.entries(ps).slice(0,4).map(([k,v])=><PillarBar key={k} name={k} score={toNum(v,50)}/>)}</div>
//     {pr.current_price&&<div className="price-range-box">
//       <div className="price-range-row"><span>Current</span><strong>{fmtPrice(pr.current_price)}</strong></div>
//       <div className="price-range-row"><span>Target Low</span><strong>{fmtPrice(pr.target_low)}</strong></div>
//       <div className="price-range-row"><span>Target High</span><strong>{fmtPrice(pr.target_high)}</strong></div>
//       <div className="price-range-row"><span>Horizon</span><strong>{pr.horizon_days||20}d</strong></div>
//     </div>}
//   </div>);
// }

// function StockCard({stock,quote,onClick}){
//   const q=quote||{};
//   return(<div className="stock-card" onClick={()=>onClick&&onClick(stock.symbol)} tabIndex="0">
//     <div><div className="sym">{stock.symbol}</div><h3>{asText(stock.name,'').slice(0,24)}</h3><span className="sector-tag">{stock.sector}</span></div>
//     <div className="stock-price-row"><span className="price">{fmtPrice(q.price)}</span><span className={changeTone(q.change_pct)}>{fmtPct(q.change_pct)}</span></div>
//     <div style={{fontSize:12,color:'#9fb0c7',display:'flex',justifyContent:'space-between'}}><span>H:{fmtPrice(q.day_high)}</span><span>L:{fmtPrice(q.day_low)}</span></div>
//   </div>);
// }

// export default function App(){
//   const [active,setActive]=useState('dashboard');
//   const [sidebarOpen,setSidebar]=useState(false);
//   const [loading,setLoading]=useState(true);
//   const [refreshing,setRefreshing]=useState(false);
//   const [error,setError]=useState('');
//   const [sseState,setSseState]=useState('reconnecting');
//   const [lastUpdated,setLastUpdated]=useState(null);
//   const [dashboard,setDashboard]=useState({latest_news:[],sentiment_counts:[],top_impacts:[],ipo_events:[],trade_events:[]});
//   const [news,setNews]=useState([]);
//   const [stats,setStats]=useState({});
//   const [categories,setCategories]=useState([]);
//   const [sourceStats,setSourceStats]=useState([]);
//   const [sourceHealth,setSourceHealth]=useState([]);
//   const [runs,setRuns]=useState([]);
//   const [filters,setFilters]=useState({query:'',category:'all',sort:'latest',limit:200,liveIfEmpty:true});
//   const [rawSearch,setRawSearch]=useState(null);
//   const [universe,setUniverse]=useState([]);
//   const [quotes,setQuotes]=useState({});
//   const [signals,setSignals]=useState([]);
//   const [sigLoading,setSigLoading]=useState(false);
//   const [sigTab,setSigTab]=useState('ALL');
//   const [finScores,setFinScores]=useState([]);
//   const [finLoading,setFinLoading]=useState(false);
//   const [stockSearch,setStockSearch]=useState('');
//   const [selectedStock,setSelectedStock]=useState(null);
//   const [stockDetail,setStockDetail]=useState(null);
//   const [detLoading,setDetLoading]=useState(false);

//   const latestRef=useRef({dashboard,news,stats,categories,sourceStats,sourceHealth,runs});
//   useEffect(()=>{latestRef.current={dashboard,news,stats,categories,sourceStats,sourceHealth,runs};});

//   const request=useCallback(async(path,opts)=>{
//     const r=await fetch(`${API}${path}`,opts);
//     if(!r.ok)throw new Error(`${r.status} ${r.statusText}`);
//     return r.json();
//   },[]);

//   const loadAll=useCallback(async({silent=false}={})=>{
//     const prev=latestRef.current;
//     if(!silent)setLoading(true);
//     setRefreshing(true);setError('');
//     try{
//       const res=await Promise.allSettled([
//         request('/api/dashboard'),
//         request('/api/news?limit=200&unique=true'),
//         request('/api/stats'),
//         request('/api/categories'),
//         request('/api/source-stats'),
//         request('/api/source-health'),
//         request('/api/ingestion-runs?limit=20'),
//       ]);
//       const ok=r=>r.status==='fulfilled'?r.value:null;
//       const[dR,nR,sR,cR,ssR,shR,rR]=res;
//       setDashboard(ok(dR)||prev.dashboard);
//       const arts=ok(nR);setNews(dedupe(safeArr(Array.isArray(arts)?arts:arts?.results||[])).map(mapArticle));
//       setStats(ok(sR)||prev.stats);
//       setCategories(safeArr(ok(cR)));
//       setSourceStats(safeArr(ok(ssR)));
//       setSourceHealth(safeArr(ok(shR)));
//       setRuns(safeArr(ok(rR)));
//       setLastUpdated(new Date());
//       const fails=res.filter(r=>r.status==='rejected').map(r=>r.reason?.message).filter(Boolean);
//       if(fails.length)setError(`Partial load — ${fails.slice(0,2).join(' | ')}`);
//     }catch(e){setError(e.message||'Load failed');}
//     finally{setLoading(false);setRefreshing(false);}
//   },[request]);

//   useEffect(()=>{loadAll();},[loadAll]);

//   const evtRef=useRef(null);
//   useEffect(()=>{
//     if(evtRef.current)evtRef.current.close();
//     const src=new EventSource(`${API}/api/events`);
//     evtRef.current=src;
//     src.onopen=()=>setSseState('connected');
//     src.onerror=()=>setSseState(p=>p==='connected'?'reconnecting':'disconnected');
//     src.addEventListener('dashboard',()=>{setSseState('connected');loadAll({silent:true}).catch(()=>{});});
//     return()=>src.close();
//   },[loadAll]);

//   const loadUniverse=useCallback(async()=>{try{const d=await request('/api/stocks/universe');setUniverse(safeArr(d));}catch(e){console.warn('universe',e);}},[request]);
//   const loadQuotes=useCallback(async(syms)=>{if(!syms?.length)return;try{const d=await request(`/api/stocks/quotes?symbols=${encodeURIComponent(syms.slice(0,50).join(','))}`);setQuotes(q=>({...q,...d}));}catch(e){console.warn('quotes',e);}},[request]);
//   const loadSignals=useCallback(async()=>{setSigLoading(true);try{const d=await request('/api/stocks/signals?limit=50');setSignals(safeArr(d.signals||d));}catch(e){setError('Signals: '+e.message);}finally{setSigLoading(false);}},[request]);
//   const loadFinScores=useCallback(async()=>{setFinLoading(true);try{const d=await request('/api/stocks/finance-scores?limit=50');setFinScores(safeArr(d));}catch(e){setError('Finance: '+e.message);}finally{setFinLoading(false);}},[request]);
//   const loadDetail=useCallback(async(sym)=>{setDetLoading(true);setStockDetail(null);try{const d=await request(`/api/stocks/detail/${sym}`);setStockDetail(d);}catch(e){setError('Detail: '+e.message);}finally{setDetLoading(false);}},[request]);

//   useEffect(()=>{if(active==='stocks'&&universe.length===0)loadUniverse();},[active,universe.length,loadUniverse]);
//   useEffect(()=>{if(active==='stocks'&&universe.length>0)loadQuotes(universe.slice(0,50).map(s=>s.symbol));},[active,universe,loadQuotes]);
//   useEffect(()=>{if(active==='signals'&&signals.length===0)loadSignals();},[active,signals.length,loadSignals]);
//   useEffect(()=>{if(active==='finance'&&finScores.length===0)loadFinScores();},[active,finScores.length,loadFinScores]);

//   function openStock(sym){setSelectedStock(sym);loadDetail(sym);setActive('detail');}

//   async function refreshNow(){
//     setRefreshing(true);setError('');
//     try{await request('/api/admin/ingest',{method:'POST'}).catch(e=>setError('Ingest: '+e.message));await loadAll({silent:true});}
//     finally{setRefreshing(false);}
//   }
//   async function runSearch(e){
//     e.preventDefault();const q=filters.query.trim();
//     if(!q){setRawSearch(null);await loadAll({silent:true});setActive('news');return;}
//     setLoading(true);setError('');
//     try{const d=await request(`/api/news/search?q=${encodeURIComponent(q)}&limit=${filters.limit}&live=${filters.liveIfEmpty}`);setRawSearch({query:q,count:d?.count??0});setNews(dedupe(safeArr(d?.results)).map(mapArticle));setActive('news');}
//     catch(e){setError(e.message||'Search failed');}
//     finally{setLoading(false);}
//   }
//   function clearFilters(){setFilters({query:'',category:'all',sort:'latest',limit:200,liveIfEmpty:true});setRawSearch(null);loadAll({silent:true}).catch(()=>{});}

//   const articles=useMemo(()=>{let rows=[...news];if(filters.category!=='all')rows=rows.filter(a=>a.category===filters.category);rows.sort((a,b)=>filters.sort==='oldest'?(getDate(a.publishedAt||a.fetchedAt)||0)-(getDate(b.publishedAt||b.fetchedAt)||0):(getDate(b.publishedAt||b.fetchedAt)||0)-(getDate(a.publishedAt||a.fetchedAt)||0));return rows;},[news,filters.category,filters.sort]);
//   const impacts=useMemo(()=>safeArr(dashboard.top_impacts).map(i=>({id:i?.id??Math.random(),company:asText(i?.company_name,'?'),sector:asText(i?.sector,'?'),score:toNum(i?.score)})),[dashboard.top_impacts]);
//   const sentRows=useMemo(()=>safeArr(dashboard.sentiment_counts).map(i=>({label:asText(i.label,'?'),count:toNum(i.count)})),[dashboard.sentiment_counts]);
//   const lastRun=runs[0]||null;
//   const filteredStocks=useMemo(()=>{let rows=safeArr(universe);if(stockSearch)rows=rows.filter(s=>(s.symbol+s.name+s.sector).toLowerCase().includes(stockSearch.toLowerCase()));return rows;},[universe,stockSearch]);
//   const sigCounts=useMemo(()=>({BULLISH:signals.filter(s=>s.signal==='BULLISH').length,NEUTRAL:signals.filter(s=>s.signal==='NEUTRAL').length,BEARISH:signals.filter(s=>s.signal==='BEARISH').length}),[signals]);
//   const filteredSignals=useMemo(()=>{let rows=safeArr(signals);if(sigTab!=='ALL')rows=rows.filter(s=>s.signal===sigTab);if(stockSearch)rows=rows.filter(s=>(s.symbol+s.name+(s.sector||'')).toLowerCase().includes(stockSearch.toLowerCase()));return rows;},[signals,sigTab,stockSearch]);
//   const currentNav=NAV_ITEMS.find(n=>n.id===active)||NAV_ITEMS[0];

//   const kpis=[
//     {label:'Raw Articles',value:toNum(stats.articles),icon:Database,tone:'info',helper:'stored evidence'},
//     {label:'Unique Stories',value:articles.length,icon:Newspaper,tone:'success',helper:'UI de-duped'},
//     {label:'Stocks Tracked',value:universe.length||250,icon:Building2,tone:'info',helper:'Nifty 250'},
//     {label:'Bullish Signals',value:sigCounts.BULLISH,icon:TrendingUp,tone:'success',helper:`${sigCounts.BEARISH} bearish`},
//     {label:'IPO Events',value:toNum(stats.ipo_events,safeArr(dashboard.ipo_events).length),icon:CalendarClock,tone:'info',helper:'detected'},
//     {label:'Trade Events',value:toNum(stats.trade_events,safeArr(dashboard.trade_events).length),icon:Globe2,tone:'info',helper:'global signals'},
//     {label:'Healthy Sources',value:`${safeArr(sourceHealth).filter(s=>s.status==='healthy').length}/${sourceHealth.length||0}`,icon:ShieldCheck,tone:sourceHealth.some(s=>s.status!=='healthy')?'warning':'success',helper:'source health'},
//     {label:'Last Ingestion',value:lastRun?`${lastRun.inserted||0}`:'0',icon:RefreshCcw,tone:statusTone(lastRun?.status),helper:lastRun?`${lastRun.mode} ${timeAgo(lastRun.finished_at||lastRun.started_at)}`:'no run'},
//   ];

//   return(
//     <div className="app-shell">
//       <aside className={`sidebar ${sidebarOpen?'open':''}`}>
//         <div className="brand">
//           <div className="brand-mark"><TrendingUp size={24}/></div>
//           <div><strong>Market Intel</strong><span>Indian Financial News</span></div>
//           <button className="icon-button close-button" onClick={()=>setSidebar(false)}><X size={18}/></button>
//         </div>
//         <nav className="nav-list">
//           {NAV_ITEMS.map(({id,label,icon:Icon})=>(<button key={id} className={active===id?'active':''} onClick={()=>{setActive(id);setSidebar(false);if(id!=='detail')setSelectedStock(null);}}><Icon size={18}/><span>{label}</span></button>))}
//         </nav>
//         <div className="scheduler-card"><RefreshCcw size={17}/><div><strong>Auto ingestion</strong><span>APScheduler · yfinance · sklearn</span></div></div>
//       </aside>

//       <main className="main-content">
//         <header className="top-header">
//           <button className="icon-button mobile-menu" onClick={()=>setSidebar(true)}><Menu/></button>
//           <div>
//             <span className="eyebrow">Python 3.12 · React · yfinance · Finance Model 1 · Signal Model 2</span>
//             <h1>{active==='detail'&&selectedStock?`${selectedStock} — Detail`:currentNav.label}</h1>
//             <p>Nifty 250 intelligence: real-time quotes, Finance Model 1 scores, ML trade signals, CNBC TV18 · NDTV Profit · Zee Business · Moneycontrol news.</p>
//           </div>
//           <div className="header-actions">
//             <LiveIndicator state={sseState}/>
//             <button className="secondary-button" onClick={refreshNow} disabled={refreshing}><RefreshCcw size={16}/>{refreshing?'Refreshing…':'Refresh'}</button>
//           </div>
//         </header>

//         <ErrorBanner message={error} onRetry={refreshNow}/>

//         {active!=='detail'&&(
//           <form className="control-bar" onSubmit={runSearch}>
//             <div className="control-search"><Search size={18}/><input value={filters.query} onChange={e=>setFilters(p=>({...p,query:e.target.value}))} placeholder="Search company, symbol, earnings, IPO, tariff…"/></div>
//             <label><Filter size={16}/>Category<select value={filters.category} onChange={e=>setFilters(p=>({...p,category:e.target.value}))}><option value="all">All</option>{safeArr(categories).map(c=><option key={c.category} value={c.category}>{c.category}</option>)}</select></label>
//             <label><SlidersHorizontal size={16}/>Sort<select value={filters.sort} onChange={e=>setFilters(p=>({...p,sort:e.target.value}))}><option value="latest">Latest</option><option value="oldest">Oldest</option></select></label>
//             <label className="checkbox"><input type="checkbox" checked={filters.liveIfEmpty} onChange={e=>setFilters(p=>({...p,liveIfEmpty:e.target.checked}))}/> Live if empty</label>
//             <button className="primary-button" type="submit"><Search size={16}/>Search</button>
//             <button className="ghost-button" type="button" onClick={clearFilters}>Clear</button>
//           </form>
//         )}

//         <div className="meta-strip">
//           <span>IST: {lastUpdated?fmtDate(lastUpdated):'Not loaded'}</span>
//           {rawSearch?<span>Search «{rawSearch.query}» — {rawSearch.count} results</span>:<span>Live feed · Refresh triggers ingestion</span>}
//         </div>

//         {loading&&!articles.length&&active==='dashboard'&&<LoadingBlock/>}

//         <section className="kpi-grid">{kpis.map(k=><KpiCard key={k.label} {...k}/>)}</section>

//         {active==='dashboard'&&<DashboardView sentRows={sentRows} impacts={impacts} articles={articles} sourceHealth={sourceHealth} runs={runs} signals={signals} onStockClick={openStock}/>}
//         {active==='news'&&<Card title={`Live News (${articles.length} stories)`} icon={Newspaper}>{articles.length?<div className="news-grid">{articles.map(a=><NewsCard key={a.id} item={a}/>)}</div>:<EmptyState title="No news"/>}</Card>}
//         {active==='stocks'&&<StocksView stocks={filteredStocks} quotes={quotes} search={stockSearch} setSearch={setStockSearch} loading={universe.length===0} onSelect={openStock} onRefreshQuotes={()=>loadQuotes(filteredStocks.slice(0,50).map(s=>s.symbol))}/>}
//         {active==='signals'&&<SignalsView signals={filteredSignals} tab={sigTab} setTab={setSigTab} counts={sigCounts} loading={sigLoading} search={stockSearch} setSearch={setStockSearch} onSelect={openStock} onRefresh={loadSignals}/>}
//         {active==='finance'&&<FinanceView scores={finScores} loading={finLoading} onSelect={openStock} onRefresh={loadFinScores}/>}
//         {active==='sentiment'&&<SentimentView sentRows={sentRows} impacts={impacts}/>}
//         {active==='sectors'&&<SectorView impacts={impacts}/>}
//         {active==='ipo'&&<Card title="IPO Monitor" icon={CalendarClock}>{safeArr(dashboard.ipo_events).length?<div className="event-list">{safeArr(dashboard.ipo_events).map((e,i)=><div key={i} className="event-row"><div><strong>{e.company_name}</strong><span>{fmtDate(e.event_date)}</span></div><Pill tone="warning">{e.event_type}</Pill></div>)}</div>:<EmptyState title="No IPO events"/>}</Card>}
//         {active==='trade'&&<Card title="Trade & Global Events" icon={Globe2}>{safeArr(dashboard.trade_events).length?<div className="event-list">{safeArr(dashboard.trade_events).map((e,i)=><div key={i} className="event-row"><div><strong>{e.event_type}</strong><span>{safeArr(e.affected_sectors).join(', ')}</span></div><Pill tone={statusTone(e.direction)}>{e.direction}</Pill></div>)}</div>:<EmptyState title="No trade events"/>}</Card>}
//         {active==='sources'&&<SourcesView sourceHealth={sourceHealth} sourceStats={sourceStats}/>}
//         {active==='runs'&&<Card title="Ingestion Runs" icon={RefreshCcw}>{runs.length?<div className="table-wrap"><table><thead><tr><th>ID</th><th>Mode</th><th>Status</th><th>Inserted</th><th>Started (IST)</th><th>Finished (IST)</th></tr></thead><tbody>{runs.map(r=><tr key={r.id}><td>{r.id}</td><td>{r.mode}</td><td><Pill tone={statusTone(r.status)}>{r.status}</Pill></td><td>{r.inserted}</td><td>{fmtDate(r.started_at)}</td><td>{fmtDate(r.finished_at)}</td></tr>)}</tbody></table></div>:<EmptyState title="No runs"/>}</Card>}
//         {active==='detail'&&<StockDetailView symbol={selectedStock} detail={stockDetail} loading={detLoading} onBack={()=>setActive('stocks')}/>}
//       </main>
//     </div>
//   );
// }

// function DashboardView({sentRows,impacts,articles,sourceHealth,runs,signals,onStockClick}){
//   const topBullish=safeArr(signals).filter(s=>s.signal==='BULLISH').slice(0,6);
//   return(
//     <div className="dashboard-grid">
//       <Card title="Sentiment Mix" icon={Activity}>{sentRows.length?<ResponsiveContainer width="100%" height={220}><PieChart><Pie data={sentRows} dataKey="count" nameKey="label" innerRadius={55} outerRadius={85}>{sentRows.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer>:<EmptyState title="No sentiment"/>}</Card>
//       <Card title="Impact Leaders" icon={TrendingUp}>{impacts.length?<ResponsiveContainer width="100%" height={220}><BarChart data={impacts.slice(0,10)}><CartesianGrid vertical={false} stroke="#1f3b5f"/><XAxis dataKey="company" hide/><YAxis/><Tooltip/><Bar dataKey="score" fill="#60a5fa" radius={[8,8,0,0]}/></BarChart></ResponsiveContainer>:<EmptyState title="No impact scores"/>}</Card>
//       <Card title="Latest Stories" icon={Newspaper} className="wide-card"><div className="compact-news-grid">{articles.slice(0,6).map(a=><NewsCard key={a.id} item={a}/>)}</div></Card>
//       {topBullish.length>0&&<Card title="Top Bullish Signals" icon={TrendingUp} className="wide-card"><div className="signal-grid">{topBullish.map(s=><SignalCard key={s.symbol} signal={s} onClick={onStockClick}/>)}</div></Card>}
//       <Card title="Snapshot" icon={Settings}><div className="status-list"><StatusLine label="Healthy sources" value={sourceHealth.filter(x=>x.status==='healthy').length} tone="success"/><StatusLine label="Last inserted" value={runs[0]?.inserted??0} tone={statusTone(runs[0]?.status)}/><StatusLine label="Bearish signals" value={safeArr(signals).filter(s=>s.signal==='BEARISH').length} tone="danger"/></div></Card>
//     </div>
//   );
// }

// function StocksView({stocks,quotes,search,setSearch,loading,onSelect,onRefreshQuotes}){
//   return(<div>
//     <div className="filter-bar">
//       <div className="search-box"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search symbol, name, sector…"/></div>
//       <button className="secondary-button" onClick={onRefreshQuotes}><RefreshCcw size={15}/>Refresh Quotes</button>
//       <span style={{color:'#9fb0c7',fontSize:13}}>{stocks.length} stocks</span>
//     </div>
//     {loading?<LoadingBlock label="Loading Nifty 250…"/>:stocks.length?<div className="stock-grid">{stocks.slice(0,100).map(s=><StockCard key={s.symbol} stock={s} quote={quotes[s.symbol]} onClick={onSelect}/>)}</div>:<EmptyState title="No stocks" detail="Run: python -m app.db.init_db"/>}
//   </div>);
// }

// function SignalsView({signals,tab,setTab,counts,loading,search,setSearch,onSelect,onRefresh}){
//   const tabs=['ALL','BULLISH','NEUTRAL','BEARISH'];
//   return(<div>
//     <div className="filter-bar">
//       <div className="tabs">{tabs.map(t=><button key={t} className={`tab-btn${tab===t?' active':''}`} onClick={()=>setTab(t)}>{t}{t!=='ALL'&&` (${counts[t]||0})`}</button>)}</div>
//       <div className="search-box" style={{maxWidth:240}}><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Filter symbol…"/></div>
//       <button className="secondary-button" onClick={onRefresh} disabled={loading}><RefreshCcw size={15}/>{loading?'Generating…':'Regenerate'}</button>
//     </div>
//     {loading?<LoadingBlock label="Running Finance Model 1 + Signal Model 2 for 50 stocks…"/>:signals.length?<div className="signal-grid">{signals.map(s=><SignalCard key={s.symbol} signal={s} onClick={onSelect}/>)}</div>:<EmptyState title="No signals" detail="Click Regenerate to run the signal model."/>}
//   </div>);
// }

// function FinanceView({scores,loading,onSelect,onRefresh}){
//   if(loading)return<LoadingBlock label="Computing Finance Model 1 scores…"/>;
//   return(<Card title="Finance Model 1 — All Stocks" icon={Award} actions={<button className="secondary-button" onClick={onRefresh}><RefreshCcw size={15}/>Refresh</button>}>
//     {scores.length?<div className="table-wrap"><table><thead><tr><th>Symbol</th><th>Name</th><th>Sector</th><th>Finance Score</th><th>Tier</th><th>Earnings</th><th>Holding</th><th>Sentiment</th><th>Technical</th></tr></thead>
//     <tbody>{scores.map(s=>(<tr key={s.symbol} onClick={()=>onSelect(s.symbol)} style={{cursor:'pointer'}}>
//       <td><strong style={{color:'#60a5fa'}}>{s.symbol}</strong></td>
//       <td>{asText(s.name,'').slice(0,22)}</td>
//       <td><span className="sector-tag">{s.sector}</span></td>
//       <td><strong style={{color:pillarColor(toNum(s.finance_score,50))}}>{fmtNum(s.finance_score,1)}</strong></td>
//       <td><span className={sigBadge(s.signal_tier)}>{s.signal_tier}</span></td>
//       <td>{fmtNum(s.pillar_scores?.earnings,0)}</td>
//       <td>{fmtNum(s.pillar_scores?.holding,0)}</td>
//       <td>{fmtNum(s.pillar_scores?.sentiment,0)}</td>
//       <td>{fmtNum(s.pillar_scores?.technical,0)}</td>
//     </tr>))}</tbody></table></div>:<EmptyState title="No scores" detail="Click Refresh to compute Finance Model 1 scores."/>}
//   </Card>);
// }

// function StockDetailView({symbol,detail,loading,onBack}){
//   const [tab,setTab]=useState('overview');
//   if(loading)return<div><button className="secondary-button" onClick={onBack} style={{marginBottom:14}}><ArrowLeft size={16}/>Back</button><LoadingBlock label={`Loading ${symbol}…`}/></div>;
//   if(!detail)return<div><button className="secondary-button" onClick={onBack}><ArrowLeft size={16}/>Back</button><EmptyState title="No detail"/></div>;
//   const {stock_info,quote,finance_score,signal,price_history,holding_data,recent_articles}=detail;
//   const q=quote||{};const fs=finance_score||{};const sig=signal||{};const ps=fs.pillar_scores||{};const pr=sig.price_range||{};
//   const hist=safeArr(price_history).map(h=>({...h,close:toNum(h.close)}));
//   return(<div>
//     <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14,flexWrap:'wrap'}}>
//       <button className="secondary-button" onClick={onBack}><ArrowLeft size={16}/>Back</button>
//       <h2 style={{margin:0}}>{symbol} — {asText(stock_info?.name,'').slice(0,30)}</h2>
//       <span className="sector-tag">{stock_info?.sector}</span>
//       {sig.signal&&<span className={sigBadge(sig.signal)}>{sig.signal}</span>}
//     </div>
//     <div className="tabs">
//       {['overview','price','earnings','holdings','events','news'].map(t=><button key={t} className={`tab-btn${tab===t?' active':''}`} onClick={()=>setTab(t)}>{t}</button>)}
//     </div>
//     {tab==='overview'&&(<div className="detail-grid">
//       <Card title="Live Quote" icon={DollarSign}><div className="status-list">
//         <StatusLine label="Price" value={fmtPrice(q.price)}/><StatusLine label="Change" value={<span className={changeTone(q.change_pct)}>{fmtPct(q.change_pct)}</span>}/>
//         <StatusLine label="Day High" value={fmtPrice(q.day_high)}/><StatusLine label="Day Low" value={fmtPrice(q.day_low)}/>
//         <StatusLine label="52W High" value={fmtPrice(q.week52_high)}/><StatusLine label="52W Low" value={fmtPrice(q.week52_low)}/>
//         <StatusLine label="P/E" value={fmtNum(q.pe_ratio,2)}/><StatusLine label="EPS" value={fmtNum(q.eps,2)}/>
//         <StatusLine label="Beta" value={fmtNum(q.beta,2)}/><StatusLine label="Mkt Cap" value={q.market_cap?`₹${(q.market_cap/1e7).toFixed(0)}Cr`:'—'}/>
//       </div></Card>
//       <Card title="Finance Score" icon={Award}><div style={{textAlign:'center',marginBottom:14}}><div className="score-ring"><span className="score-num" style={{color:pillarColor(toNum(fs.finance_score,50))}}>{fmtNum(fs.finance_score,1)}</span><span className="score-label">{fs.signal_tier}</span></div></div><div className="signal-pillars">{Object.entries(ps).map(([k,v])=><PillarBar key={k} name={k} score={toNum(v,50)}/>)}</div></Card>
//       <Card title="Trade Signal" icon={Zap}><div className="status-list"><StatusLine label="Signal" value={<span className={sigBadge(sig.signal)}>{sig.signal||'—'}</span>}/><StatusLine label="Confidence" value={`${fmtNum(sig.confidence,1)}%`}/></div>
//         {pr.current_price&&<div className="price-range-box" style={{marginTop:12}}>
//           <div className="price-range-row"><span>Current</span><strong>{fmtPrice(pr.current_price)}</strong></div>
//           <div className="price-range-row"><span>Target Low</span><strong>{fmtPrice(pr.target_low)}</strong></div>
//           <div className="price-range-row"><span>Target High</span><strong>{fmtPrice(pr.target_high)}</strong></div>
//           <div className="price-range-row"><span>Horizon</span><strong>{pr.horizon_days||20} trading days</strong></div>
//           <div className="price-range-row"><span>ATR %</span><strong>{fmtNum(pr.atr_pct,2)}%</strong></div>
//         </div>}
//         {sig.class_proba&&<div style={{marginTop:12,display:'grid',gap:6}}>{Object.entries(sig.class_proba).map(([label,pct])=><div key={label} style={{display:'flex',alignItems:'center',gap:8}}><span style={{width:70,fontSize:12,color:'#9fb0c7'}}>{label}</span><div style={{flex:1,height:8,background:'#102241',borderRadius:999,overflow:'hidden'}}><div style={{width:`${pct}%`,height:'100%',background:SIGNAL_COLORS[label],borderRadius:999}}/></div><span style={{width:38,fontSize:12,textAlign:'right'}}>{fmtNum(pct,1)}%</span></div>)}</div>}
//       </Card>
//       <Card title="Holdings Summary" icon={Users}>{holding_data&&Object.keys(holding_data).length?<div className="status-list"><StatusLine label="Promoter %" value={`${fmtNum(holding_data.promoter_pct!=null?holding_data.promoter_pct*100:null,2)}%`}/><StatusLine label="Institution %" value={`${fmtNum(holding_data.institution_pct!=null?holding_data.institution_pct*100:null,2)}%`}/></div>:<EmptyState title="Holdings not available" detail="yfinance data pending"/>}</Card>
//     </div>)}
//     {tab==='price'&&<Card title="Price History (3 months)" icon={BarChart3}>{hist.length?<ResponsiveContainer width="100%" height={320}><AreaChart data={hist}><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#60a5fa" stopOpacity={0.3}/><stop offset="95%" stopColor="#60a5fa" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#1f3b5f" vertical={false}/><XAxis dataKey="date" tick={{fontSize:11}} interval="preserveStartEnd"/><YAxis tick={{fontSize:11}} domain={['auto','auto']}/><Tooltip formatter={v=>`₹${toNum(v).toFixed(2)}`}/><Area type="monotone" dataKey="close" stroke="#60a5fa" fill="url(#cg)" strokeWidth={2} dot={false}/>{pr.target_low&&<ReferenceLine y={pr.target_low} stroke="#ef4444" strokeDasharray="4 4"/>}{pr.target_high&&<ReferenceLine y={pr.target_high} stroke="#22c55e" strokeDasharray="4 4"/>}</AreaChart></ResponsiveContainer>:<EmptyState title="No price history"/>}</Card>}
//     {tab==='earnings'&&<EarningsTab symbol={symbol}/>}
//     {tab==='holdings'&&<HoldingsTab symbol={symbol}/>}
//     {tab==='events'&&<EventsTab symbol={symbol}/>}
//     {tab==='news'&&<Card title={`News — ${symbol}`} icon={Newspaper}>{safeArr(recent_articles).length?<div className="news-grid">{safeArr(recent_articles).map(a=><NewsCard key={a.id} item={mapArticle(a)}/>)}</div>:<EmptyState title="No linked news"/>}</Card>}
//   </div>);
// }

// function EarningsTab({symbol}){
//   const [data,setData]=useState(null);const [loading,setLoading]=useState(true);
//   useEffect(()=>{fetch(`${API}/api/stocks/earnings/${symbol}`).then(r=>r.json()).then(setData).catch(()=>setData({})).finally(()=>setLoading(false));},[symbol]);
//   if(loading)return<LoadingBlock label="Loading earnings…"/>;
//   const rows=safeArr(data?.db_records).concat(safeArr(data?.yfinance_quarterly));
//   return<Card title={`Earnings — ${symbol}`} icon={BarChart3}>{rows.length?<div className="table-wrap"><table><thead><tr><th>Quarter</th><th>Revenue ₹Cr</th><th>Rev YoY%</th><th>Net Profit ₹Cr</th><th>Profit YoY%</th><th>Net Margin</th><th>EPS</th><th>Beat</th></tr></thead><tbody>{rows.map((r,i)=><tr key={i}><td>{asText(r.quarter_label||r.quarter,'—')}</td><td>{fmtNum(r.revenue_cr||r.revenue,0)}</td><td className={changeTone(r.revenue_yoy_pct)}>{fmtPct(r.revenue_yoy_pct)}</td><td>{fmtNum(r.net_profit_cr||r.earnings,0)}</td><td className={changeTone(r.net_profit_yoy_pct)}>{fmtPct(r.net_profit_yoy_pct)}</td><td>{fmtNum(r.net_margin_pct,1)}%</td><td>{fmtNum(r.eps,2)}</td><td style={{color:r.beat_estimate===true?'#22c55e':r.beat_estimate===false?'#ef4444':'inherit'}}>{r.beat_estimate===true?'✓':r.beat_estimate===false?'✗':'—'}</td></tr>)}</tbody></table></div>:<EmptyState title="No earnings data" detail="Auto-extracted from results articles or add via POST /api/stocks/earnings/{symbol}"/>}</Card>;
// }

// function HoldingsTab({symbol}){
//   const [data,setData]=useState(null);const [loading,setLoading]=useState(true);
//   useEffect(()=>{fetch(`${API}/api/stocks/holdings/${symbol}`).then(r=>r.json()).then(setData).catch(()=>setData({})).finally(()=>setLoading(false));},[symbol]);
//   if(loading)return<LoadingBlock label="Loading holdings…"/>;
//   const rows=safeArr(data?.db_records);const yf=data?.yfinance||{};
//   return<div>
//     {rows.length?<Card title={`Shareholding — ${symbol}`} icon={Users}><div className="table-wrap"><table><thead><tr><th>Quarter</th><th>Promoter%</th><th>Pledged%</th><th>FII%</th><th>DII%</th><th>MF%</th><th>Public%</th><th>FII Chg</th></tr></thead><tbody>{rows.map((r,i)=><tr key={i}><td>{asText(r.quarter_label,'—')}</td><td>{fmtNum(r.promoter_pct,2)}%</td><td style={{color:toNum(r.pledged_pct)>20?'#ef4444':'#22c55e'}}>{fmtNum(r.pledged_pct,2)}%</td><td>{fmtNum(r.fii_pct,2)}%</td><td>{fmtNum(r.dii_pct,2)}%</td><td>{fmtNum(r.mutual_fund_pct,2)}%</td><td>{fmtNum(r.public_pct,2)}%</td><td className={changeTone(r.fii_change_pct)}>{fmtPct(r.fii_change_pct)}</td></tr>)}</tbody></table></div></Card>:null}
//     {yf&&Object.keys(yf).length?<Card title="yfinance Institutional Holders" icon={Users}>{safeArr(yf.institutional).length?<div className="table-wrap"><table><thead><tr><th>Holder</th><th>% Out</th></tr></thead><tbody>{safeArr(yf.institutional).slice(0,8).map((h,i)=><tr key={i}><td>{asText(h.Holder||h.holder,'—')}</td><td>{fmtNum(h['% Out']||h.pctOut,2)}%</td></tr>)}</tbody></table></div>:null}{yf.promoter_pct!=null&&<div className="status-list" style={{marginTop:10}}><StatusLine label="Promoter (yf)" value={`${fmtNum(yf.promoter_pct*100,2)}%`}/><StatusLine label="Institution (yf)" value={`${fmtNum(yf.institution_pct*100,2)}%`}/></div>}</Card>:null}
//     {!rows.length&&(!yf||!Object.keys(yf).length)&&<EmptyState title="No holding data" detail="Holdings auto-extracted or add via POST /api/stocks/holdings/{symbol}"/>}
//   </div>;
// }

// function EventsTab({symbol}){
//   const [data,setData]=useState(null);const [loading,setLoading]=useState(true);
//   useEffect(()=>{fetch(`${API}/api/stocks/events/${symbol}?days=180`).then(r=>r.json()).then(setData).catch(()=>setData([])).finally(()=>setLoading(false));},[symbol]);
//   if(loading)return<LoadingBlock label="Loading events…"/>;
//   const rows=safeArr(data);
//   const typeColor=t=>{const v=(t||'').toLowerCase();if(['dividend','bonus','order','buyback'].some(x=>v.includes(x)))return '#22c55e';if(['sell','fraud','downgrade','litigation'].some(x=>v.includes(x)))return '#ef4444';return '#60a5fa';};
//   return<Card title={`Events — ${symbol} (180d)`} icon={CalendarClock}>{rows.length?<div className="event-list">{rows.map((r,i)=><div key={i} className="event-row"><div><strong style={{color:typeColor(r.event_type)}}>{r.event_type}</strong><span>{asText(r.description,'').slice(0,100)}</span><span style={{fontSize:12,color:'#9fb0c7'}}>{fmtDate(r.event_date)}</span></div>{r.amount&&<Pill tone="info">₹{r.amount}</Pill>}{r.ratio&&<Pill tone="warning">{r.ratio}</Pill>}</div>)}</div>:<EmptyState title="No events" detail="Events auto-extracted from news or add via POST /api/stocks/events/{symbol}"/>}</Card>;
// }

// function SentimentView({sentRows,impacts}){
//   const trend=impacts.slice(0,20).map((it,i)=>({name:`#${i+1}`,score:it.score}));
//   return<div className="dashboard-grid">
//     <Card title="Sentiment Distribution" icon={Activity}>{sentRows.length?<ResponsiveContainer width="100%" height={280}><PieChart><Pie data={sentRows} dataKey="count" nameKey="label" innerRadius={70} outerRadius={110}>{sentRows.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer>:<EmptyState title="No sentiment"/>}</Card>
//     <Card title="Impact Score Curve" icon={TrendingUp}>{trend.length?<ResponsiveContainer width="100%" height={280}><LineChart data={trend}><CartesianGrid stroke="#1f3b5f" vertical={false}/><XAxis dataKey="name"/><YAxis/><Tooltip/><Line type="monotone" dataKey="score" stroke="#22c55e" strokeWidth={3} dot={false}/></LineChart></ResponsiveContainer>:<EmptyState title="No trend"/>}</Card>
//   </div>;
// }

// function SectorView({impacts}){
//   const sectors=useMemo(()=>{const m=new Map();for(const it of impacts){const k=it.sector||'?';const ex=m.get(k)||{sector:k,count:0,maxImpact:0,avgImpact:0};ex.count++;ex.avgImpact+=it.score;ex.maxImpact=Math.max(ex.maxImpact,it.score);m.set(k,ex);}return[...m.values()].map(r=>({...r,avgImpact:r.count?Math.round(r.avgImpact/r.count):0})).sort((a,b)=>b.maxImpact-a.maxImpact);},[impacts]);
//   return<Card title="Sector Intelligence" icon={Layers3}>{sectors.length?<div className="sector-grid">{sectors.map(r=><div key={r.sector} className="sector-card"><span>{r.sector}</span><strong>{r.maxImpact}</strong><small>{r.count} records · avg {r.avgImpact}</small><div className="progress"><i style={{width:`${Math.min(100,r.maxImpact)}%`}}/></div></div>)}</div>:<EmptyState title="No sector data"/>}</Card>;
// }

// function SourcesView({sourceHealth,sourceStats}){
//   const artMap=new Map(safeArr(sourceStats).map(x=>[x.source,toNum(x.articles)]));
//   return<Card title="Source Health" icon={Database}>{sourceHealth.length?<div className="source-grid">{sourceHealth.map(r=><div key={r.id} className="source-card"><div><strong>{r.source}</strong><Pill tone={statusTone(r.status)}>{r.status}</Pill></div><span>Type: {r.source_type}</span><span>Articles: {artMap.get(r.source)??r.articles??0}</span><span>Next: {fmtDate(r.next_run_at)}</span><span>Last OK: {fmtDate(r.last_success_at)}</span>{r.last_error&&<small>{r.last_error?.slice(0,80)}</small>}</div>)}</div>:<EmptyState title="No sources"/>}</Card>;
// }
import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import {
  Activity, AlertTriangle, BarChart3, Bell, Building2, CalendarClock,
  ChevronDown, CircleDot, Database, Filter, Globe2, Layers3,
  Menu, Newspaper, RefreshCcw, Search, Settings, ShieldCheck,
  SlidersHorizontal, TrendingUp, Wifi, WifiOff, X, Zap,
  ArrowLeft, DollarSign, Users, Award,
} from 'lucide-react';
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Line, LineChart,
  Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis, ReferenceLine,
} from 'recharts';
import './styles.css';

const API = import.meta.env.VITE_API_BASE || ''; // Use Vite /api proxy in development
const SIGNAL_COLORS = { BULLISH:'#22c55e', BEARISH:'#ef4444', NEUTRAL:'#f97316' };
const CHART_COLORS = ['#60a5fa','#22c55e','#f97316','#ef4444','#a78bfa','#14b8a6','#facc15'];
const NAV_ITEMS = [
  {id:'dashboard',label:'Dashboard',icon:Activity},
  {id:'news',label:'Live News',icon:Newspaper},
  {id:'stocks',label:'Nifty 250',icon:Building2},
  {id:'signals',label:'Trade Signals',icon:Zap},
  {id:'finance',label:'Finance Scores',icon:Award},
  {id:'sentiment',label:'Sentiment',icon:BarChart3},
  {id:'sectors',label:'Sectors',icon:Layers3},
  {id:'ipo',label:'IPO Monitor',icon:CalendarClock},
  {id:'trade',label:'Trade Events',icon:Globe2},
  {id:'sources',label:'Sources',icon:Database},
  {id:'runs',label:'Ingestion Runs',icon:Settings},
];

const safeArr=v=>Array.isArray(v)?v:[];
const toNum=(v,fb=0)=>{const n=Number(v);return isFinite(n)?n:fb;};
const asText=(v,fb='')=>v==null?fb:String(v);
const getDate=v=>{if(!v)return null;const d=new Date(v);return isNaN(d)?null:d;};
const fmtDate=v=>{const d=getDate(v);if(!d)return '—';return new Intl.DateTimeFormat('en-IN',{dateStyle:'medium',timeStyle:'short',timeZone:'Asia/Kolkata'}).format(d);};
const timeAgo=v=>{const d=getDate(v);if(!d)return '—';const s=Math.max(1,Math.floor((Date.now()-d)/1000));if(s<60)return `${s}s ago`;if(s<3600)return `${Math.floor(s/60)}m ago`;if(s<86400)return `${Math.floor(s/3600)}h ago`;return `${Math.floor(s/86400)}d ago`;};
const fmtPrice=v=>v!=null?`₹${toNum(v).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2})}`:'—';
const fmtPct=v=>v!=null?`${toNum(v)>=0?'+':''}${toNum(v).toFixed(2)}%`:'—';
const fmtNum=(v,d=2)=>v!=null?toNum(v).toFixed(d):'—';
const changeTone=v=>toNum(v)>0?'change-pos':toNum(v)<0?'change-neg':'change-flat';
const sigBadge=s=>s==='BULLISH'?'badge-bullish':s==='BEARISH'?'badge-bearish':'badge-neutral';
const normStory=t=>(t||'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\b(live|latest|update|news|market|stock)\b/g,' ').replace(/\s+/g,' ').trim().slice(0,160);
function dedupe(articles){const seen=new Set();const out=[];for(const a of articles){const k=normStory(a.title||'')||a.id;if(!seen.has(k)){seen.add(k);out.push(a);}}return out;}
function mapArticle(a){return{id:a?.id??a?.url??Math.random(),title:asText(a?.title,'Untitled'),summary:asText(a?.summary||a?.content,''),url:asText(a?.url,'#'),category:asText(a?.category,'market_news'),publishedAt:a?.published_at||a?.fetched_at||null,fetchedAt:a?.fetched_at||null};}
function statusTone(s){const v=asText(s).toLowerCase();if(['healthy','completed','positive','connected','bullish'].includes(v))return 'success';if(['degraded','running','neutral','reconnecting'].includes(v))return 'warning';if(['blocked','disabled','failed','negative','disconnected','bearish'].includes(v))return 'danger';return 'default';}
function pillarColor(score){if(score>=70)return '#22c55e';if(score>=50)return '#60a5fa';if(score>=35)return '#f97316';return '#ef4444';}

function Card({title,icon:Icon,children,className='',actions=null}){return(<section className={`card ${className}`}><div className="card-title"><span className="card-icon">{Icon&&<Icon size={19}/>}</span><h2>{title}</h2><div className="card-actions">{actions}</div></div>{children}</section>);}
function Pill({children,tone='default'}){return<span className={`pill ${tone}`}>{children}</span>;}
function EmptyState({title='No data',detail='Data appears after ingestion completes.'}){return<div className="empty-state"><CircleDot size={22}/><strong>{title}</strong><span>{detail}</span></div>;}
function ErrorBanner({message,onRetry}){if(!message)return null;return<div className="error-banner" role="alert"><AlertTriangle size={18}/><span>{message}</span>{onRetry&&<button onClick={onRetry}>Retry</button>}</div>;}
function LoadingBlock({label='Loading…'}){return<div className="loading-block"><span className="spinner"/>{label}</div>;}
function KpiCard({label,value,icon:Icon,tone='default',helper}){return<div className={`kpi-card ${tone}`} tabIndex="0"><div className="kpi-icon">{Icon&&<Icon size={22}/>}</div><div><span>{label}</span><strong>{value}</strong>{helper&&<small>{helper}</small>}</div></div>;}
function LiveIndicator({state}){const tone=statusTone(state);const Icon=state==='connected'?Wifi:WifiOff;return<div className={`live-indicator ${tone}`}><Icon size={16}/><span>{state}</span></div>;}
function StatusLine({label,value,tone='default'}){return<div className="status-line"><span>{label}</span><span>{value}</span></div>;}
function NewsCard({item}){const tone=item.category==='ipo'?'warning':item.category==='trade'?'success':'default';return<article className="news-card"><div className="news-meta"><Pill tone={tone}>{item.category.replaceAll('_',' ')}</Pill><span>{timeAgo(item.publishedAt||item.fetchedAt)}</span></div><h3><a href={item.url} target="_blank" rel="noreferrer">{item.title}</a></h3>{item.summary&&<p>{item.summary}</p>}<div className="news-footer"><span>{fmtDate(item.publishedAt||item.fetchedAt)}</span><a href={item.url} target="_blank" rel="noreferrer">Open ↗</a></div></article>;}
function PillarBar({name,score}){return<div className="pillar-row"><span>{name}</span><div className="pillar-bar-wrap"><div className="pillar-bar"><i style={{width:`${score}%`,background:pillarColor(score)}}/></div><strong style={{fontSize:12,minWidth:28}}>{fmtNum(score,0)}</strong></div></div>;}

function SignalCard({signal,onClick}){
  const ps=signal.pillar_scores||{};const pr=signal.price_range||{};
  return(<div className={`signal-card ${signal.signal}`} onClick={()=>onClick&&onClick(signal.symbol)} style={{cursor:'pointer'}}>
    <div className="signal-header"><div><div className="sym">{signal.symbol}</div><h3>{asText(signal.name,'').slice(0,26)}</h3></div><span className={sigBadge(signal.signal)}>{signal.signal}</span></div>
    <div className="signal-meta"><span style={{color:'#9fb0c7',fontSize:13}}>Score:</span><strong style={{color:pillarColor(toNum(signal.finance_score,50))}}>{fmtNum(signal.finance_score,1)}</strong><span style={{color:'#9fb0c7',fontSize:13}}>Conf:</span><strong>{fmtNum(signal.confidence,1)}%</strong></div>
    <div className="conf-bar"><i style={{width:`${signal.confidence}%`}}/></div>
    <div className="signal-pillars">{Object.entries(ps).slice(0,4).map(([k,v])=><PillarBar key={k} name={k} score={toNum(v,50)}/>)}</div>
    {pr.current_price&&<div className="price-range-box">
      <div className="price-range-row"><span>Current</span><strong>{fmtPrice(pr.current_price)}</strong></div>
      <div className="price-range-row"><span>Target Low</span><strong>{fmtPrice(pr.target_low)}</strong></div>
      <div className="price-range-row"><span>Target High</span><strong>{fmtPrice(pr.target_high)}</strong></div>
      <div className="price-range-row"><span>Horizon</span><strong>{pr.horizon_days||20}d</strong></div>
    </div>}
  </div>);
}

function StockCard({stock,quote,onClick}){
  const q=quote||{};
  return(<div className="stock-card" onClick={()=>onClick&&onClick(stock.symbol)} tabIndex="0">
    <div><div className="sym">{stock.symbol}</div><h3>{asText(stock.name,'').slice(0,24)}</h3><span className="sector-tag">{stock.sector}</span></div>
    <div className="stock-price-row"><span className="price">{fmtPrice(q.price)}</span><span className={changeTone(q.change_pct)}>{fmtPct(q.change_pct)}</span></div>
    <div style={{fontSize:12,color:'#9fb0c7',display:'flex',justifyContent:'space-between'}}><span>H:{fmtPrice(q.day_high)}</span><span>L:{fmtPrice(q.day_low)}</span></div>
  </div>);
}

export default function App(){
  const [active,setActive]=useState('dashboard');
  const [sidebarOpen,setSidebar]=useState(false);
  const [loading,setLoading]=useState(true);
  const [refreshing,setRefreshing]=useState(false);
  const [error,setError]=useState('');
  const [sseState,setSseState]=useState('reconnecting');
  const [lastUpdated,setLastUpdated]=useState(null);
  const [dashboard,setDashboard]=useState({latest_news:[],sentiment_counts:[],top_impacts:[],ipo_events:[],trade_events:[]});
  const [news,setNews]=useState([]);
  const [stats,setStats]=useState({});
  const [categories,setCategories]=useState([]);
  const [sourceStats,setSourceStats]=useState([]);
  const [sourceHealth,setSourceHealth]=useState([]);
  const [runs,setRuns]=useState([]);
  const [filters,setFilters]=useState({query:'',category:'all',sort:'latest',limit:200,liveIfEmpty:true});
  const [rawSearch,setRawSearch]=useState(null);
  const [universe,setUniverse]=useState([]);
  const [quotes,setQuotes]=useState({});
  const [signals,setSignals]=useState([]);
  const [sigLoading,setSigLoading]=useState(false);
  const [sigTab,setSigTab]=useState('ALL');
  const [finScores,setFinScores]=useState([]);
  const [finLoading,setFinLoading]=useState(false);
  const [stockSearch,setStockSearch]=useState('');
  const [selectedStock,setSelectedStock]=useState(null);
  const [stockDetail,setStockDetail]=useState(null);
  const [detLoading,setDetLoading]=useState(false);

  const latestRef=useRef({dashboard,news,stats,categories,sourceStats,sourceHealth,runs});
  useEffect(()=>{latestRef.current={dashboard,news,stats,categories,sourceStats,sourceHealth,runs};});

  const request=useCallback(async(path,opts)=>{
    const r=await fetch(`${API}${path}`,opts);
    if(!r.ok)throw new Error(`${r.status} ${r.statusText}`);
    return r.json();
  },[]);

  const loadAll=useCallback(async({silent=false}={})=>{
    const prev=latestRef.current;
    if(!silent)setLoading(true);
    setRefreshing(true);setError('');
    try{
      const res=await Promise.allSettled([
        request('/api/dashboard'),
        request('/api/news?limit=200&unique=true'),
        request('/api/stats'),
        request('/api/categories'),
        request('/api/source-stats'),
        request('/api/source-health'),
        request('/api/ingestion-runs?limit=20'),
      ]);
      const ok=r=>r.status==='fulfilled'?r.value:null;
      const[dR,nR,sR,cR,ssR,shR,rR]=res;
      setDashboard(ok(dR)||prev.dashboard);
      const arts=ok(nR);setNews(dedupe(safeArr(Array.isArray(arts)?arts:arts?.results||[])).map(mapArticle));
      setStats(ok(sR)||prev.stats);
      setCategories(safeArr(ok(cR)));
      setSourceStats(safeArr(ok(ssR)));
      setSourceHealth(safeArr(ok(shR)));
      setRuns(safeArr(ok(rR)));
      setLastUpdated(new Date());
      const fails=res.filter(r=>r.status==='rejected').map(r=>r.reason?.message).filter(Boolean);
      if(fails.length)setError(`Partial load — ${fails.slice(0,2).join(' | ')}`);
    }catch(e){setError(e.message||'Load failed');}
    finally{setLoading(false);setRefreshing(false);}
  },[request]);

  useEffect(()=>{loadAll();},[loadAll]);

  const evtRef=useRef(null);
  useEffect(()=>{
    if(evtRef.current)evtRef.current.close();
    const src=new EventSource(`${API}/api/events`);
    evtRef.current=src;
    src.onopen=()=>setSseState('connected');
    src.onerror=()=>setSseState(p=>p==='connected'?'reconnecting':'disconnected');
    src.addEventListener('dashboard',()=>{setSseState('connected');loadAll({silent:true}).catch(()=>{});});
    return()=>src.close();
  },[loadAll]);

  const loadUniverse=useCallback(async()=>{try{const d=await request('/api/stocks/universe');setUniverse(safeArr(d));}catch(e){console.warn('universe',e);}},[request]);
  const loadQuotes=useCallback(async(syms)=>{if(!syms?.length)return;try{const d=await request(`/api/stocks/quotes?symbols=${encodeURIComponent(syms.slice(0,50).join(','))}`);setQuotes(q=>({...q,...d}));}catch(e){console.warn('quotes',e);}},[request]);
  const loadSignals=useCallback(async()=>{setSigLoading(true);try{const d=await request('/api/stocks/signals?limit=50');setSignals(safeArr(d.signals||d));}catch(e){setError('Signals: '+e.message);}finally{setSigLoading(false);}},[request]);
  const loadFinScores=useCallback(async()=>{setFinLoading(true);try{const d=await request('/api/stocks/finance-scores?limit=50');setFinScores(safeArr(d));}catch(e){setError('Finance: '+e.message);}finally{setFinLoading(false);}},[request]);
  const loadDetail=useCallback(async(sym)=>{setDetLoading(true);setStockDetail(null);try{const d=await request(`/api/stocks/detail/${sym}`);setStockDetail(d);}catch(e){setError('Detail: '+e.message);}finally{setDetLoading(false);}},[request]);

  useEffect(()=>{if(active==='stocks'&&universe.length===0)loadUniverse();},[active,universe.length,loadUniverse]);
  useEffect(()=>{if(active==='stocks'&&universe.length>0)loadQuotes(universe.slice(0,50).map(s=>s.symbol));},[active,universe,loadQuotes]);
  useEffect(()=>{if(active==='signals'&&signals.length===0)loadSignals();},[active,signals.length,loadSignals]);
  useEffect(()=>{if(active==='finance'&&finScores.length===0)loadFinScores();},[active,finScores.length,loadFinScores]);

  function openStock(sym){setSelectedStock(sym);loadDetail(sym);setActive('detail');}

  async function refreshNow(){
    setRefreshing(true);setError('');
    try{await request('/api/admin/ingest',{method:'POST'}).catch(e=>setError('Ingest: '+e.message));await loadAll({silent:true});}
    finally{setRefreshing(false);}
  }
  async function runSearch(e){
    e.preventDefault();const q=filters.query.trim();
    if(!q){setRawSearch(null);await loadAll({silent:true});setActive('news');return;}
    setLoading(true);setError('');
    try{const d=await request(`/api/news/search?q=${encodeURIComponent(q)}&limit=${filters.limit}&live=${filters.liveIfEmpty}`);setRawSearch({query:q,count:d?.count??0});setNews(dedupe(safeArr(d?.results)).map(mapArticle));setActive('news');}
    catch(e){setError(e.message||'Search failed');}
    finally{setLoading(false);}
  }
  function clearFilters(){setFilters({query:'',category:'all',sort:'latest',limit:200,liveIfEmpty:true});setRawSearch(null);loadAll({silent:true}).catch(()=>{});}

  const articles=useMemo(()=>{let rows=[...news];if(filters.category!=='all')rows=rows.filter(a=>a.category===filters.category);rows.sort((a,b)=>filters.sort==='oldest'?(getDate(a.publishedAt||a.fetchedAt)||0)-(getDate(b.publishedAt||b.fetchedAt)||0):(getDate(b.publishedAt||b.fetchedAt)||0)-(getDate(a.publishedAt||a.fetchedAt)||0));return rows;},[news,filters.category,filters.sort]);
  const impacts=useMemo(()=>safeArr(dashboard.top_impacts).map(i=>({id:i?.id??Math.random(),company:asText(i?.company_name,'?'),sector:asText(i?.sector,'?'),score:toNum(i?.score)})),[dashboard.top_impacts]);
  const sentRows=useMemo(()=>safeArr(dashboard.sentiment_counts).map(i=>({label:asText(i.label,'?'),count:toNum(i.count)})),[dashboard.sentiment_counts]);
  const lastRun=runs[0]||null;
  const filteredStocks=useMemo(()=>{let rows=safeArr(universe);if(stockSearch)rows=rows.filter(s=>(s.symbol+s.name+s.sector).toLowerCase().includes(stockSearch.toLowerCase()));return rows;},[universe,stockSearch]);
  const sigCounts=useMemo(()=>({BULLISH:signals.filter(s=>s.signal==='BULLISH').length,NEUTRAL:signals.filter(s=>s.signal==='NEUTRAL').length,BEARISH:signals.filter(s=>s.signal==='BEARISH').length}),[signals]);
  const filteredSignals=useMemo(()=>{let rows=safeArr(signals);if(sigTab!=='ALL')rows=rows.filter(s=>s.signal===sigTab);if(stockSearch)rows=rows.filter(s=>(s.symbol+s.name+(s.sector||'')).toLowerCase().includes(stockSearch.toLowerCase()));return rows;},[signals,sigTab,stockSearch]);
  const currentNav=NAV_ITEMS.find(n=>n.id===active)||NAV_ITEMS[0];

  const kpis=[
    {label:'Raw Articles',value:toNum(stats.articles),icon:Database,tone:'info',helper:'stored evidence'},
    {label:'Unique Stories',value:articles.length,icon:Newspaper,tone:'success',helper:'UI de-duped'},
    {label:'Stocks Tracked',value:universe.length||250,icon:Building2,tone:'info',helper:'Nifty 250'},
    {label:'Bullish Signals',value:sigCounts.BULLISH,icon:TrendingUp,tone:'success',helper:`${sigCounts.BEARISH} bearish`},
    {label:'IPO Events',value:toNum(stats.ipo_events,safeArr(dashboard.ipo_events).length),icon:CalendarClock,tone:'info',helper:'detected'},
    {label:'Trade Events',value:toNum(stats.trade_events,safeArr(dashboard.trade_events).length),icon:Globe2,tone:'info',helper:'global signals'},
    {label:'Healthy Sources',value:`${safeArr(sourceHealth).filter(s=>s.status==='healthy').length}/${sourceHealth.length||0}`,icon:ShieldCheck,tone:sourceHealth.some(s=>s.status!=='healthy')?'warning':'success',helper:'source health'},
    {label:'Last Ingestion',value:lastRun?`${lastRun.inserted||0}`:'0',icon:RefreshCcw,tone:statusTone(lastRun?.status),helper:lastRun?`${lastRun.mode} ${timeAgo(lastRun.finished_at||lastRun.started_at)}`:'no run'},
  ];

  return(
    <div className="app-shell">
      <aside className={`sidebar ${sidebarOpen?'open':''}`}>
        <div className="brand">
          <div className="brand-mark"><TrendingUp size={24}/></div>
          <div><strong>Market Intel</strong><span>Indian Financial News</span></div>
          <button className="icon-button close-button" onClick={()=>setSidebar(false)}><X size={18}/></button>
        </div>
        <nav className="nav-list">
          {NAV_ITEMS.map(({id,label,icon:Icon})=>(<button key={id} className={active===id?'active':''} onClick={()=>{setActive(id);setSidebar(false);if(id!=='detail')setSelectedStock(null);}}><Icon size={18}/><span>{label}</span></button>))}
        </nav>
        <div className="scheduler-card"><RefreshCcw size={17}/><div><strong>Auto ingestion</strong><span>APScheduler · yfinance · sklearn</span></div></div>
      </aside>

      <main className="main-content">
        <header className="top-header">
          <button className="icon-button mobile-menu" onClick={()=>setSidebar(true)}><Menu/></button>
          <div>
            <span className="eyebrow">Python 3.12 · React · yfinance · Finance Model 1 · Signal Model 2</span>
            <h1>{active==='detail'&&selectedStock?`${selectedStock} — Detail`:currentNav.label}</h1>
            <p>Nifty 250 intelligence: real-time quotes, Finance Model 1 scores, ML trade signals, CNBC TV18 · NDTV Profit · Zee Business · Moneycontrol news.</p>
          </div>
          <div className="header-actions">
            <LiveIndicator state={sseState}/>
            <button className="secondary-button" onClick={refreshNow} disabled={refreshing}><RefreshCcw size={16}/>{refreshing?'Refreshing…':'Refresh'}</button>
          </div>
        </header>

        <ErrorBanner message={error} onRetry={refreshNow}/>

        {active!=='detail'&&(
          <form className="control-bar" onSubmit={runSearch}>
            <div className="control-search"><Search size={18}/><input value={filters.query} onChange={e=>setFilters(p=>({...p,query:e.target.value}))} placeholder="Search company, symbol, earnings, IPO, tariff…"/></div>
            <label><Filter size={16}/>Category<select value={filters.category} onChange={e=>setFilters(p=>({...p,category:e.target.value}))}><option value="all">All</option>{safeArr(categories).map(c=><option key={c.category} value={c.category}>{c.category}</option>)}</select></label>
            <label><SlidersHorizontal size={16}/>Sort<select value={filters.sort} onChange={e=>setFilters(p=>({...p,sort:e.target.value}))}><option value="latest">Latest</option><option value="oldest">Oldest</option></select></label>
            <label className="checkbox"><input type="checkbox" checked={filters.liveIfEmpty} onChange={e=>setFilters(p=>({...p,liveIfEmpty:e.target.checked}))}/> Live if empty</label>
            <button className="primary-button" type="submit"><Search size={16}/>Search</button>
            <button className="ghost-button" type="button" onClick={clearFilters}>Clear</button>
          </form>
        )}

        <div className="meta-strip">
          <span>IST: {lastUpdated?fmtDate(lastUpdated):'Not loaded'}</span>
          {rawSearch?<span>Search «{rawSearch.query}» — {rawSearch.count} results</span>:<span>Live feed · Refresh triggers ingestion</span>}
        </div>

        {loading&&!articles.length&&active==='dashboard'&&<LoadingBlock/>}

        <section className="kpi-grid">{kpis.map(k=><KpiCard key={k.label} {...k}/>)}</section>

        {active==='dashboard'&&<DashboardView sentRows={sentRows} impacts={impacts} articles={articles} sourceHealth={sourceHealth} runs={runs} signals={signals} onStockClick={openStock}/>}
        {active==='news'&&<Card title={`Live News (${articles.length} stories)`} icon={Newspaper}>{articles.length?<div className="news-grid">{articles.map(a=><NewsCard key={a.id} item={a}/>)}</div>:<EmptyState title="No news"/>}</Card>}
        {active==='stocks'&&<StocksView stocks={filteredStocks} quotes={quotes} search={stockSearch} setSearch={setStockSearch} loading={universe.length===0} onSelect={openStock} onRefreshQuotes={()=>loadQuotes(filteredStocks.slice(0,50).map(s=>s.symbol))}/>}
        {active==='signals'&&<SignalsView signals={filteredSignals} tab={sigTab} setTab={setSigTab} counts={sigCounts} loading={sigLoading} search={stockSearch} setSearch={setStockSearch} onSelect={openStock} onRefresh={loadSignals}/>}
        {active==='finance'&&<FinanceView scores={finScores} loading={finLoading} onSelect={openStock} onRefresh={loadFinScores}/>}
        {active==='sentiment'&&<SentimentView sentRows={sentRows} impacts={impacts}/>}
        {active==='sectors'&&<SectorView impacts={impacts}/>}
        {active==='ipo'&&<Card title="IPO Monitor" icon={CalendarClock}>{safeArr(dashboard.ipo_events).length?<div className="event-list">{safeArr(dashboard.ipo_events).map((e,i)=><div key={i} className="event-row"><div><strong>{e.company_name}</strong><span>{fmtDate(e.event_date)}</span></div><Pill tone="warning">{e.event_type}</Pill></div>)}</div>:<EmptyState title="No IPO events"/>}</Card>}
        {active==='trade'&&<Card title="Trade & Global Events" icon={Globe2}>{safeArr(dashboard.trade_events).length?<div className="event-list">{safeArr(dashboard.trade_events).map((e,i)=><div key={i} className="event-row"><div><strong>{e.event_type}</strong><span>{safeArr(e.affected_sectors).join(', ')}</span></div><Pill tone={statusTone(e.direction)}>{e.direction}</Pill></div>)}</div>:<EmptyState title="No trade events"/>}</Card>}
        {active==='sources'&&<SourcesView sourceHealth={sourceHealth} sourceStats={sourceStats}/>}
        {active==='runs'&&<Card title="Ingestion Runs" icon={RefreshCcw}>{runs.length?<div className="table-wrap"><table><thead><tr><th>ID</th><th>Mode</th><th>Status</th><th>Inserted</th><th>Started (IST)</th><th>Finished (IST)</th></tr></thead><tbody>{runs.map(r=><tr key={r.id}><td>{r.id}</td><td>{r.mode}</td><td><Pill tone={statusTone(r.status)}>{r.status}</Pill></td><td>{r.inserted}</td><td>{fmtDate(r.started_at)}</td><td>{fmtDate(r.finished_at)}</td></tr>)}</tbody></table></div>:<EmptyState title="No runs"/>}</Card>}
        {active==='detail'&&<StockDetailView symbol={selectedStock} detail={stockDetail} loading={detLoading} onBack={()=>setActive('stocks')}/>}
      </main>
    </div>
  );
}

function DashboardView({sentRows,impacts,articles,sourceHealth,runs,signals,onStockClick}){
  const topBullish=safeArr(signals).filter(s=>s.signal==='BULLISH').slice(0,6);
  return(
    <div className="dashboard-grid">
      <Card title="Sentiment Mix" icon={Activity}>{sentRows.length?<ResponsiveContainer width="100%" height={220}><PieChart><Pie data={sentRows} dataKey="count" nameKey="label" innerRadius={55} outerRadius={85}>{sentRows.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer>:<EmptyState title="No sentiment"/>}</Card>
      <Card title="Impact Leaders" icon={TrendingUp}>{impacts.length?<ResponsiveContainer width="100%" height={220}><BarChart data={impacts.slice(0,10)}><CartesianGrid vertical={false} stroke="#1f3b5f"/><XAxis dataKey="company" hide/><YAxis/><Tooltip/><Bar dataKey="score" fill="#60a5fa" radius={[8,8,0,0]}/></BarChart></ResponsiveContainer>:<EmptyState title="No impact scores"/>}</Card>
      <Card title="Latest Stories" icon={Newspaper} className="wide-card"><div className="compact-news-grid">{articles.slice(0,6).map(a=><NewsCard key={a.id} item={a}/>)}</div></Card>
      {topBullish.length>0&&<Card title="Top Bullish Signals" icon={TrendingUp} className="wide-card"><div className="signal-grid">{topBullish.map(s=><SignalCard key={s.symbol} signal={s} onClick={onStockClick}/>)}</div></Card>}
      <Card title="Snapshot" icon={Settings}><div className="status-list"><StatusLine label="Healthy sources" value={sourceHealth.filter(x=>x.status==='healthy').length} tone="success"/><StatusLine label="Last inserted" value={runs[0]?.inserted??0} tone={statusTone(runs[0]?.status)}/><StatusLine label="Bearish signals" value={safeArr(signals).filter(s=>s.signal==='BEARISH').length} tone="danger"/></div></Card>
    </div>
  );
}

function StocksView({stocks,quotes,search,setSearch,loading,onSelect,onRefreshQuotes}){
  return(<div>
    <div className="filter-bar">
      <div className="search-box"><Search size={16}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search symbol, name, sector…"/></div>
      <button className="secondary-button" onClick={onRefreshQuotes}><RefreshCcw size={15}/>Refresh Quotes</button>
      <span style={{color:'#9fb0c7',fontSize:13}}>{stocks.length} stocks</span>
    </div>
    {loading?<LoadingBlock label="Loading Nifty 250…"/>:stocks.length?<div className="stock-grid">{stocks.slice(0,100).map(s=><StockCard key={s.symbol} stock={s} quote={quotes[s.symbol]} onClick={onSelect}/>)}</div>:<EmptyState title="No stocks" detail="Run: python -m app.db.init_db"/>}
  </div>);
}

function SignalsView({signals,tab,setTab,counts,loading,search,setSearch,onSelect,onRefresh}){
  const tabs=['ALL','BULLISH','NEUTRAL','BEARISH'];
  return(<div>
    <div className="filter-bar">
      <div className="tabs">{tabs.map(t=><button key={t} className={`tab-btn${tab===t?' active':''}`} onClick={()=>setTab(t)}>{t}{t!=='ALL'&&` (${counts[t]||0})`}</button>)}</div>
      <div className="search-box" style={{maxWidth:240}}><Search size={15}/><input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Filter symbol…"/></div>
      <button className="secondary-button" onClick={onRefresh} disabled={loading}><RefreshCcw size={15}/>{loading?'Generating…':'Regenerate'}</button>
    </div>
    {loading?<LoadingBlock label="Running Finance Model 1 + Signal Model 2 for 50 stocks…"/>:signals.length?<div className="signal-grid">{signals.map(s=><SignalCard key={s.symbol} signal={s} onClick={onSelect}/>)}</div>:<EmptyState title="No signals" detail="Click Regenerate to run the signal model."/>}
  </div>);
}

function FinanceView({scores,loading,onSelect,onRefresh}){
  if(loading)return<LoadingBlock label="Computing Finance Model 1 scores…"/>;
  return(<Card title="Finance Model 1 — All Stocks" icon={Award} actions={<button className="secondary-button" onClick={onRefresh}><RefreshCcw size={15}/>Refresh</button>}>
    {scores.length?<div className="table-wrap"><table><thead><tr><th>Symbol</th><th>Name</th><th>Sector</th><th>Finance Score</th><th>Tier</th><th>Earnings</th><th>Holding</th><th>Sentiment</th><th>Technical</th></tr></thead>
    <tbody>{scores.map(s=>(<tr key={s.symbol} onClick={()=>onSelect(s.symbol)} style={{cursor:'pointer'}}>
      <td><strong style={{color:'#60a5fa'}}>{s.symbol}</strong></td>
      <td>{asText(s.name,'').slice(0,22)}</td>
      <td><span className="sector-tag">{s.sector}</span></td>
      <td><strong style={{color:pillarColor(toNum(s.finance_score,50))}}>{fmtNum(s.finance_score,1)}</strong></td>
      <td><span className={sigBadge(s.signal_tier)}>{s.signal_tier}</span></td>
      <td>{fmtNum(s.pillar_scores?.earnings,0)}</td>
      <td>{fmtNum(s.pillar_scores?.holding,0)}</td>
      <td>{fmtNum(s.pillar_scores?.sentiment,0)}</td>
      <td>{fmtNum(s.pillar_scores?.technical,0)}</td>
    </tr>))}</tbody></table></div>:<EmptyState title="No scores" detail="Click Refresh to compute Finance Model 1 scores."/>}
  </Card>);
}

function StockDetailView({symbol,detail,loading,onBack}){
  const [tab,setTab]=useState('overview');
  if(loading)return<div><button className="secondary-button" onClick={onBack} style={{marginBottom:14}}><ArrowLeft size={16}/>Back</button><LoadingBlock label={`Loading ${symbol}…`}/></div>;
  if(!detail)return<div><button className="secondary-button" onClick={onBack}><ArrowLeft size={16}/>Back</button><EmptyState title="No detail"/></div>;
  const {stock_info,quote,finance_score,signal,price_history,holding_data,recent_articles}=detail;
  const q=quote||{};const fs=finance_score||{};const sig=signal||{};const ps=fs.pillar_scores||{};const pr=sig.price_range||{};
  const hist=safeArr(price_history).map(h=>({...h,close:toNum(h.close)}));
  return(<div>
    <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:14,flexWrap:'wrap'}}>
      <button className="secondary-button" onClick={onBack}><ArrowLeft size={16}/>Back</button>
      <h2 style={{margin:0}}>{symbol} — {asText(stock_info?.name,'').slice(0,30)}</h2>
      <span className="sector-tag">{stock_info?.sector}</span>
      {sig.signal&&<span className={sigBadge(sig.signal)}>{sig.signal}</span>}
    </div>
    <div className="tabs">
      {['overview','price','earnings','holdings','events','news'].map(t=><button key={t} className={`tab-btn${tab===t?' active':''}`} onClick={()=>setTab(t)}>{t}</button>)}
    </div>
    {tab==='overview'&&(<div className="detail-grid">
      <Card title="Live Quote" icon={DollarSign}><div className="status-list">
        <StatusLine label="Price" value={fmtPrice(q.price)}/><StatusLine label="Change" value={<span className={changeTone(q.change_pct)}>{fmtPct(q.change_pct)}</span>}/>
        <StatusLine label="Day High" value={fmtPrice(q.day_high)}/><StatusLine label="Day Low" value={fmtPrice(q.day_low)}/>
        <StatusLine label="52W High" value={fmtPrice(q.week52_high)}/><StatusLine label="52W Low" value={fmtPrice(q.week52_low)}/>
        <StatusLine label="P/E" value={fmtNum(q.pe_ratio,2)}/><StatusLine label="EPS" value={fmtNum(q.eps,2)}/>
        <StatusLine label="Beta" value={fmtNum(q.beta,2)}/><StatusLine label="Mkt Cap" value={q.market_cap?`₹${(q.market_cap/1e7).toFixed(0)}Cr`:'—'}/>
      </div></Card>
      <Card title="Finance Score" icon={Award}><div style={{textAlign:'center',marginBottom:14}}><div className="score-ring"><span className="score-num" style={{color:pillarColor(toNum(fs.finance_score,50))}}>{fmtNum(fs.finance_score,1)}</span><span className="score-label">{fs.signal_tier}</span></div></div><div className="signal-pillars">{Object.entries(ps).map(([k,v])=><PillarBar key={k} name={k} score={toNum(v,50)}/>)}</div></Card>
      <Card title="Trade Signal" icon={Zap}><div className="status-list"><StatusLine label="Signal" value={<span className={sigBadge(sig.signal)}>{sig.signal||'—'}</span>}/><StatusLine label="Confidence" value={`${fmtNum(sig.confidence,1)}%`}/></div>
        {pr.current_price&&<div className="price-range-box" style={{marginTop:12}}>
          <div className="price-range-row"><span>Current</span><strong>{fmtPrice(pr.current_price)}</strong></div>
          <div className="price-range-row"><span>Target Low</span><strong>{fmtPrice(pr.target_low)}</strong></div>
          <div className="price-range-row"><span>Target High</span><strong>{fmtPrice(pr.target_high)}</strong></div>
          <div className="price-range-row"><span>Horizon</span><strong>{pr.horizon_days||20} trading days</strong></div>
          <div className="price-range-row"><span>ATR %</span><strong>{fmtNum(pr.atr_pct,2)}%</strong></div>
        </div>}
        {sig.class_proba&&<div style={{marginTop:12,display:'grid',gap:6}}>{Object.entries(sig.class_proba).map(([label,pct])=><div key={label} style={{display:'flex',alignItems:'center',gap:8}}><span style={{width:70,fontSize:12,color:'#9fb0c7'}}>{label}</span><div style={{flex:1,height:8,background:'#102241',borderRadius:999,overflow:'hidden'}}><div style={{width:`${pct}%`,height:'100%',background:SIGNAL_COLORS[label],borderRadius:999}}/></div><span style={{width:38,fontSize:12,textAlign:'right'}}>{fmtNum(pct,1)}%</span></div>)}</div>}
      </Card>
      <Card title="Holdings Summary" icon={Users}>{holding_data&&Object.keys(holding_data).length?<div className="status-list"><StatusLine label="Promoter %" value={`${fmtNum(holding_data.promoter_pct!=null?holding_data.promoter_pct*100:null,2)}%`}/><StatusLine label="Institution %" value={`${fmtNum(holding_data.institution_pct!=null?holding_data.institution_pct*100:null,2)}%`}/></div>:<EmptyState title="Holdings not available" detail="yfinance data pending"/>}</Card>
    </div>)}
    {tab==='price'&&<Card title="Price History (3 months)" icon={BarChart3}>{hist.length?<ResponsiveContainer width="100%" height={320}><AreaChart data={hist}><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#60a5fa" stopOpacity={0.3}/><stop offset="95%" stopColor="#60a5fa" stopOpacity={0}/></linearGradient></defs><CartesianGrid stroke="#1f3b5f" vertical={false}/><XAxis dataKey="date" tick={{fontSize:11}} interval="preserveStartEnd"/><YAxis tick={{fontSize:11}} domain={['auto','auto']}/><Tooltip formatter={v=>`₹${toNum(v).toFixed(2)}`}/><Area type="monotone" dataKey="close" stroke="#60a5fa" fill="url(#cg)" strokeWidth={2} dot={false}/>{pr.target_low&&<ReferenceLine y={pr.target_low} stroke="#ef4444" strokeDasharray="4 4"/>}{pr.target_high&&<ReferenceLine y={pr.target_high} stroke="#22c55e" strokeDasharray="4 4"/>}</AreaChart></ResponsiveContainer>:<EmptyState title="No price history"/>}</Card>}
    {tab==='earnings'&&<EarningsTab symbol={symbol}/>}
    {tab==='holdings'&&<HoldingsTab symbol={symbol}/>}
    {tab==='events'&&<EventsTab symbol={symbol}/>}
    {tab==='news'&&<Card title={`News — ${symbol}`} icon={Newspaper}>{safeArr(recent_articles).length?<div className="news-grid">{safeArr(recent_articles).map(a=><NewsCard key={a.id} item={mapArticle(a)}/>)}</div>:<EmptyState title="No linked news"/>}</Card>}
  </div>);
}

function EarningsTab({symbol}){
  const [data,setData]=useState(null);const [loading,setLoading]=useState(true);
  useEffect(()=>{fetch(`${API}/api/stocks/earnings/${symbol}`).then(r=>r.json()).then(setData).catch(()=>setData({})).finally(()=>setLoading(false));},[symbol]);
  if(loading)return<LoadingBlock label="Loading earnings…"/>;
  const rows=safeArr(data?.db_records).concat(safeArr(data?.yfinance_quarterly));
  return<Card title={`Earnings — ${symbol}`} icon={BarChart3}>{rows.length?<div className="table-wrap"><table><thead><tr><th>Quarter</th><th>Revenue ₹Cr</th><th>Rev YoY%</th><th>Net Profit ₹Cr</th><th>Profit YoY%</th><th>Net Margin</th><th>EPS</th><th>Beat</th></tr></thead><tbody>{rows.map((r,i)=><tr key={i}><td>{asText(r.quarter_label||r.quarter,'—')}</td><td>{fmtNum(r.revenue_cr||r.revenue,0)}</td><td className={changeTone(r.revenue_yoy_pct)}>{fmtPct(r.revenue_yoy_pct)}</td><td>{fmtNum(r.net_profit_cr||r.earnings,0)}</td><td className={changeTone(r.net_profit_yoy_pct)}>{fmtPct(r.net_profit_yoy_pct)}</td><td>{fmtNum(r.net_margin_pct,1)}%</td><td>{fmtNum(r.eps,2)}</td><td style={{color:r.beat_estimate===true?'#22c55e':r.beat_estimate===false?'#ef4444':'inherit'}}>{r.beat_estimate===true?'✓':r.beat_estimate===false?'✗':'—'}</td></tr>)}</tbody></table></div>:<EmptyState title="No earnings data" detail="Auto-extracted from results articles or add via POST /api/stocks/earnings/{symbol}"/>}</Card>;
}

function HoldingsTab({symbol}){
  const [data,setData]=useState(null);const [loading,setLoading]=useState(true);
  useEffect(()=>{fetch(`${API}/api/stocks/holdings/${symbol}`).then(r=>r.json()).then(setData).catch(()=>setData({})).finally(()=>setLoading(false));},[symbol]);
  if(loading)return<LoadingBlock label="Loading holdings…"/>;
  const rows=safeArr(data?.db_records);const yf=data?.yfinance||{};
  return<div>
    {rows.length?<Card title={`Shareholding — ${symbol}`} icon={Users}><div className="table-wrap"><table><thead><tr><th>Quarter</th><th>Promoter%</th><th>Pledged%</th><th>FII%</th><th>DII%</th><th>MF%</th><th>Public%</th><th>FII Chg</th></tr></thead><tbody>{rows.map((r,i)=><tr key={i}><td>{asText(r.quarter_label,'—')}</td><td>{fmtNum(r.promoter_pct,2)}%</td><td style={{color:toNum(r.pledged_pct)>20?'#ef4444':'#22c55e'}}>{fmtNum(r.pledged_pct,2)}%</td><td>{fmtNum(r.fii_pct,2)}%</td><td>{fmtNum(r.dii_pct,2)}%</td><td>{fmtNum(r.mutual_fund_pct,2)}%</td><td>{fmtNum(r.public_pct,2)}%</td><td className={changeTone(r.fii_change_pct)}>{fmtPct(r.fii_change_pct)}</td></tr>)}</tbody></table></div></Card>:null}
    {yf&&Object.keys(yf).length?<Card title="yfinance Institutional Holders" icon={Users}>{safeArr(yf.institutional).length?<div className="table-wrap"><table><thead><tr><th>Holder</th><th>% Out</th></tr></thead><tbody>{safeArr(yf.institutional).slice(0,8).map((h,i)=><tr key={i}><td>{asText(h.Holder||h.holder,'—')}</td><td>{fmtNum(h['% Out']||h.pctOut,2)}%</td></tr>)}</tbody></table></div>:null}{yf.promoter_pct!=null&&<div className="status-list" style={{marginTop:10}}><StatusLine label="Promoter (yf)" value={`${fmtNum(yf.promoter_pct*100,2)}%`}/><StatusLine label="Institution (yf)" value={`${fmtNum(yf.institution_pct*100,2)}%`}/></div>}</Card>:null}
    {!rows.length&&(!yf||!Object.keys(yf).length)&&<EmptyState title="No holding data" detail="Holdings auto-extracted or add via POST /api/stocks/holdings/{symbol}"/>}
  </div>;
}

function EventsTab({symbol}){
  const [data,setData]=useState(null);const [loading,setLoading]=useState(true);
  useEffect(()=>{fetch(`${API}/api/stocks/events/${symbol}?days=180`).then(r=>r.json()).then(setData).catch(()=>setData([])).finally(()=>setLoading(false));},[symbol]);
  if(loading)return<LoadingBlock label="Loading events…"/>;
  const rows=safeArr(data);
  const typeColor=t=>{const v=(t||'').toLowerCase();if(['dividend','bonus','order','buyback'].some(x=>v.includes(x)))return '#22c55e';if(['sell','fraud','downgrade','litigation'].some(x=>v.includes(x)))return '#ef4444';return '#60a5fa';};
  return<Card title={`Events — ${symbol} (180d)`} icon={CalendarClock}>{rows.length?<div className="event-list">{rows.map((r,i)=><div key={i} className="event-row"><div><strong style={{color:typeColor(r.event_type)}}>{r.event_type}</strong><span>{asText(r.description,'').slice(0,100)}</span><span style={{fontSize:12,color:'#9fb0c7'}}>{fmtDate(r.event_date)}</span></div>{r.amount&&<Pill tone="info">₹{r.amount}</Pill>}{r.ratio&&<Pill tone="warning">{r.ratio}</Pill>}</div>)}</div>:<EmptyState title="No events" detail="Events auto-extracted from news or add via POST /api/stocks/events/{symbol}"/>}</Card>;
}

function SentimentView({sentRows,impacts}){
  const trend=impacts.slice(0,20).map((it,i)=>({name:`#${i+1}`,score:it.score}));
  return<div className="dashboard-grid">
    <Card title="Sentiment Distribution" icon={Activity}>{sentRows.length?<ResponsiveContainer width="100%" height={280}><PieChart><Pie data={sentRows} dataKey="count" nameKey="label" innerRadius={70} outerRadius={110}>{sentRows.map((_,i)=><Cell key={i} fill={CHART_COLORS[i%CHART_COLORS.length]}/>)}</Pie><Tooltip/></PieChart></ResponsiveContainer>:<EmptyState title="No sentiment"/>}</Card>
    <Card title="Impact Score Curve" icon={TrendingUp}>{trend.length?<ResponsiveContainer width="100%" height={280}><LineChart data={trend}><CartesianGrid stroke="#1f3b5f" vertical={false}/><XAxis dataKey="name"/><YAxis/><Tooltip/><Line type="monotone" dataKey="score" stroke="#22c55e" strokeWidth={3} dot={false}/></LineChart></ResponsiveContainer>:<EmptyState title="No trend"/>}</Card>
  </div>;
}

function SectorView({impacts}){
  const sectors=useMemo(()=>{const m=new Map();for(const it of impacts){const k=it.sector||'?';const ex=m.get(k)||{sector:k,count:0,maxImpact:0,avgImpact:0};ex.count++;ex.avgImpact+=it.score;ex.maxImpact=Math.max(ex.maxImpact,it.score);m.set(k,ex);}return[...m.values()].map(r=>({...r,avgImpact:r.count?Math.round(r.avgImpact/r.count):0})).sort((a,b)=>b.maxImpact-a.maxImpact);},[impacts]);
  return<Card title="Sector Intelligence" icon={Layers3}>{sectors.length?<div className="sector-grid">{sectors.map(r=><div key={r.sector} className="sector-card"><span>{r.sector}</span><strong>{r.maxImpact}</strong><small>{r.count} records · avg {r.avgImpact}</small><div className="progress"><i style={{width:`${Math.min(100,r.maxImpact)}%`}}/></div></div>)}</div>:<EmptyState title="No sector data"/>}</Card>;
}

function SourcesView({sourceHealth,sourceStats}){
  const artMap=new Map(safeArr(sourceStats).map(x=>[x.source,toNum(x.articles)]));
  return<Card title="Source Health" icon={Database}>{sourceHealth.length?<div className="source-grid">{sourceHealth.map(r=><div key={r.id} className="source-card"><div><strong>{r.source}</strong><Pill tone={statusTone(r.status)}>{r.status}</Pill></div><span>Type: {r.source_type}</span><span>Articles: {artMap.get(r.source)??r.articles??0}</span><span>Next: {fmtDate(r.next_run_at)}</span><span>Last OK: {fmtDate(r.last_success_at)}</span>{r.last_error&&<small>{r.last_error?.slice(0,80)}</small>}</div>)}</div>:<EmptyState title="No sources"/>}</Card>;
}

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error('Root element #root was not found in index.html');
}

createRoot(rootElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);

