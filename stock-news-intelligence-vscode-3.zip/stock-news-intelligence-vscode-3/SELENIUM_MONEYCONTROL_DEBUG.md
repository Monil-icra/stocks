# Selenium Moneycontrol Fallback

## Why this exists

Moneycontrol sitemap sometimes returns 403 to `httpx`/curl from the backend, even when the URL opens in a browser. This connector adds a Selenium fallback that opens the public sitemap in Chrome and returns page text/source to the existing sitemap parser.

## Important compliance note

This does not use personal browser cookies, credentials, CAPTCHA solving, or proxy bypass. If Moneycontrol blocks Selenium too, the source remains blocked. Review site terms, robots policy, and internal compliance before production use.

## Settings

```env
ENABLE_SELENIUM_FALLBACK=true
SELENIUM_HEADLESS=true
SELENIUM_START_ON_APP_START=true
SELENIUM_PAGE_LOAD_TIMEOUT_SECONDS=30
SELENIUM_WAIT_SECONDS=12
SELENIUM_LOG_PATH=./logs/selenium_moneycontrol.log
```

## Debug commands

```powershell
curl http://127.0.0.1:8000/api/debug/selenium-moneycontrol
curl http://127.0.0.1:8000/api/debug/html-source/SOURCE_ID
curl -X POST http://127.0.0.1:8000/api/admin/ingest
```

## Log file

`backend/logs/selenium_moneycontrol.log`

The log records import checks, driver startup, page source length, body text length, whether `<urlset>` was found, and exceptions.

## Requirements

- Google Chrome installed on the machine.
- `selenium>=4.21.0` installed from `requirements-py314.txt`.
- Selenium Manager can locate or download a compatible ChromeDriver.
