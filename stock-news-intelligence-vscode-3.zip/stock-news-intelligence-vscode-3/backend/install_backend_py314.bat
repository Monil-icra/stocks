@echo off
python -m pip install --upgrade pip setuptools wheel
pip install -r requirements-py314.txt
copy .env.example .env
python -m app.db.init_db
echo Backend setup complete.
