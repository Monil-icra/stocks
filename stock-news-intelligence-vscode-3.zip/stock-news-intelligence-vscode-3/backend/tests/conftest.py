"""pytest configuration for the stock-news-intelligence backend.

Adds the backend/ directory to sys.path so that ``import app.services.cache``
and all other ``app.*`` imports resolve correctly when pytest is invoked from
any working directory.

Usage (from the backend/ directory):
    pytest tests/ -v --tb=short

Usage (from the project root):
    pytest backend/tests/ -v --tb=short
"""
import sys
from pathlib import Path

# Resolve to: <repo>/backend/
_backend_root = Path(__file__).resolve().parent.parent
if str(_backend_root) not in sys.path:
    sys.path.insert(0, str(_backend_root))
