"""
Tests for Indian Stock Market News Intelligence platform.

Run from backend/ directory:
    pytest tests/ -v --tb=short

Each test is self-contained and uses in-memory SQLite so no external
services (Redis, Chrome, Moneycontrol) are required.
"""
from __future__ import annotations

import hashlib
import json
import types
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest
from fastapi.encoders import jsonable_encoder
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

# ── Existing service imports ──────────────────────────────────────────────────
from app.services.classifier import classify, ipo_events, trade_event
from app.services.company import detect_companies
from app.services.impact import calculate

# ── DB imports ────────────────────────────────────────────────────────────────
from app.db.models import (
    Article,
    Base,
    IngestionLock,
    IngestionRun,
    RSSSource,
)


# ═══════════════════════════════════════════════════════════════════════════════
# Helpers
# ═══════════════════════════════════════════════════════════════════════════════

def _in_memory_db():
    engine = create_engine(
        'sqlite:///:memory:',
        connect_args={'check_same_thread': False},
        future=True,
    )
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
    return Session()


def _sha(value: str) -> str:
    return hashlib.sha256(value.encode('utf-8', 'ignore')).hexdigest()


def _make_source(db, name='Test RSS', source_type='rss', url='http://example.com/rss', enabled=True):
    src = RSSSource(
        name=name,
        url=url,
        credibility=80,
        category='markets',
        enabled=enabled,
        source_type=source_type,
        interval_seconds=60,
        allowed_patterns=[],
        blocked_patterns=[],
        article_limit=50,
        polite_delay_ms=100,
        status='healthy',
    )
    db.add(src)
    db.commit()
    db.refresh(src)
    return src


# ═══════════════════════════════════════════════════════════════════════════════
# Original classifier tests (unchanged)
# ═══════════════════════════════════════════════════════════════════════════════

def test_classifier_trade():
    assert classify('India UK FTA tariff deal') == 'trade'


def test_ipo_detection():
    assert 'drhp_filed' in ipo_events('Company DRHP filed with SEBI')


def test_trade_detection():
    assert trade_event('India UK FTA tariff deal')['hits']


def test_company_detection():
    assert detect_companies('Reliance and TCS shares gained')


def test_impact_range():
    score, _ = calculate(50, 90, 80, 90)
    assert 0 <= score <= 100


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 1 – lock.py: db.rollback() called on release failure
# ═══════════════════════════════════════════════════════════════════════════════

def test_release_lock_rollback_on_error():
    """release_ingestion_lock must rollback the session when commit fails,
    leaving the session in a clean, reusable state."""
    from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

    db = _in_memory_db()
    acquired = acquire_ingestion_lock(db, 'test-owner')
    assert acquired

    # Simulate a commit failure during release
    original_commit = db.commit

    def _bad_commit():
        db.commit = original_commit  # restore after first call
        raise Exception('simulated commit failure')

    db.commit = _bad_commit

    with pytest.raises(Exception, match='simulated commit failure'):
        release_ingestion_lock(db, 'test-owner')

    # After the exception, the session must still be usable (rollback was called)
    result = db.execute(__import__('sqlalchemy').text('SELECT 1')).scalar()
    assert result == 1
    db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 2 – lock.py: acquire_ingestion_lock returns False (not raises) on DB error
# ═══════════════════════════════════════════════════════════════════════════════

def test_acquire_lock_returns_false_on_db_error():
    from app.services.lock import acquire_ingestion_lock

    db = _in_memory_db()
    original_commit = db.commit

    def _bad_commit():
        raise Exception('db locked')

    db.commit = _bad_commit
    result = acquire_ingestion_lock(db, 'test')
    assert result is False
    db.commit = original_commit
    db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 3 – ingest.py: run.summary serialised with jsonable_encoder (no datetime error)
# ═══════════════════════════════════════════════════════════════════════════════

def test_ingestion_run_summary_is_json_serialisable():
    """IngestionRun.summary must be serialisable to JSON without raising
    'Object of type datetime is not JSON serializable'."""
    detail = [
        {
            'source': 'Test RSS',
            'source_type': 'rss',
            'inserted': 3,
            'seen': 10,
            'duplicates': 7,
            'error': None,
            'status': 'healthy',
            # datetime inside summary — this was the bug
            'next_run_at': datetime.utcnow().isoformat(),
        }
    ]
    summary = jsonable_encoder({'sources': detail, 'error': None})
    # Must not raise:
    serialised = json.dumps(summary)
    assert 'inserted' in serialised


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 4 – ingest.py: selenium_sitemap_index routes to sitemap connector
# ═══════════════════════════════════════════════════════════════════════════════

def test_fetch_source_worker_selenium_sitemap_index_routes_correctly():
    """selenium_sitemap_index sources must call sitemap_entries_for_source,
    NOT rss_entries_for_source.  The original code fell through to RSS for
    any source_type not in {'html_index', 'sitemap_xml'}, so Moneycontrol
    returned 0 articles every time."""
    from app.services import ingest as ingest_mod

    called_with = {}

    def fake_sitemap(db, src):
        called_with['source_type'] = src.source_type
        return [], 0

    def fake_rss(src):
        called_with['rss_called'] = True
        return [], 0

    with patch.object(ingest_mod, 'sitemap_entries_for_source', side_effect=fake_sitemap), \
         patch.object(ingest_mod, 'rss_entries_for_source', side_effect=fake_rss):

        snap = {
            'id': 1,
            'name': 'Moneycontrol Selenium News',
            'url': 'https://www.moneycontrol.com/news/index-sitemap-2026.xml',
            'credibility': 84,
            'category': 'markets',
            'source_type': 'selenium_sitemap_index',
            'allowed_patterns': [],
            'blocked_patterns': [],
            'article_limit': 50,
            'polite_delay_ms': 100,
        }
        result = ingest_mod.fetch_source_worker(snap)

    assert called_with.get('source_type') == 'selenium_sitemap_index', \
        'selenium_sitemap_index should have called sitemap_entries_for_source, not rss_entries_for_source'
    assert 'rss_called' not in called_with, \
        'rss_entries_for_source must NOT be called for selenium_sitemap_index sources'
    assert result['error'] is None


def test_fetch_source_worker_selenium_sitemap_routes_correctly():
    """selenium_sitemap also routes to sitemap connector."""
    from app.services import ingest as ingest_mod

    called = {}

    def fake_sitemap(db, src):
        called['ok'] = True
        return [], 0

    with patch.object(ingest_mod, 'sitemap_entries_for_source', side_effect=fake_sitemap):
        snap = {
            'id': 2,
            'name': 'Some Selenium Sitemap',
            'url': 'https://example.com/sitemap.xml',
            'credibility': 70,
            'category': 'markets',
            'source_type': 'selenium_sitemap',
            'allowed_patterns': [],
            'blocked_patterns': [],
            'article_limit': 50,
            'polite_delay_ms': 100,
        }
        result = ingest_mod.fetch_source_worker(snap)

    assert called.get('ok') is True
    assert result['error'] is None


def test_fetch_source_worker_rss_routes_correctly():
    """Plain 'rss' sources must still use rss_entries_for_source."""
    from app.services import ingest as ingest_mod

    called = {}

    def fake_rss(src):
        called['ok'] = True
        return [], 0

    with patch.object(ingest_mod, 'rss_entries_for_source', side_effect=fake_rss):
        snap = {
            'id': 3,
            'name': 'ET Markets',
            'url': 'https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms',
            'credibility': 90,
            'category': 'markets',
            'source_type': 'rss',
            'allowed_patterns': [],
            'blocked_patterns': [],
            'article_limit': 500,
            'polite_delay_ms': 250,
        }
        result = ingest_mod.fetch_source_worker(snap)

    assert called.get('ok') is True
    assert result['error'] is None


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 5 – sitemap_connector.py: child sitemaps use force_selenium=True
# ═══════════════════════════════════════════════════════════════════════════════

def test_sitemap_connector_child_fetch_uses_force_selenium():
    """When source_type is selenium_sitemap_index, every child sitemap must
    be fetched with force_selenium=True.  Previously child fetches used httpx
    and got 403 from Moneycontrol, returning 0 articles."""
    from app.services import sitemap_connector as sc

    # Parent sitemap index XML
    parent_xml = """<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://www.moneycontrol.com/news/sitemap-2026-08.xml</loc>
    <lastmod>2026-08-18</lastmod>
  </sitemap>
</sitemapindex>"""

    child_xml = """<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">
  <url>
    <loc>https://www.moneycontrol.com/news/business/markets/test-article-123456.html</loc>
    <lastmod>2026-08-18T10:00:00+05:30</lastmod>
    <news:news>
      <news:publication_date>2026-08-18T10:00:00+05:30</news:publication_date>
      <news:title>Test Market Article</news:title>
      <news:keywords>Nifty, Sensex, BSE</news:keywords>
    </news:news>
  </url>
</urlset>"""

    fetch_calls = []

    def fake_fetch(url, force_selenium=False):
        fetch_calls.append({'url': url, 'force_selenium': force_selenium})
        if 'index-sitemap' in url:
            return parent_xml
        return child_xml

    src = types.SimpleNamespace(
        source_type='selenium_sitemap_index',
        url='https://www.moneycontrol.com/news/index-sitemap-2026.xml',
        article_limit=50,
        polite_delay_ms=0,
        allowed_patterns=[],
        blocked_patterns=[],
    )

    with patch.object(sc, 'fetch_sitemap_xml', side_effect=fake_fetch):
        entries, seen = sc.sitemap_entries_for_source(None, src)

    # Every fetch — parent and child — must have force_selenium=True
    for call in fetch_calls:
        assert call['force_selenium'] is True, (
            f"fetch_sitemap_xml called with force_selenium=False for url={call['url']}"
        )

    assert len(entries) >= 1, 'Expected at least one entry from child sitemap'
    assert entries[0]['url'] == 'https://www.moneycontrol.com/news/business/markets/test-article-123456.html'


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 6 – routes.py: /api/ingestion-runs serialises summary without error
# ═══════════════════════════════════════════════════════════════════════════════

def test_ingestion_runs_jsonable_encoder():
    """IngestionRun rows must be serialisable by jsonable_encoder even when
    the summary JSON column contains ISO datetime strings."""
    db = _in_memory_db()
    src = _make_source(db)
    run = IngestionRun(
        mode='test',
        status='completed',
        inserted=5,
        finished_at=datetime.utcnow(),
        summary=jsonable_encoder({
            'sources': [
                {
                    'source': 'Test RSS',
                    'inserted': 5,
                    'next_run_at': datetime.utcnow().isoformat(),
                }
            ],
            'error': None,
        }),
    )
    db.add(run)
    db.commit()
    db.refresh(run)

    rows = db.query(IngestionRun).all()
    serialised = json.dumps(jsonable_encoder(rows))
    assert 'Test RSS' in serialised
    db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 7 – cache.py: all required functions exported
# ═══════════════════════════════════════════════════════════════════════════════

def test_cache_exports_all_required_functions():
    """cache.py must export invalidate_api_cache, cache_delete_pattern,
    and cached_or_compute (imports that other modules depend on)."""
    import app.services.cache as cache_mod

    assert callable(cache_mod.invalidate_api_cache), 'invalidate_api_cache missing'
    assert callable(cache_mod.cache_delete_pattern), 'cache_delete_pattern missing'
    assert callable(cache_mod.cached_or_compute), 'cached_or_compute missing'
    assert callable(cache_mod.cache_set_json), 'cache_set_json missing'
    assert callable(cache_mod.cache_get_json), 'cache_get_json missing'


def test_cached_or_compute_no_redis():
    """cached_or_compute must work when Redis is unavailable,
    calling compute() on every request rather than erroring."""
    from app.services.cache import cached_or_compute

    call_count = [0]

    def compute():
        call_count[0] += 1
        return {'result': 'ok'}

    with patch('app.services.cache.get_redis', return_value=None):
        result1 = cached_or_compute('test:key', compute, 30)
        result2 = cached_or_compute('test:key', compute, 30)

    assert result1 == {'result': 'ok'}
    assert result2 == {'result': 'ok'}
    assert call_count[0] == 2  # called both times (no cache)


def test_invalidate_api_cache_no_redis():
    """invalidate_api_cache must not raise when Redis is unavailable."""
    from app.services.cache import invalidate_api_cache

    with patch('app.services.cache.get_redis', return_value=None):
        result = invalidate_api_cache()
    assert result == 0


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 8 – config.py: all three cache TTL settings present and have right types
# ═══════════════════════════════════════════════════════════════════════════════

def test_config_cache_ttl_settings_present():
    from app.core.config import settings

    assert isinstance(settings.api_cache_ttl_seconds, int), 'api_cache_ttl_seconds must be int'
    assert isinstance(settings.news_cache_ttl_seconds, int), 'news_cache_ttl_seconds must be int'
    assert isinstance(settings.redis_cache_ttl_seconds, int), 'redis_cache_ttl_seconds must be int'
    assert settings.api_cache_ttl_seconds > 0
    assert settings.news_cache_ttl_seconds > 0
    assert settings.redis_cache_ttl_seconds > 0


def test_config_database_url_is_persistent_path():
    from app.core.config import settings

    # The database URL must NOT be the old relative ./data/ path
    # so data persists across VS Code restarts.
    assert './data/' not in settings.database_url, (
        'database_url must point to the stable persistent directory, not ./data/'
    )


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 9 – ingest.py: cache_set_json for news:last uses jsonable_encoder
# ═══════════════════════════════════════════════════════════════════════════════

def test_ingest_cache_last_news_uses_jsonable_encoder():
    """After ingest_all, the news:last cache key must contain JSON-safe data.
    The original code passed raw ORM Article objects to cache_set_json which
    broke json.dumps with 'Object of type datetime is not JSON serializable'."""
    db = _in_memory_db()
    src = _make_source(db)

    # Insert a real article so cache_set_json gets called with real data
    article = Article(
        source_id=src.id,
        title='Test article',
        url='https://example.com/test-1',
        url_hash=_sha('https://example.com/test-1'),
        content_hash=_sha('Test article'),
        published_at=datetime.utcnow(),
    )
    db.add(article)
    db.commit()

    captured = {}

    def fake_cache_set(key, value, ttl=None):
        if key == 'news:last':
            captured['value'] = value

    from app.services import ingest as ingest_mod

    with patch.object(ingest_mod, 'cache_set_json', side_effect=fake_cache_set), \
         patch.object(ingest_mod, 'ingest_all', wraps=None):
        # Directly call the cache line logic as it appears after ingest_all
        latest = db.query(Article).order_by(Article.fetched_at.desc()).limit(200).all()
        if latest:
            ingest_mod.cache_set_json('news:last', jsonable_encoder(latest))

    assert 'value' in captured, 'cache_set_json was not called with news:last'
    # Must be JSON-serialisable — no datetime objects
    serialised = json.dumps(captured['value'])
    assert 'test-1' in serialised
    db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 10 – React: loadAll deps do NOT include state setters (unit-testable invariant)
# ═══════════════════════════════════════════════════════════════════════════════

def test_main_jsx_loadall_deps_are_stable():
    """Smoke-test that the JSX source no longer lists dashboard/news/stats/etc.
    inside the useCallback dependency array for loadAll.  Those inclusions
    caused infinite re-renders (each setState call changed the dep,
    retriggered useEffect, called loadAll again, forever)."""
    import os

    jsx_path = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        'frontend',
        'src',
        'main.jsx',
    )
    # Try the fixed output path too
    fixed_path = os.path.join(
        os.path.dirname(__file__),
        '..',
        '..',
        '..',
        'frontend',
        'src',
        'main.jsx',
    )

    content = None
    for path in [jsx_path, fixed_path]:
        try:
            with open(os.path.normpath(path), encoding='utf-8') as f:
                content = f.read()
            break
        except FileNotFoundError:
            continue

    if content is None:
        pytest.skip('main.jsx not found at expected paths')

    # The only dep in the loadAll useCallback should be [request]
    # Look for the useCallback closing bracket pattern
    import re

    matches = re.findall(r'useCallback\(.*?(\[.*?\])\s*\)', content, re.DOTALL)
    for match in matches:
        if 'dashboard' in match or ('news' in match and 'news_cache' not in match):
            pytest.fail(
                'loadAll useCallback still lists state variables in its deps array. '
                'This causes an infinite re-render loop. '
                f'Found dependency array: {match!r}'
            )


# ═══════════════════════════════════════════════════════════════════════════════
# Integration: dedup via url_hash works correctly
# ═══════════════════════════════════════════════════════════════════════════════

def test_url_hash_deduplication():
    """Two attempts to insert the same URL should result in exactly one article."""
    db = _in_memory_db()
    src = _make_source(db)

    url = 'https://example.com/article-dedupe-test'
    url_hash = _sha(url)

    a1 = Article(
        source_id=src.id,
        title='Article 1',
        url=url,
        url_hash=url_hash,
        content_hash=_sha('Article 1'),
    )
    db.add(a1)
    db.commit()

    # Simulate what ingest does: check before insert
    exists = db.query(Article.id).filter(Article.url_hash == url_hash).first()
    assert exists is not None

    count = db.query(Article).filter(Article.url_hash == url_hash).count()
    assert count == 1
    db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# Integration: ingestion lock acquire + release round-trip
# ═══════════════════════════════════════════════════════════════════════════════

def test_lock_acquire_release_roundtrip():
    from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

    db = _in_memory_db()

    assert acquire_ingestion_lock(db, 'owner-a') is True
    # Second acquire with a different owner should fail (lock held)
    assert acquire_ingestion_lock(db, 'owner-b') is False

    release_ingestion_lock(db, 'owner-a')

    # After release, a new owner can acquire
    assert acquire_ingestion_lock(db, 'owner-b') is True
    release_ingestion_lock(db, 'owner-b')
    db.close()


def test_lock_expired_can_be_reacquired():
    """An expired lock (locked_until in the past) must be re-acquirable."""
    from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

    db = _in_memory_db()
    acquire_ingestion_lock(db, 'owner-a')

    # Manually expire the lock
    lock = db.get(IngestionLock, 1)
    lock.locked_until = datetime.utcnow() - timedelta(seconds=10)
    db.commit()

    assert acquire_ingestion_lock(db, 'owner-b') is True
    db.close()


# ═══════════════════════════════════════════════════════════════════════════════
# Sitemap connector: XML parsing helpers
# ═══════════════════════════════════════════════════════════════════════════════

def test_parse_sitemap_index_filters_by_date():
    from app.services.sitemap_connector import parse_sitemap_index

    old_date = (datetime.utcnow() - timedelta(days=30)).strftime('%Y-%m-%d')
    new_date = datetime.utcnow().strftime('%Y-%m-%d')

    xml = f"""<?xml version="1.0"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap><loc>https://example.com/old.xml</loc><lastmod>{old_date}</lastmod></sitemap>
  <sitemap><loc>https://example.com/new.xml</loc><lastmod>{new_date}</lastmod></sitemap>
</sitemapindex>"""

    items = parse_sitemap_index(xml, max_sitemaps=10, backfill_days=6)
    urls = [item['url'] for item in items]
    assert 'https://example.com/new.xml' in urls
    assert 'https://example.com/old.xml' not in urls


def test_parse_sitemap_urls_extracts_news_fields():
    from app.services.sitemap_connector import parse_sitemap_urls

    xml = """<?xml version="1.0"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:news="http://www.google.com/schemas/sitemap-news/0.9"
        xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">
  <url>
    <loc>https://www.moneycontrol.com/news/business/markets/nifty-article.html</loc>
    <lastmod>2026-08-18T10:00:00+05:30</lastmod>
    <news:news>
      <news:publication_date>2026-08-18T10:00:00+05:30</news:publication_date>
      <news:title>Nifty crosses 25000</news:title>
      <news:keywords>Nifty, Sensex, Bulls</news:keywords>
    </news:news>
    <image:image>
      <image:loc>https://img.moneycontrol.com/nifty.jpg</image:loc>
    </image:image>
  </url>
</urlset>"""

    items = parse_sitemap_urls(xml)
    assert len(items) == 1
    item = items[0]
    assert item['url'] == 'https://www.moneycontrol.com/news/business/markets/nifty-article.html'
    assert item['title'] == 'Nifty crosses 25000'
    assert 'Nifty' in (item['keywords'] or '')
    assert item['image_url'] == 'https://img.moneycontrol.com/nifty.jpg'
    assert item['publication_date'] is not None


# ═══════════════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════════════
# BUG FIX 16 – selenium_connector.py: Chrome XML viewer returns full HTML page;
#              XHR re-fetch strategy extracts raw XML correctly
# ═══════════════════════════════════════════════════════════════════════════════

def test_extract_xml_from_pagesource_finds_sitemapindex_in_viewer_div():
    """_extract_xml_from_pagesource must find XML inside the
    #webkit-xml-viewer-source-xml div that Chrome injects for all XML URLs."""
    from app.services.selenium_connector import _extract_xml_from_pagesource

    # Real Chrome page_source structure for an XML sitemap URL
    chrome_pagesource = (
        '<html xmlns="http://www.w3.org/1999/xhtml">'
        '<head><style id="xml-viewer-style">/* Chromium CSS */\n:root{color-scheme:light dark;}\n</style></head>'
        '<body>'
        '<div id="webkit-xml-viewer-source-xml">'
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc>'
        '<lastmod>2026-08-18T15:12:46+05:30</lastmod></sitemap>'
        '</sitemapindex>'
        '</div>'
        '<div id="webkit-xml-viewer-tree">... rendered tree ...</div>'
        '</body></html>'
    )

    result = _extract_xml_from_pagesource(chrome_pagesource)
    assert '<sitemapindex' in result, (
        f'Expected <sitemapindex in result, got: {result[:300]!r}'
    )
    # Must be parseable XML
    import xml.etree.ElementTree as ET
    root = ET.fromstring(result.encode('utf-8'))
    assert 'sitemapindex' in root.tag


def test_extract_xml_from_pagesource_unescape_fallback():
    """When the viewer div is absent, _extract_xml_from_pagesource falls back
    to unescape() + marker search."""
    from app.services.selenium_connector import _extract_xml_from_pagesource

    # page_source with entity-encoded XML but no viewer div
    entity_encoded = (
        '<html><body>'
        '&lt;?xml version="1.0"?&gt;'
        '&lt;urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"&gt;'
        '&lt;url&gt;&lt;loc&gt;https://example.com/article.html&lt;/loc&gt;&lt;/url&gt;'
        '&lt;/urlset&gt;'
        '</body></html>'
    )
    result = _extract_xml_from_pagesource(entity_encoded)
    assert '<urlset' in result, f'Expected <urlset in result, got: {result[:300]!r}'


def test_selenium_fetch_uses_xhr_strategy(monkeypatch):
    """selenium_fetch_page_source must try XHR first and return raw XML
    when the XHR strategy succeeds."""
    from app.services import selenium_connector as sc

    raw_xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc>'
        '<lastmod>2026-08-18T15:12:46+05:30</lastmod></sitemap>'
        '</sitemapindex>'
    )

    class FakeDriver:
        page_source = '<html><body><div id="webkit-xml-viewer-source-xml"></div></body></html>'
        current_url = 'https://www.moneycontrol.com/news/index-sitemap-2026.xml'
        title = 'Moneycontrol sitemap'

        def get(self, url): pass
        def quit(self): pass

        def execute_script(self, script):
            # Simulate XHR returning raw XML on first call
            if 'XMLHttpRequest' in script:
                return raw_xml
            return ''

        def set_page_load_timeout(self, t): pass

    monkeypatch.setattr(sc, '_build_driver', lambda: FakeDriver())

    result = sc.selenium_fetch_page_source(
        'https://www.moneycontrol.com/news/index-sitemap-2026.xml',
        wait_text='sitemap'
    )

    assert '<sitemapindex' in result, f'Expected <sitemapindex in XHR result, got: {result[:300]!r}'


def test_selenium_fetch_falls_back_to_div_when_xhr_empty(monkeypatch):
    """When XHR returns empty/non-XML, fall back to the viewer div JS extraction."""
    from app.services import selenium_connector as sc

    div_xml = (
        '<?xml version="1.0"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<url><loc>https://www.moneycontrol.com/news/business/markets/article.html</loc></url>'
        '</urlset>'
    )

    class FakeDriver:
        page_source = '<html><body><div id="webkit-xml-viewer-source-xml">' + div_xml + '</div></body></html>'
        current_url = 'https://example.com/sitemap.xml'
        title = 'sitemap'

        def get(self, url): pass
        def quit(self): pass

        def execute_script(self, script):
            if 'XMLHttpRequest' in script:
                return ''  # XHR returns nothing
            if 'webkit-xml-viewer-source-xml' in script:
                return div_xml
            return ''

        def set_page_load_timeout(self, t): pass

    monkeypatch.setattr(sc, '_build_driver', lambda: FakeDriver())

    result = sc.selenium_fetch_page_source('https://example.com/sitemap.xml')
    assert '<urlset' in result, f'Expected <urlset from div fallback, got: {result[:300]!r}'


def test_selenium_fetch_falls_back_to_pagesource_regex(monkeypatch):
    """When XHR and div JS both fail, fall back to regex extraction from page_source."""
    from app.services import selenium_connector as sc

    raw_xml_in_div = (
        '<?xml version="1.0"?>'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc></sitemap>'
        '</sitemapindex>'
    )

    class FakeDriver:
        page_source = (
            '<html><body><div id="webkit-xml-viewer-source-xml">'
            + raw_xml_in_div
            + '</div></body></html>'
        )
        current_url = 'https://example.com/sitemap.xml'
        title = 'sitemap'

        def get(self, url): pass
        def quit(self): pass

        def execute_script(self, script):
            return ''  # All JS strategies return empty

        def set_page_load_timeout(self, t): pass

    monkeypatch.setattr(sc, '_build_driver', lambda: FakeDriver())

    result = sc.selenium_fetch_page_source('https://example.com/sitemap.xml')
    assert '<sitemapindex' in result, f'Expected <sitemapindex from regex fallback, got: {result[:300]!r}'


# ═══════════════════════════════════════════════════════════════════════════════
# Sitemap connector: full pipeline with realistic Moneycontrol XML
# ═══════════════════════════════════════════════════════════════════════════════

def test_to_xml_text_strips_chrome_wrapper():
    """_to_xml_text must extract clean XML whether it is plain XML,
    XML with a leading Chrome message, or entity-encoded XML."""
    from app.services.sitemap_connector import _to_xml_text
    import xml.etree.ElementTree as ET

    # Case A: plain XML (from XHR — the common case now)
    plain = (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc>'
        '<lastmod>2026-08-18T15:12:46+05:30</lastmod></sitemap>\n'
        '</sitemapindex>'
    )
    result_a = _to_xml_text(plain)
    assert '<sitemapindex' in result_a
    ET.fromstring(result_a.encode('utf-8'))  # must parse

    # Case B: raw XML with Chrome leading message
    with_message = (
        'This XML file does not appear to have any style information associated with it.\n\n'
        + plain
    )
    result_b = _to_xml_text(with_message)
    assert '<sitemapindex' in result_b
    ET.fromstring(result_b.encode('utf-8'))

    # Case C: entity-encoded XML (legacy fallback path)
    from html import escape
    entity_encoded = escape(plain)
    result_c = _to_xml_text(entity_encoded)
    assert '<sitemapindex' in result_c
    ET.fromstring(result_c.encode('utf-8'))


def test_full_pipeline_sitemapindex_to_articles():
    """End-to-end: sitemapindex → child fetch → parse_sitemap_urls → entries.
    All fetches use force_selenium=True. No network required."""
    from unittest.mock import patch
    from app.services import sitemap_connector as sc
    import types

    parent_xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap>'
        '<loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc>'
        '<lastmod>2026-08-18T10:00:00+05:30</lastmod>'
        '</sitemap>'
        '</sitemapindex>'
    )

    child_xml = (
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" '
        'xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">'
        '<url>'
        '<loc>https://www.moneycontrol.com/news/business/markets/nifty-17788891.html</loc>'
        '<news:news>'
        '<news:publication_date>2026-08-18T12:30:00+05:30</news:publication_date>'
        '<news:title>Nifty Bank Nifty outlook for today</news:title>'
        '<news:keywords>Nifty, Bank Nifty, NSE</news:keywords>'
        '</news:news>'
        '</url>'
        '<url>'
        '<loc>https://www.moneycontrol.com/news/business/companies/reliance-q1-17788900.html</loc>'
        '<news:news>'
        '<news:title>Reliance Q1 results beat estimates</news:title>'
        '<news:keywords>Reliance, RIL, Q1 results</news:keywords>'
        '</news:news>'
        '</url>'
        '</urlset>'
    )

    def fake_fetch(url, force_selenium=False):
        assert force_selenium is True, f'force_selenium must be True, got False for {url}'
        return parent_xml if 'index-sitemap' in url else child_xml

    src = types.SimpleNamespace(
        source_type='selenium_sitemap_index',
        url='https://www.moneycontrol.com/news/index-sitemap-2026.xml',
        article_limit=50,
        polite_delay_ms=0,
    )

    with patch.object(sc, 'fetch_sitemap_xml', side_effect=fake_fetch):
        entries, seen = sc.sitemap_entries_for_source(None, src)

    assert len(entries) == 2, f'Expected 2 articles, got {len(entries)}'
    titles = [e['title'] for e in entries]
    assert any('Nifty' in t for t in titles)
    assert any('Reliance' in t for t in titles)


def test_financial_url_filter_keeps_business_drops_lifestyle():
    from app.services.sitemap_connector import _is_financial_url

    assert _is_financial_url('https://www.moneycontrol.com/news/business/markets/nifty.html')
    assert _is_financial_url('https://www.moneycontrol.com/news/business/companies/reliance.html')
    assert _is_financial_url('https://www.moneycontrol.com/news/business/ipo/company.html')
    assert _is_financial_url('https://www.moneycontrol.com/news/business/commodities/gold.html')
    assert _is_financial_url('https://www.moneycontrol.com/news/business/earnings/tcs.html')
    assert not _is_financial_url('https://www.moneycontrol.com/news/lifestyle/fashion.html')
    assert not _is_financial_url('https://www.moneycontrol.com/news/india/politics.html')
    assert not _is_financial_url('https://www.moneycontrol.com/news/world/global.html')
    assert not _is_financial_url('https://www.moneycontrol.com/news/technology/gadgets.html')


# ═══════════════════════════════════════════════════════════════════════════════
# NEW FEATURE TESTS — Finance Model 1, Signal Model 2, Nifty 250, Quote Service
# ═══════════════════════════════════════════════════════════════════════════════

# ── Nifty 250 universe ────────────────────────────────────────────────────────

def test_nifty250_count():
    from app.services.nifty250 import NIFTY_250
    assert len(NIFTY_250) >= 200, f'Expected 200+ stocks, got {len(NIFTY_250)}'


def test_nifty250_no_duplicates():
    from app.services.nifty250 import NIFTY_250
    symbols = [s['symbol'] for s in NIFTY_250]
    assert len(symbols) == len(set(symbols)), 'Duplicate symbols in NIFTY_250'


def test_nifty250_required_fields():
    from app.services.nifty250 import NIFTY_250
    for stock in NIFTY_250:
        assert stock.get('symbol'), f'Missing symbol: {stock}'
        assert stock.get('name'),   f'Missing name: {stock}'
        assert stock.get('sector'), f'Missing sector in {stock["symbol"]}'


def test_nifty250_yf_symbol():
    from app.services.nifty250 import yf_symbol
    assert yf_symbol('RELIANCE') == 'RELIANCE.NS'
    assert yf_symbol('TCS')      == 'TCS.NS'


def test_nifty250_get_by_symbol():
    from app.services.nifty250 import get_by_symbol
    r = get_by_symbol('RELIANCE')
    assert r is not None
    assert r['name'] == 'Reliance Industries'
    assert get_by_symbol('NONEXISTENT_XYZ_ABC') is None


# ── Finance Model 1 ───────────────────────────────────────────────────────────

def test_finance_score_returns_required_keys():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.models import Base
    from app.services.finance_model import compute_finance_score

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()

    result = compute_finance_score(db, 'RELIANCE')

    required = ['symbol','name','sector','finance_score','signal_tier','pillar_scores','pillar_details','computed_at']
    for key in required:
        assert key in result, f'Missing key: {key}'

    assert 0 <= result['finance_score'] <= 100
    assert result['signal_tier'] in ('STRONG_BUY','BUY','HOLD','SELL','STRONG_SELL')
    pillars = result['pillar_scores']
    for p in ('earnings','holding','events','sentiment','technical'):
        assert p in pillars, f'Missing pillar: {p}'
        assert 0 <= pillars[p] <= 100

    db.close()


def test_finance_score_with_quote():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.models import Base
    from app.services.finance_model import compute_finance_score

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine)()

    quote = {
        'price': 2850.0, 'prev_close': 2800.0, 'week52_high': 3200.0,
        'week52_low': 2200.0, 'pe_ratio': 28.5, 'beta': 0.9,
    }
    result = compute_finance_score(db, 'TCS', quote=quote)
    assert result['finance_score'] > 0
    assert result['pillar_details']['technical']['available'] is True
    db.close()


def test_finance_score_pillar_weights_sum_to_one():
    from app.services.finance_model import PILLAR_WEIGHTS
    assert abs(sum(PILLAR_WEIGHTS.values()) - 1.0) < 1e-9


def test_batch_finance_scores():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.models import Base
    from app.services.finance_model import batch_compute_finance_scores

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    db = sessionmaker(bind=engine)()

    syms = ['RELIANCE', 'TCS', 'HDFCBANK']
    results = batch_compute_finance_scores(db, syms)
    assert len(results) == 3
    # Should be sorted by finance_score descending
    scores = [r['finance_score'] for r in results]
    assert scores == sorted(scores, reverse=True)
    db.close()


def test_earnings_scoring():
    """_score_earnings: high revenue + profit growth → score > 60."""
    from app.db.models_extended import EarningsResult
    from app.services.finance_model import _score_earnings
    from datetime import datetime

    rows = [EarningsResult(
        symbol='TEST', period_end=datetime(2026, 6, 30),
        quarter_label='Q1FY27',
        revenue_yoy_pct=25.0, net_profit_yoy_pct=35.0,
        net_margin_pct=18.0, eps_yoy_pct=30.0, beat_estimate=True,
    )]
    score, detail = _score_earnings(rows)
    assert score > 60, f'Expected score > 60, got {score}'
    assert detail['available'] is True
    assert detail['consecutive_beats'] == 1


def test_holding_scoring_high_pledge():
    """_score_holding: high pledge % should lower the score."""
    from app.db.models_extended import HoldingPattern
    from app.services.finance_model import _score_holding
    from datetime import datetime

    high_pledge = [HoldingPattern(
        symbol='TEST', period_date=datetime(2026, 6, 30),
        promoter_pct=55.0, pledged_pct=45.0,
        fii_pct=15.0, dii_pct=10.0, fii_change_pct=-2.0,
    )]
    no_pledge = [HoldingPattern(
        symbol='TEST', period_date=datetime(2026, 6, 30),
        promoter_pct=55.0, pledged_pct=0.0,
        fii_pct=20.0, dii_pct=12.0, fii_change_pct=1.0,
    )]
    s_high, _ = _score_holding(high_pledge)
    s_low, _  = _score_holding(no_pledge)
    assert s_low > s_high, 'Zero pledge should score higher than 45% pledge'


# ── Signal Model 2 ────────────────────────────────────────────────────────────

def test_signal_model_trains_on_synthetic():
    """ensure_trained() trains on synthetic data when no real data exists."""
    from app.services.signal_model import ensure_trained, SIGNAL_LABELS

    model = ensure_trained()
    assert model.is_trained
    assert model._training_samples >= 2000
    info = model.info()
    assert info['trained'] is True
    assert info['labels'] == SIGNAL_LABELS


def test_signal_model_predict_returns_valid_signal():
    from app.services.signal_model import ensure_trained, SIGNAL_LABELS
    import numpy as np

    model = ensure_trained()
    # Strongly bullish feature vector
    features = np.array([
        80, 70, 75, 80, 72, 78,  # pillar scores + finance score
        1, 1, 1, 1,              # all pillars available
        25, 35, 18, 28,          # rev_growth, pft_growth, margin, eps_growth
        62, 25, 2, 3,            # promoter, fii, pledged, fii_change
        1.5, 22, 0.9, 0.75,     # daily_chg, pe, beta, 52wk_position
    ], dtype=np.float32)

    signal, confidence, proba = model.predict(features)
    assert signal in SIGNAL_LABELS
    assert 0 <= confidence <= 100
    assert len(proba) == 3
    assert abs(sum(proba) - 1.0) < 1e-5


def test_generate_signal_output_keys():
    """generate_signal returns all required keys."""
    from app.services.signal_model import generate_signal

    finance_result = {
        'symbol': 'RELIANCE', 'name': 'Reliance Industries',
        'sector': 'Energy', 'finance_score': 72.5,
        'signal_tier': 'BUY',
        'pillar_scores': {'earnings':75,'holding':68,'events':60,'sentiment':72,'technical':65},
        'pillar_details': {
            'earnings':  {'available':True,'revenue_growth_pct':20,'profit_growth_pct':30,'net_margin_pct':15,'eps_growth_pct':25,'beat_estimate':True,'consecutive_beats':2,'score':78},
            'holding':   {'available':True,'promoter_pct':50,'fii_pct':22,'pledged_pct':5,'fii_change':1.5,'score':68},
            'events':    {'available':False,'score':50},
            'sentiment': {'available':True,'article_count':12,'score':72},
            'technical': {'available':True,'price':2850,'prev_close':2800,'daily_change_pct':1.8,'pe_ratio':28,'beta':0.9,'score':65},
        },
        'quote': {'price':2850,'prev_close':2800,'week52_high':3200,'week52_low':2200,'pe_ratio':28,'beta':0.9},
    }
    result = generate_signal(finance_result)

    required = ['symbol','name','sector','finance_score','signal','confidence','class_proba','price_range','pillar_scores','generated_at']
    for key in required:
        assert key in result, f'Missing key: {key}'

    assert result['signal'] in ('BULLISH','NEUTRAL','BEARISH')
    assert 0 <= result['confidence'] <= 100
    pr = result['price_range']
    assert pr['current_price'] == 2850.0
    assert pr['target_low'] is not None
    assert pr['target_high'] is not None
    assert pr['target_high'] > pr['target_low']


def test_price_range_bullish_higher_than_bearish():
    """Bullish signal should produce a higher target_mid than bearish."""
    from app.services.signal_model import _estimate_price_range

    quote = {'price': 1000.0, 'prev_close': 990.0, 'week52_high': 1200.0, 'week52_low': 800.0}
    bull = _estimate_price_range(quote, 'BULLISH', 80.0)
    bear = _estimate_price_range(quote, 'BEARISH', 80.0)

    assert bull['target_mid'] > bear['target_mid'], \
        f"Bullish mid {bull['target_mid']} should be > Bearish mid {bear['target_mid']}"


def test_feature_extraction_shape():
    """_extract_features returns a vector of the correct length."""
    from app.services.signal_model import _extract_features, FEATURES
    import numpy as np

    finance_result = {
        'finance_score': 60,
        'pillar_scores': {'earnings':60,'holding':55,'events':50,'sentiment':65,'technical':58},
        'pillar_details': {
            'earnings': {'available':True,'revenue_growth_pct':10,'profit_growth_pct':15,'net_margin_pct':12,'eps_growth_pct':10,'beat_estimate':True},
            'holding':  {'available':True,'promoter_pct':52,'fii_pct':18,'pledged_pct':8,'fii_change':0.5},
            'events':   {'available':False},
            'sentiment':{'available':True},
            'technical':{'available':True,'daily_change_pct':0.8,'pe_ratio':24,'beta':1.1},
        },
        'quote': {'price':1500,'prev_close':1480,'week52_high':1800,'week52_low':1200},
    }
    features = _extract_features(finance_result)
    assert features.shape == (len(FEATURES),), \
        f'Expected {len(FEATURES)} features, got {features.shape[0]}'
    assert not any(np.isnan(features)), 'NaN in feature vector'


# ── Quote service ─────────────────────────────────────────────────────────────

def test_quote_service_no_yfinance():
    """get_quote returns graceful fallback when yfinance unavailable."""
    from unittest.mock import patch
    from app.services.quote_service import get_quote

    with patch('app.services.quote_service._yf_available', return_value=False), \
         patch('app.services.cache.get_redis', return_value=None):
        result = get_quote('RELIANCE')

    assert result['symbol'] == 'RELIANCE'
    assert result['price'] is None
    assert 'error' in result


def test_quotes_batch_empty():
    from app.services.quote_service import get_quotes_batch
    result = get_quotes_batch([])
    assert result == {}


def test_safe_float():
    from app.services.quote_service import _safe
    assert _safe(None) is None
    assert _safe('bad') is None
    assert _safe(float('nan')) is None
    assert _safe(float('inf')) is None
    assert _safe(1234.5678) == 1234.5678
    assert _safe('3.14') == 3.14


# ── Config: new keys present ──────────────────────────────────────────────────

def test_config_new_keys():
    from app.core.config import settings
    assert isinstance(settings.quote_cache_ttl_seconds, int)
    assert isinstance(settings.quote_refresh_interval_seconds, int)
    assert isinstance(settings.signal_refresh_interval_seconds, int)
    assert isinstance(settings.signal_retrain_interval_seconds, int)
    assert isinstance(settings.signal_batch_size, int)
    assert isinstance(settings.sentiment_lookback_days, int)
    assert settings.quote_cache_ttl_seconds > 0
    assert settings.signal_batch_size > 0


# ── DB models: extended tables created via Base.metadata ─────────────────────

def test_extended_tables_created_by_base_metadata():
    """All extended model tables must be registered in Base.metadata."""
    from app.db.models import Base
    table_names = set(Base.metadata.tables.keys())
    required = {
        'stock_universe', 'stock_quotes', 'earnings_results',
        'holding_patterns', 'corporate_events', 'trade_signals',
    }
    missing = required - table_names
    assert not missing, f'Missing tables in Base.metadata: {missing}'


def test_extended_tables_create_in_memory():
    """Extended tables must be creatable in an in-memory SQLite DB."""
    from sqlalchemy import create_engine, inspect
    from app.db.models import Base

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    inspector = inspect(engine)
    existing = set(inspector.get_table_names())
    required = {
        'stock_universe', 'stock_quotes', 'earnings_results',
        'holding_patterns', 'corporate_events', 'trade_signals',
        'articles', 'rss_sources', 'ingestion_runs',
    }
    missing = required - existing
    assert not missing, f'Tables not created: {missing}'


# ── Scheduler: 4 jobs registered ─────────────────────────────────────────────

def test_scheduler_registers_all_four_jobs():
    """start_scheduler must register rss_ingestion_due, quote_refresh,
    signal_refresh, and signal_retrain jobs."""
    from unittest.mock import patch, MagicMock
    import app.services.scheduler as sched_mod

    mock_scheduler = MagicMock()
    mock_scheduler.running = False
    with patch.object(sched_mod, 'scheduler', mock_scheduler):
        with patch('app.core.config.settings') as mock_settings:
            mock_settings.app_scheduler_enabled = True
            mock_settings.ingestion_interval_seconds = 60
            mock_settings.quote_refresh_interval_seconds = 300
            mock_settings.signal_refresh_interval_seconds = 1800
            mock_settings.signal_retrain_interval_seconds = 86400
            sched_mod.start_scheduler()

    job_ids = [call.kwargs.get('id') or call.args[1] if call.args else call.kwargs.get('id')
               for call in mock_scheduler.add_job.call_args_list]
    # Simpler: just check add_job was called 4 times
    assert mock_scheduler.add_job.call_count == 4, \
        f'Expected 4 jobs registered, got {mock_scheduler.add_job.call_count}'
