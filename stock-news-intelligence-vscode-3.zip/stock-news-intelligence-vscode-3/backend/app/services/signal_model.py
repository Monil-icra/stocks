"""
signal_model.py — Trade Signal Model (Model 2)

Trains a RandomForest classifier on Finance Model 1 feature vectors and
generates per-stock trade signals:

  Signal:     BULLISH | BEARISH | NEUTRAL
  Confidence: 0–100 %
  Price Range: (target_low, target_high) based on ATR + sentiment bias

Training data is synthetic-bootstrapped from historical finance scores
stored in the TradeSignal table, and supplemented with real data as it
accumulates.  The model retrains every time generate_signals() is called
with retrain=True (default: daily via scheduler).

Persistence: model is pickled to stable_data_dir/signal_model.pkl so it
survives restarts.
"""
from __future__ import annotations

import math
import pickle
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Any

import numpy as np

from app.core.config import settings
from app.services.finance_model import PILLAR_WEIGHTS, _clamp, _safe_float


# ─── feature vector definition ───────────────────────────────────────────────

FEATURES = [
    'earnings_score',
    'holding_score',
    'events_score',
    'sentiment_score',
    'technical_score',
    'finance_score',
    'earnings_available',
    'holding_available',
    'events_available',
    'sentiment_available',
    'revenue_growth',
    'profit_growth',
    'net_margin',
    'eps_growth',
    'promoter_pct',
    'fii_pct',
    'pledged_pct',
    'fii_change',
    'daily_change_pct',
    'pe_ratio',
    'beta',
    'week52_position',   # (price - 52wk_low) / (52wk_high - 52wk_low)
]

SIGNAL_LABELS = ['BEARISH', 'NEUTRAL', 'BULLISH']
SIGNAL_TO_INT  = {s: i for i, s in enumerate(SIGNAL_LABELS)}
INT_TO_SIGNAL  = {i: s for i, s in enumerate(SIGNAL_LABELS)}

MODEL_PATH = Path(settings.stable_data_dir) / 'signal_model.pkl'


# ─── feature extraction ───────────────────────────────────────────────────────

def _extract_features(finance_result: dict) -> np.ndarray:
    p   = finance_result.get('pillar_scores', {})
    pd_ = finance_result.get('pillar_details', {})
    q   = finance_result.get('quote') or {}

    e_det = pd_.get('earnings', {})
    h_det = pd_.get('holding', {})
    t_det = pd_.get('technical', {})

    price      = _safe_float(q.get('price'))
    wk52h      = _safe_float(q.get('week52_high'))
    wk52l      = _safe_float(q.get('week52_low'))
    wk52_pos   = (
        (price - wk52l) / (wk52h - wk52l)
        if wk52h and wk52l and wk52h > wk52l
        else 0.5
    )

    return np.array([
        _safe_float(p.get('earnings'),  50),
        _safe_float(p.get('holding'),   50),
        _safe_float(p.get('events'),    50),
        _safe_float(p.get('sentiment'), 50),
        _safe_float(p.get('technical'), 50),
        _safe_float(finance_result.get('finance_score'), 50),
        float(e_det.get('available', False)),
        float(h_det.get('available', False)),
        float(pd_.get('events', {}).get('available', False)),
        float(pd_.get('sentiment', {}).get('available', False)),
        _safe_float(e_det.get('revenue_growth_pct'), 0),
        _safe_float(e_det.get('profit_growth_pct'),  0),
        _safe_float(e_det.get('net_margin_pct'),     0),
        _safe_float(e_det.get('eps_growth_pct'),     0),
        _safe_float(h_det.get('promoter_pct'),      50),
        _safe_float(h_det.get('fii_pct'),           20),
        _safe_float(h_det.get('pledged_pct'),        0),
        _safe_float(h_det.get('fii_change'),         0),
        _safe_float(t_det.get('daily_change_pct'),   0),
        _safe_float(t_det.get('pe_ratio'),          25),
        _safe_float(t_det.get('beta'),               1),
        wk52_pos,
    ], dtype=np.float32)


# ─── synthetic training bootstrap ────────────────────────────────────────────

def _generate_synthetic_training_data(n_samples: int = 2000) -> tuple[np.ndarray, np.ndarray]:
    """
    Bootstrap training data when no real historical signals exist yet.
    Uses domain rules to label synthetic feature vectors so the model
    starts with reasonable priors.
    """
    rng = np.random.default_rng(42)
    X = []
    y = []

    for _ in range(n_samples):
        fs   = rng.uniform(0, 100)
        earn = rng.uniform(0, 100)
        hold = rng.uniform(0, 100)
        ev   = rng.uniform(0, 100)
        sent = rng.uniform(0, 100)
        tech = rng.uniform(0, 100)

        rev_g  = rng.uniform(-30, 60)
        pft_g  = rng.uniform(-40, 80)
        margin = rng.uniform(-5, 30)
        eps_g  = rng.uniform(-30, 60)
        prom   = rng.uniform(20, 75)
        fii    = rng.uniform(0, 40)
        pledge = rng.uniform(0, 60)
        fii_ch = rng.uniform(-10, 10)
        d_chg  = rng.uniform(-5, 5)
        pe     = rng.uniform(5, 80)
        beta   = rng.uniform(0.3, 2.0)
        wk52   = rng.uniform(0, 1)

        row = np.array([
            earn, hold, ev, sent, tech, fs,
            1, 1, 1, 1,
            rev_g, pft_g, margin, eps_g,
            prom, fii, pledge, fii_ch,
            d_chg, pe, beta, wk52,
        ], dtype=np.float32)

        # Domain-rule label
        bullish_signals = (
            int(fs >= 65) +
            int(rev_g > 15) +
            int(pft_g > 20) +
            int(margin > 12) +
            int(fii_ch > 2) +
            int(sent >= 60) +
            int(wk52 > 0.6) +
            int(pledge < 10)
        )
        bearish_signals = (
            int(fs <= 35) +
            int(rev_g < -5) +
            int(pft_g < -10) +
            int(pledge > 40) +
            int(fii_ch < -3) +
            int(sent <= 40) +
            int(wk52 < 0.25) +
            int(pe > 70)
        )

        if bullish_signals >= 5:
            label = SIGNAL_TO_INT['BULLISH']
        elif bearish_signals >= 4:
            label = SIGNAL_TO_INT['BEARISH']
        else:
            label = SIGNAL_TO_INT['NEUTRAL']

        X.append(row)
        y.append(label)

    return np.array(X), np.array(y)


# ─── Model class ──────────────────────────────────────────────────────────────

class SignalModel:
    def __init__(self):
        self._clf = None
        self._trained_at: datetime | None = None
        self._training_samples: int = 0

    def _build_clf(self):
        from sklearn.ensemble import RandomForestClassifier
        return RandomForestClassifier(
            n_estimators=200,
            max_depth=8,
            min_samples_leaf=5,
            class_weight='balanced',
            random_state=42,
            n_jobs=-1,
        )

    def train(self, X: np.ndarray, y: np.ndarray) -> None:
        clf = self._build_clf()
        clf.fit(X, y)
        self._clf = clf
        self._trained_at = datetime.utcnow()
        self._training_samples = len(X)

    def predict(self, features: np.ndarray) -> tuple[str, float, np.ndarray]:
        """Returns (signal_label, confidence_pct, class_probabilities)."""
        if self._clf is None:
            return 'NEUTRAL', 50.0, np.array([0.25, 0.5, 0.25])
        proba = self._clf.predict_proba(features.reshape(1, -1))[0]
        idx = int(np.argmax(proba))
        return INT_TO_SIGNAL[idx], round(float(proba[idx]) * 100, 1), proba

    def save(self) -> None:
        MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
        with open(MODEL_PATH, 'wb') as f:
            pickle.dump(self, f)

    @classmethod
    def load(cls) -> 'SignalModel':
        if MODEL_PATH.exists():
            try:
                with open(MODEL_PATH, 'rb') as f:
                    return pickle.load(f)
            except Exception:
                pass
        return cls()

    @property
    def is_trained(self) -> bool:
        return self._clf is not None

    def info(self) -> dict:
        return {
            'trained': self.is_trained,
            'trained_at': self._trained_at.isoformat() if self._trained_at else None,
            'training_samples': self._training_samples,
            'features': FEATURES,
            'labels': SIGNAL_LABELS,
        }


# ─── price range estimation ───────────────────────────────────────────────────

def _estimate_price_range(
    quote: dict | None,
    signal: str,
    confidence: float,
    history: list[dict] | None = None,
) -> dict:
    """
    Estimate a target price range based on ATR (Average True Range) and
    signal direction.  Falls back to percentage-based ranges when history
    is unavailable.
    """
    if not quote or not quote.get('price'):
        return {'low': None, 'high': None, 'method': 'unavailable'}

    price = _safe_float(quote['price'])
    if price <= 0:
        return {'low': None, 'high': None, 'method': 'unavailable'}

    # Compute ATR from history if available (14-day)
    atr_pct = 0.03  # default 3% daily range
    if history and len(history) >= 14:
        trs = []
        for i in range(1, min(15, len(history))):
            h = _safe_float(history[i]['high'])
            l = _safe_float(history[i]['low'])
            pc = _safe_float(history[i - 1]['close'])
            if h and l and pc:
                tr = max(h - l, abs(h - pc), abs(l - pc))
                trs.append(tr / pc)
        if trs:
            atr_pct = sum(trs) / len(trs)

    # Horizon: 1-month range (20 trading days)
    horizon_days = 20
    # Annualized drift based on signal
    drift_per_day = {
        'BULLISH': 0.001 + (confidence - 50) / 5000,
        'NEUTRAL': 0.0,
        'BEARISH': -0.001 - (confidence - 50) / 5000,
    }.get(signal, 0.0)

    expected_move = price * drift_per_day * horizon_days
    range_width   = price * atr_pct * math.sqrt(horizon_days)

    target_mid = price + expected_move
    low  = round(max(price * 0.5, target_mid - range_width), 2)
    high = round(target_mid + range_width, 2)

    return {
        'current_price': round(price, 2),
        'target_low':    low,
        'target_high':   high,
        'target_mid':    round(target_mid, 2),
        'atr_pct':       round(atr_pct * 100, 2),
        'horizon_days':  horizon_days,
        'method':        'atr_based' if history else 'percentage_based',
    }


# ─── Global model instance ────────────────────────────────────────────────────

_model: SignalModel | None = None


def _get_model() -> SignalModel:
    global _model
    if _model is None:
        _model = SignalModel.load()
    return _model


def ensure_trained(real_X: np.ndarray | None = None, real_y: np.ndarray | None = None) -> SignalModel:
    """Ensure the model is trained, using synthetic data if real data is sparse."""
    model = _get_model()
    if model.is_trained:
        return model

    X_syn, y_syn = _generate_synthetic_training_data(2000)

    if real_X is not None and len(real_X) >= 50:
        X = np.vstack([X_syn, real_X])
        y = np.concatenate([y_syn, real_y])
    else:
        X, y = X_syn, y_syn

    model.train(X, y)
    try:
        model.save()
    except Exception:
        pass
    return model


def generate_signal(
    finance_result: dict,
    history: list[dict] | None = None,
    retrain: bool = False,
) -> dict:
    """
    Generate a trade signal for a single stock from its Finance Model 1 result.

    Returns:
      {
        symbol, name, sector,
        finance_score,
        signal:     'BULLISH' | 'NEUTRAL' | 'BEARISH',
        confidence: float (0–100),
        price_range: { current_price, target_low, target_high, target_mid, horizon_days },
        pillar_scores,
        generated_at,
      }
    """
    model = ensure_trained()
    features = _extract_features(finance_result)
    signal, confidence, proba = model.predict(features)

    price_range = _estimate_price_range(
        finance_result.get('quote'),
        signal,
        confidence,
        history,
    )

    return {
        'symbol':        finance_result.get('symbol'),
        'name':          finance_result.get('name'),
        'sector':        finance_result.get('sector'),
        'finance_score': finance_result.get('finance_score'),
        'signal':        signal,
        'confidence':    confidence,
        'class_proba': {
            'BEARISH': round(float(proba[0]) * 100, 1),
            'NEUTRAL': round(float(proba[1]) * 100, 1),
            'BULLISH': round(float(proba[2]) * 100, 1),
        },
        'price_range':   price_range,
        'pillar_scores': finance_result.get('pillar_scores'),
        'generated_at':  datetime.utcnow().isoformat(),
    }


def generate_signals_batch(
    finance_results: list[dict],
    histories: dict[str, list[dict]] | None = None,
) -> list[dict]:
    """Generate signals for all stocks. Returns list sorted by confidence desc."""
    model = ensure_trained()
    histories = histories or {}
    signals = []
    for fr in finance_results:
        try:
            sym = fr.get('symbol', '')
            sig = generate_signal(fr, history=histories.get(sym))
            signals.append(sig)
        except Exception as ex:
            signals.append({
                'symbol': fr.get('symbol'),
                'signal': 'NEUTRAL',
                'confidence': 0.0,
                'error': str(ex),
            })
    # Sort: BULLISH first by confidence, then BEARISH, then NEUTRAL
    order = {'BULLISH': 0, 'BEARISH': 1, 'NEUTRAL': 2}
    return sorted(signals, key=lambda s: (order.get(s.get('signal', 'NEUTRAL'), 2), -s.get('confidence', 0)))


def retrain_from_db(db) -> dict:
    """
    Retrain the signal model using historical TradeSignal rows from DB.
    Falls back to synthetic data if fewer than 50 historical rows exist.
    """
    from app.db.models import TradeSignal as TradeSignalModel

    rows = db.query(TradeSignalModel).filter(
        TradeSignalModel.actual_signal.isnot(None)
    ).all()

    real_X, real_y = None, None
    if len(rows) >= 50:
        X_list, y_list = [], []
        for row in rows:
            if row.feature_vector and row.actual_signal in SIGNAL_TO_INT:
                X_list.append(np.array(row.feature_vector, dtype=np.float32))
                y_list.append(SIGNAL_TO_INT[row.actual_signal])
        if X_list:
            real_X = np.array(X_list)
            real_y = np.array(y_list)

    global _model
    _model = SignalModel()
    trained = ensure_trained(real_X, real_y)

    return {
        'retrained_at':       datetime.utcnow().isoformat(),
        'real_samples_used':  len(real_X) if real_X is not None else 0,
        'total_samples':      trained._training_samples,
        'model_info':         trained.info(),
    }


def model_info() -> dict:
    return _get_model().info()
