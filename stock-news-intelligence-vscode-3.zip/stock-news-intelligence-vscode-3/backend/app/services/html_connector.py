from __future__ import annotations

import re
import time
from datetime import timezone
from email.utils import parsedate_to_datetime
from urllib.parse import urljoin, urlparse

import httpx
from bs4 import BeautifulSoup

from app.core.config import settings

BROWSER_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36 NewsIntelBot/1.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.9',
    'Cache-Control': 'no-cache',
    'Pragma': 'no-cache',
}
DEFAULT_ALLOWED = [
    '/news/business/', '/news/business/markets/', '/news/business/companies/',
    '/news/business/economy/', '/news/business/ipo/', '/news/markets/',
    '/stocksmarketsindia/', '/markets/', '/india/stockpricequote/',
]
DEFAULT_BLOCKED = [
    '/sports/', '/entertainment/', '/lifestyle/', '/web-stories/',
    '/photos/', '/videos/', '/news/trends/', '/education/', '/city/',
    '/technology/', '/astrology/', '/health-and-fitness/',
]


def normalize_url(url: str) -> str:
    parsed = urlparse(url)
    return parsed._replace(fragment='').geturl().rstrip('/')


def fetch_html(url: str) -> str:
    # verify=False — TLS verification disabled per IT team policy
    with httpx.Client(
        timeout=settings.html_article_timeout_seconds,
        headers=BROWSER_HEADERS,
        follow_redirects=True,
        verify=False,
    ) as client:
        response = client.get(url)
        response.raise_for_status()
        return response.text


def is_same_domain(url: str, base_url: str) -> bool:
    return urlparse(url).netloc.lower().endswith(
        urlparse(base_url).netloc.lower().replace('www.', '')
    )


def is_allowed_link(url: str, allowed_patterns, blocked_patterns) -> bool:
    path = urlparse(url).path.lower()
    allowed = allowed_patterns or DEFAULT_ALLOWED
    blocked = blocked_patterns or DEFAULT_BLOCKED
    if any(p.lower() in path for p in blocked):
        return False
    return any(p.lower() in path for p in allowed)


def extract_index_links(html: str, base_url: str, allowed_patterns=None, blocked_patterns=None, max_links: int = 80):
    soup = BeautifulSoup(html or '', 'html.parser')
    seen, links = set(), []
    for anchor in soup.find_all('a', href=True):
        href = anchor.get('href') or ''
        url = normalize_url(urljoin(base_url, href))
        if not url.startswith('http'):
            continue
        if not is_same_domain(url, base_url):
            continue
        if not is_allowed_link(url, allowed_patterns, blocked_patterns):
            continue
        if url in seen:
            continue
        seen.add(url)
        text = ' '.join(anchor.get_text(' ', strip=True).split())
        links.append({'url': url, 'anchor_text': text})
        if len(links) >= max_links:
            break
    return links


def clean_text(value: str | None) -> str:
    return re.sub(r'\s+', ' ', value or '').strip()


def meta_content(soup: BeautifulSoup, *names: str) -> str:
    for name in names:
        tag = (soup.find('meta', attrs={'property': name}) or
               soup.find('meta', attrs={'name': name}))
        if tag and tag.get('content'):
            return clean_text(tag.get('content'))
    return ''


def parse_date(value: str | None):
    if not value:
        return None
    try:
        return parsedate_to_datetime(value).astimezone(timezone.utc).replace(tzinfo=None)
    except Exception:
        try:
            from datetime import datetime
            return datetime.fromisoformat(
                value.replace('Z', '+00:00')
            ).astimezone(timezone.utc).replace(tzinfo=None)
        except Exception:
            return None


def extract_article(html: str, url: str, fallback_title: str = ''):
    soup = BeautifulSoup(html or '', 'html.parser')
    for tag in soup(['script', 'style', 'noscript', 'iframe', 'svg']):
        tag.decompose()
    title = meta_content(soup, 'og:title', 'twitter:title')
    if not title:
        h1 = soup.find('h1')
        title = clean_text(h1.get_text(' ', strip=True)) if h1 else fallback_title
    summary = meta_content(soup, 'og:description', 'description', 'twitter:description')
    published_raw = meta_content(soup, 'article:published_time', 'article:modified_time', 'pubdate')
    if not published_raw:
        time_tag = soup.find('time')
        if time_tag:
            published_raw = time_tag.get('datetime') or time_tag.get_text(' ', strip=True)
    candidates = []
    for selector in ['article', '[class*=article]', '[class*=story]', '[class*=content]', '[id*=article]', '[id*=content]']:
        for node in soup.select(selector)[:5]:
            text = clean_text(node.get_text(' ', strip=True))
            if len(text) > 250:
                candidates.append(text)
    content = (max(candidates, key=len) if candidates else
               clean_text(' '.join(p.get_text(' ', strip=True) for p in soup.find_all('p')[:30])))
    if not summary and content:
        summary = content[:320]
    return {
        'title': title,
        'url': url,
        'summary': summary,
        'content': content or f'{title}. {summary}',
        'published_at': parse_date(published_raw),
    }


def polite_sleep(milliseconds: int):
    if milliseconds and milliseconds > 0:
        time.sleep(milliseconds / 1000)
