from __future__ import annotations

import json
from typing import Any, Callable

from fastapi.encoders import jsonable_encoder

from app.core.config import settings

_client = None


def get_redis():
    """Return a live Redis client, or None if Redis is unavailable / disabled.

    The app must work without Redis — callers that get None skip the cache.
    """
    global _client
    if not getattr(settings, 'use_redis_cache', True):
        return None
    if _client is not None:
        # Quick liveness check — re-connect if the previous client went stale.
        try:
            _client.ping()
            return _client
        except Exception:
            _client = None
    try:
        import redis
        _client = redis.Redis.from_url(
            settings.redis_url,
            decode_responses=True,
            socket_connect_timeout=1,
            socket_timeout=2,
        )
        _client.ping()
        return _client
    except Exception:
        _client = None
        return None


def cache_set_json(key: str, value: Any, ttl: int | None = None) -> None:
    client = get_redis()
    if not client:
        return
    try:
        payload = json.dumps(jsonable_encoder(value), ensure_ascii=False)
        # FIX: use settings attributes directly; they are always present because
        # config.py declares them explicitly.  The old getattr fallback masked
        # missing fields during startup.
        effective_ttl = ttl or settings.redis_cache_ttl_seconds
        client.setex(key, effective_ttl, payload)
    except Exception:
        return


def cache_get_json(key: str, default=None):
    client = get_redis()
    if not client:
        return default
    try:
        raw = client.get(key)
        if not raw:
            return default
        return json.loads(raw)
    except Exception:
        return default


def cache_delete(key: str) -> bool:
    """Delete a single cache key.  Returns True if the key existed."""
    client = get_redis()
    if not client:
        return False
    try:
        return bool(client.delete(key))
    except Exception:
        return False


def cache_delete_pattern(pattern: str) -> int:
    """Delete all keys matching a Redis glob pattern.  Returns count deleted."""
    client = get_redis()
    if not client:
        return 0
    deleted = 0
    try:
        for key in client.scan_iter(match=pattern, count=200):
            deleted += client.delete(key)
    except Exception:
        pass
    return deleted


def invalidate_api_cache() -> int:
    """Delete all api: prefixed cache keys.

    Keeps last-good fallback keys (last:*) intact so the UI can still
    show stale data while a fresh ingestion run is in progress.
    """
    return cache_delete_pattern('api:*')


def cached_or_compute(
    key: str,
    compute: Callable[[], Any],
    ttl: int | None = None,
    allow_empty: bool = False,
) -> Any:
    """Return cached value if present; otherwise call compute(), cache, and return.

    When Redis is unavailable, compute() is called on every request — the app
    degrades gracefully with no caching rather than erroring.

    allow_empty=True: cache and return the result even when it is falsy
    (empty list, 0, etc.) so that callers can distinguish "not cached" (None)
    from "cached empty result" ([] / 0 / {}).
    """
    cached = cache_get_json(key, None)
    if cached is not None:
        return cached
    value = compute()
    if allow_empty or value:
        cache_set_json(key, value, ttl or settings.api_cache_ttl_seconds)
    return value
