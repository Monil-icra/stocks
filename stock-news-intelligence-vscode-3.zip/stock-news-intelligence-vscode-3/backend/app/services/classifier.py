IPO_KEYWORDS = {'ipo announced':'ipo_announced','drhp':'drhp_filed','draft red herring':'drhp_filed','rhp':'rhp_filed','ipo opens':'ipo_opens','subscription':'subscription','ipo closes':'ipo_closes','allotment':'allotment','listing':'listing'}
TRADE_KEYWORDS = ['fta','free trade agreement','trade agreement','tariff','tariffs','sanctions','import duty','export duty','customs duty','trade war','market access','export restrictions','import restrictions','quota','india-us','india-uk','india-eu','india-australia']
SECTOR_KEYWORDS = {'IT':['software','technology','it services','cloud','ai'], 'Banking':['bank','nbfc','lending','credit','deposit','loan'], 'Pharma':['drug','pharma','api','usfda'], 'Auto':['vehicle','ev','auto','two-wheeler','car'], 'Metals':['steel','aluminium','copper','metal'], 'Energy':['oil','gas','refinery','renewable','solar'], 'Telecom':['telecom','5g','spectrum']}

def classify(text: str) -> str:
    low = text.lower()
    if any(k in low for k in IPO_KEYWORDS): return 'ipo'
    if any(k in low for k in TRADE_KEYWORDS): return 'trade'
    if any(k in low for k in ['result','earnings','quarter','profit','revenue','margin']): return 'earnings'
    return 'market_news'

def sectors(text: str):
    low = text.lower()
    return [s for s, keys in SECTOR_KEYWORDS.items() if any(k in low for k in keys)]

def ipo_events(text: str):
    low = text.lower()
    return sorted(set(v for k, v in IPO_KEYWORDS.items() if k in low))

def trade_event(text: str):
    low = text.lower()
    hits = [k for k in TRADE_KEYWORDS if k in low]
    sec = sectors(text)
    direction = 'negative' if any(k in low for k in ['tariff','sanctions','trade war','duty']) else 'positive' if hits else 'none'
    confidence = min(95, 20 + 15 * len(hits) + 10 * len(sec)) if hits else 0
    return {'hits': hits, 'sectors': sec, 'direction': direction, 'confidence': confidence}
