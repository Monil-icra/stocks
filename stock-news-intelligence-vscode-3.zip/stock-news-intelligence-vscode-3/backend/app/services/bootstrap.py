from __future__ import annotations

from datetime import datetime
from pathlib import Path
from threading import Thread
import traceback

from app.core.config import settings
from app.db.session import SessionLocal
from app.services.ingest import ingest_all
from app.services.lock import acquire_ingestion_lock, release_ingestion_lock
from app.services.cache import invalidate_api_cache


def _log(message: str):
    path = Path('./logs/startup_bootstrap.log')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a', encoding='utf-8') as f:
        f.write(f'[{datetime.utcnow().isoformat(timespec="seconds")}Z] {message}\n')


def _run():
    db = SessionLocal()
    owner = 'startup-bootstrap'
    acquired = False
    try:
        _log('START startup bootstrap ingestion')
        acquired = acquire_ingestion_lock(db, owner)
        if not acquired:
            _log('SKIP lock already held')
            return
        result = ingest_all(db, mode='startup-bootstrap', due_only=False)
        invalidate_api_cache()
        _log(f'DONE result={result}')
    except Exception as ex:
        # FIX: rollback before attempting lock release so session is in clean state
        try:
            db.rollback()
        except Exception:
            pass
        _log(f'ERROR {ex}\n{traceback.format_exc()}')
    finally:
        # FIX: always attempt lock release in the outermost finally block,
        # with its own try/except so a release failure never prevents db.close().
        if acquired:
            try:
                release_ingestion_lock(db, owner)
            except Exception as ex:
                try:
                    db.rollback()
                except Exception:
                    pass
                _log(f'WARN release lock failed {ex}')
        try:
            db.close()
        except Exception:
            pass


def start_startup_bootstrap():
    if not settings.startup_bootstrap_ingest:
        _log('DISABLED startup bootstrap ingestion')
        return {'started': False, 'reason': 'disabled'}
    thread = Thread(target=_run, name='startup-bootstrap-ingest', daemon=True)
    thread.start()
    _log('THREAD started')
    return {'started': True}
