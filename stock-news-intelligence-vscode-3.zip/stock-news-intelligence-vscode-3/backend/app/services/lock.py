from __future__ import annotations
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.models import IngestionLock


def utcnow():
    return datetime.utcnow()


def acquire_ingestion_lock(db: Session, owner: str) -> bool:
    now = utcnow()
    ttl = timedelta(seconds=settings.ingestion_lock_ttl_seconds)
    try:
        lock = db.get(IngestionLock, 1)
        if lock and lock.locked_until and lock.locked_until > now:
            return False
        if not lock:
            lock = IngestionLock(id=1, owner=owner, locked_until=now + ttl)
            db.add(lock)
        else:
            lock.owner = owner
            lock.locked_until = now + ttl
            lock.updated_at = now
        db.commit()
        return True
    except Exception:
        # FIX: rollback so session stays usable after a failed acquire (e.g. DB locked)
        try:
            db.rollback()
        except Exception:
            pass
        return False


def release_ingestion_lock(db: Session, owner: str) -> None:
    try:
        lock = db.get(IngestionLock, 1)
        if lock and lock.owner == owner:
            # Set locked_until to 1 second in the past so it is immediately available
            lock.locked_until = utcnow() - timedelta(seconds=1)
            lock.updated_at = utcnow()
            db.commit()
    except Exception:
        # FIX: rollback on error so the session is left in a clean state.
        # Without this, any subsequent db operation on the same session would fail
        # with "transaction already rolled back / in error state".
        try:
            db.rollback()
        except Exception:
            pass
        raise
