from __future__ import annotations

import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from types import SimpleNamespace

import feedparser
import httpx
from fastapi.encoders import jsonable_encoder
from bs4 import BeautifulSoup
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import SessionLocal
from app.db.models import (
    Article,
    ArticleEntity,
    ImpactScore,
    IngestionRun,
    IPOEvent,
    NewsEmbedding,
    RSSSource,
    SentimentAnalysis,
    TradeEvent,
)
from app.services.cache import cache_set_json
from app.services.classifier import classify, ipo_events, sectors, trade_event
from app.services.company import detect_companies
from app.services.html_connector import extract_article, extract_index_links, fetch_html, polite_sleep
from app.services.impact import calculate
from app.services.nlp import analyze_entities, embedding, sentiment
from app.services.sitemap_connector import sitemap_entries_for_source as connector_sitemap_entries_for_source


def clean_html(value: str | None):
    return BeautifulSoup(value or '', 'html.parser').get_text(' ', strip=True)


def sha(value: str):
    return hashlib.sha256((value or '').encode('utf-8', 'ignore')).hexdigest()


def parse_date(value):
    if not value:
        return None
    try:
        return parsedate_to_datetime(value).astimezone(timezone.utc).replace(tzinfo=None)
    except Exception:
        return None


def utcnow():
    return datetime.utcnow()


def is_source_due(src: RSSSource, now):
    if not src.enabled:
        return False
    if src.next_run_at and src.next_run_at > now:
        return False
    return True


def update_source_success(src: RSSSource, inserted: int):
    now = utcnow()
    src.last_checked_at = now
    src.last_success_at = now
    src.last_error = None
    src.consecutive_failures = 0
    src.status = 'healthy'
    src.next_run_at = now + timedelta(seconds=max(60, src.interval_seconds or settings.ingestion_interval_seconds))


def update_source_failure(src: RSSSource, error: str):
    now = utcnow()
    src.last_checked_at = now
    src.last_error_at = now
    src.last_error = error[:2000]
    src.consecutive_failures = (src.consecutive_failures or 0) + 1
    if '404' in error or '410' in error:
        src.status = 'disabled'
        src.enabled = False
        src.next_run_at = now + timedelta(days=365)
    elif '403' in error:
        src.status = 'blocked'
        src.next_run_at = now + timedelta(minutes=30)
    else:
        src.status = 'degraded'
        backoff = min(3600, 60 * max(1, src.consecutive_failures))
        src.next_run_at = now + timedelta(seconds=backoff)


def snapshot_source(src: RSSSource):
    return {
        'id': src.id,
        'name': src.name,
        'url': src.url,
        'credibility': src.credibility,
        'category': src.category,
        'source_type': src.source_type or 'rss',
        'allowed_patterns': src.allowed_patterns or [],
        'blocked_patterns': src.blocked_patterns or [],
        'article_limit': src.article_limit or settings.html_connector_max_links,
        'polite_delay_ms': src.polite_delay_ms or 500,
    }


def rss_entries_for_source(src):
    headers = {
        'User-Agent': settings.user_agent,
        'Accept': 'application/rss+xml, application/xml, text/xml, */*',
        'Accept-Language': 'en-US,en;q=0.9',
    }
    with httpx.Client(timeout=settings.fetch_timeout_seconds, headers=headers, follow_redirects=True, verify=False) as client:
        response = client.get(src.url)
        response.raise_for_status()
    parsed = feedparser.parse(response.text)
    entries = []
    for entry in parsed.entries[: settings.rss_entries_per_source]:
        url = entry.get('link') or entry.get('id') or ''
        title = clean_html(entry.get('title', ''))
        summary = clean_html(entry.get('summary', ''))
        if not url or not title:
            continue
        content = f'{title}. {summary}'
        entries.append({
            'url': url,
            'title': title,
            'summary': summary,
            'content': content,
            'published_at': parse_date(entry.get('published') or entry.get('updated')),
        })
    return entries, len(parsed.entries or [])


def html_entries_for_source(src):
    index_html = fetch_html(src.url)
    links = extract_index_links(
        index_html,
        src.url,
        allowed_patterns=src.allowed_patterns or [],
        blocked_patterns=src.blocked_patterns or [],
        max_links=min(settings.html_connector_max_links, src.article_limit or 40),
    )
    entries = []
    for link in links[: src.article_limit or 40]:
        try:
            polite_sleep(src.polite_delay_ms or 500)
            article_html = fetch_html(link['url'])
            article = extract_article(article_html, link['url'], fallback_title=link.get('anchor_text') or '')
            if article.get('title') and article.get('url'):
                entries.append(article)
        except Exception:
            continue
    return entries, len(links)


def sitemap_entries_for_source(db: Session, src):
    # FIX: pass real db (or None — connector accepts None), not hardcoded None.
    # The connector does not use db, but we keep the signature consistent.
    return connector_sitemap_entries_for_source(db, src)


# FIX: selenium_sitemap_index and selenium_sitemap types must route to sitemap connector,
# NOT fall through to RSS. Previously only 'html_index' and 'sitemap_xml' were handled;
# Moneycontrol (selenium_sitemap_index) fell through to rss_entries_for_source and
# tried to parse the sitemap index XML as an RSS feed, returning 0 entries every time.
def fetch_source_worker(source_snapshot: dict):
    src = SimpleNamespace(**source_snapshot)
    try:
        source_type = src.source_type or 'rss'
        if source_type == 'html_index':
            entries, seen = html_entries_for_source(src)
        elif source_type in ('sitemap_xml', 'selenium_sitemap', 'selenium_sitemap_index'):
            # selenium_sitemap and selenium_sitemap_index route through sitemap_connector,
            # which sets force_selenium=True based on source_type. No httpx fallback used.
            entries, seen = sitemap_entries_for_source(None, src)
        else:
            # Default: RSS (covers 'rss' and any unknown future types)
            entries, seen = rss_entries_for_source(src)
        return {
            'source_id': src.id,
            'source': src.name,
            'source_type': source_type,
            'entries': entries,
            'seen': seen,
            'error': None,
        }
    except Exception as ex:
        return {
            'source_id': src.id,
            'source': src.name,
            'source_type': src.source_type,
            'entries': [],
            'seen': 0,
            'error': str(ex),
        }


def persist_article(db: Session, src: RSSSource, item: dict):
    url = item['url']
    title = item['title']
    summary = item.get('summary') or ''
    content = item.get('content') or f'{title}. {summary}'
    article = Article(
        source_id=src.id,
        title=title,
        url=url,
        url_hash=sha(url),
        content_hash=sha(content),
        summary=summary,
        content=content,
        published_at=item.get('published_at'),
        category=classify(content),
    )
    db.add(article)
    db.flush()
    sent = sentiment(content)
    db.add(SentimentAnalysis(article_id=article.id, **sent))
    sec = sectors(content)
    matched = detect_companies(content)
    for c in matched:
        db.add(ArticleEntity(
            article_id=article.id,
            entity_text=c['name'],
            entity_type='COMPANY',
            nse_symbol=c['nse'],
            bse_symbol=c['bse'],
            sector=c['sector'],
            confidence=c['confidence'],
        ))
        score, explanation = calculate(sent['score'], c['importance'], 80 if c['sector'] in sec else 60, src.credibility)
        db.add(ImpactScore(article_id=article.id, company_name=c['name'], sector=c['sector'], score=score, explanation=explanation))
    for ent in analyze_entities(content):
        if ent['label'] in {'ORG', 'GPE', 'MONEY', 'PRODUCT'}:
            db.add(ArticleEntity(article_id=article.id, entity_text=ent['text'], entity_type=ent['label'], confidence=70))
    if not matched and sec:
        score, explanation = calculate(sent['score'], 40, 70, src.credibility)
        db.add(ImpactScore(article_id=article.id, company_name=None, sector=sec[0], score=score, explanation=explanation))
    for ev in ipo_events(content):
        db.add(IPOEvent(article_id=article.id, company_name=title[:240], event_type=ev, status=ev, event_date=article.published_at))
    tr = trade_event(content)
    if tr['hits']:
        db.add(TradeEvent(article_id=article.id, event_type=','.join(tr['hits'])[:120], affected_sectors=tr['sectors'], direction=tr['direction'], confidence=tr['confidence']))
    vec, engine = embedding(content)
    db.add(NewsEmbedding(article_id=article.id, vector=vec[:384], engine=engine))
    return article


def ingest_all(db: Session, mode: str = 'manual', due_only: bool = False):
    run = IngestionRun(mode=mode, status='running', summary={})
    db.add(run)
    db.commit()
    db.refresh(run)

    total = 0
    detail = []
    exc_to_raise = None

    try:
        now = utcnow()
        sources = db.query(RSSSource).filter(RSSSource.enabled == True).all()
        if due_only:
            sources = [src for src in sources if is_source_due(src, now)]
        snapshots = [snapshot_source(src) for src in sources]
        results = []
        if snapshots:
            with ThreadPoolExecutor(max_workers=max(1, settings.ingestion_worker_count)) as pool:
                futures = [pool.submit(fetch_source_worker, snap) for snap in snapshots]
                for future in as_completed(futures):
                    results.append(future.result())

        for result in results:
            src = db.get(RSSSource, result['source_id'])
            if not src:
                continue
            inserted = 0
            duplicates = 0
            if result['error']:
                update_source_failure(src, result['error'])
                db.commit()
                detail.append({
                    'source': src.name,
                    'source_type': src.source_type,
                    'inserted': 0,
                    'seen': result.get('seen', 0),
                    'duplicates': 0,
                    'error': result['error'],
                    'status': src.status,
                    # FIX: next_run_at is a datetime; jsonable_encoder handles it, but
                    # we must not put raw datetime into a dict that goes into JSON column directly.
                    'next_run_at': src.next_run_at.isoformat() if src.next_run_at else None,
                })
                continue
            for item in result['entries']:
                if db.query(Article.id).filter(Article.url_hash == sha(item['url'])).first():
                    duplicates += 1
                    continue
                try:
                    persist_article(db, src, item)
                    inserted += 1
                except Exception as persist_ex:
                    # FIX: rollback on persist failure so the session stays usable
                    db.rollback()
                    detail.append({
                        'source': src.name,
                        'source_type': src.source_type,
                        'inserted': 0,
                        'seen': 1,
                        'duplicates': 0,
                        'error': f'persist_article failed: {persist_ex}',
                        'status': src.status,
                        'next_run_at': None,
                    })
                    continue
            update_source_success(src, inserted)
            db.commit()
            total += inserted
            detail.append({
                'source': src.name,
                'source_type': src.source_type,
                'inserted': inserted,
                'seen': result.get('seen', len(result['entries'])),
                'duplicates': duplicates,
                'error': None,
                'status': src.status,
                'next_run_at': src.next_run_at.isoformat() if src.next_run_at else None,
            })

        run.status = 'completed'

    except Exception as ex:
        exc_to_raise = ex
        run.status = 'failed'
        try:
            db.rollback()
        except Exception:
            pass

    finally:
        run.finished_at = utcnow()
        run.inserted = total
        # FIX: always build summary after total/detail are finalised, using only
        # JSON-safe types. jsonable_encoder converts datetime, Decimal, etc.
        # Never embed raw ORM objects or datetime into run.summary directly.
        run.summary = jsonable_encoder({'sources': detail, 'error': str(exc_to_raise) if exc_to_raise else None})
        try:
            db.add(run)
            db.commit()
        except Exception:
            try:
                db.rollback()
                db.add(run)
                db.commit()
            except Exception:
                pass

        # FIX: cache the latest 200 articles using jsonable_encoder so datetime fields
        # are serialised as ISO strings, not raw Python datetime objects (which break json.dumps).
        try:
            latest = db.query(Article).order_by(Article.fetched_at.desc()).limit(200).all()
            if latest:
                cache_set_json('news:last', jsonable_encoder(latest))
        except Exception:
            pass

    if exc_to_raise:
        raise exc_to_raise

    return jsonable_encoder({
        'inserted': total,
        'sources': detail,
        'run_id': run.id,
        'mode': mode,
        'workers': settings.ingestion_worker_count,
    })
