import hashlib, random
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from app.core.config import settings

analyzer = SentimentIntensityAnalyzer()
_spacy = None
_transformer = None
_embedder = None

def load_spacy():
    global _spacy
    if _spacy is not None: return _spacy
    if not settings.enable_spacy: return None
    try:
        import spacy
        try: _spacy = spacy.load('en_core_web_sm')
        except Exception: _spacy = spacy.blank('en')
    except Exception:
        _spacy = None
    return _spacy

def load_transformer():
    global _transformer
    if _transformer is not None: return _transformer
    if not settings.enable_transformers: return None
    try:
        from transformers import pipeline
        _transformer = pipeline('sentiment-analysis')
    except Exception:
        _transformer = None
    return _transformer

def load_embedder():
    global _embedder
    if _embedder is not None: return _embedder
    try:
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer('all-MiniLM-L6-v2')
    except Exception:
        _embedder = None
    return _embedder

def analyze_entities(text: str):
    nlp = load_spacy()
    if not nlp: return []
    doc = nlp(text[:100000])
    return [{'text': ent.text, 'label': ent.label_} for ent in getattr(doc, 'ents', [])]

def sentiment(text: str):
    vader = analyzer.polarity_scores(text or '')['compound']
    score = round(vader * 100, 2)
    engine = 'vader'
    transformer = load_transformer()
    if transformer:
        try:
            res = transformer((text or '')[:512])[0]
            label = res['label'].lower()
            conf = float(res['score'])
            if 'neg' in label: score = round(-100 * conf, 2)
            elif 'pos' in label: score = round(100 * conf, 2)
            engine = 'transformers'
        except Exception:
            pass
    label = 'positive' if score > 15 else 'negative' if score < -15 else 'neutral'
    return {'label': label, 'score': score, 'engine': engine}

def embedding(text: str):
    model = load_embedder()
    if model:
        try: return model.encode(text[:5000]).tolist(), 'sentence-transformers'
        except Exception: pass
    seed = int(hashlib.sha256((text or '').encode()).hexdigest()[:8], 16)
    rnd = random.Random(seed)
    return [rnd.uniform(-1, 1) for _ in range(384)], 'fallback'
