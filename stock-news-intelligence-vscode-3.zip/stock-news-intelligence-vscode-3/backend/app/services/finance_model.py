"""
finance_model.py — Finance Model 1

Aggregates five signal pillars per stock and produces a single
normalized FinanceScore (0–100) plus a structured breakdown used
by Model 2 (signal_model.py) for trade signal generation.

Pillars:
  1. Earnings Quality    — YoY revenue/profit growth, margins, EPS trend
  2. Holding Pattern     — promoter stake, FII/DII momentum, pledging
  3. Corporate Events    — results, splits, bonuses, buybacks, AGM/EGM
  4. News Sentiment      — weighted average of recent article sentiments
  5. Technical Snapshot  — 52-week position, beta, volume trend

All inputs are optional.  Missing pillars are weighted at 0 so the
model degrades gracefully when data is sparse.
"""
from __future__ import annotations

import math
from datetime import datetime, timezone, timedelta
from typing import Any

from sqlalchemy.orm import Session

from app.db.models import (
    Article,
    ArticleEntity,
    CorporateEvent,
    EarningsResult,
    HoldingPattern,
    ImpactScore,
    SentimentAnalysis,
    StockUniverse,
)
from app.services.nifty250 import get_by_symbol


# ─── weights for each pillar (must sum to 1.0) ────────────────────────────────
PILLAR_WEIGHTS = {
    'earnings':   0.30,
    'holding':    0.20,
    'events':     0.15,
    'sentiment':  0.25,
    'technical':  0.10,
}


def _safe_float(value, fallback: float = 0.0) -> float:
    if value is None:
        return fallback
    try:
        f = float(value)
        return fallback if math.isnan(f) or math.isinf(f) else f
    except (TypeError, ValueError):
        return fallback


def _clamp(value: float, lo: float = 0.0, hi: float = 100.0) -> float:
    return max(lo, min(hi, value))


# ─── Pillar 1: Earnings Quality ───────────────────────────────────────────────

def _score_earnings(rows: list[EarningsResult]) -> tuple[float, dict]:
    """Score based on the most recent 4 quarters of earnings."""
    if not rows:
        return 0.0, {'available': False}

    rows = sorted(rows, key=lambda r: r.period_end or datetime.min, reverse=True)[:4]
    latest = rows[0]

    revenue_growth = _safe_float(latest.revenue_yoy_pct)
    profit_growth  = _safe_float(latest.net_profit_yoy_pct)
    margin         = _safe_float(latest.net_margin_pct)
    eps_growth     = _safe_float(latest.eps_yoy_pct)
    beat_estimate  = latest.beat_estimate  # True/False/None

    # Revenue growth: 20%+ = 100, 0% = 50, -20% = 0
    rev_score  = _clamp(50 + revenue_growth * 2.5)
    # Profit growth: 30%+ = 100, 0% = 50
    pft_score  = _clamp(50 + profit_growth * 1.67)
    # Net margin: >20% great, <0% bad
    marg_score = _clamp(margin * 5)
    # EPS growth
    eps_score  = _clamp(50 + eps_growth * 1.67)
    # Beat estimate bonus
    beat_score = 75.0 if beat_estimate is True else (25.0 if beat_estimate is False else 50.0)

    score = (
        rev_score  * 0.25 +
        pft_score  * 0.30 +
        marg_score * 0.20 +
        eps_score  * 0.15 +
        beat_score * 0.10
    )

    # Consecutive beats bonus
    beats = sum(1 for r in rows if r.beat_estimate is True)
    score = _clamp(score + beats * 2.5)

    return score, {
        'available': True,
        'quarters':  len(rows),
        'revenue_growth_pct': revenue_growth,
        'profit_growth_pct':  profit_growth,
        'net_margin_pct':     margin,
        'eps_growth_pct':     eps_growth,
        'beat_estimate':      beat_estimate,
        'consecutive_beats':  beats,
        'score':              round(score, 2),
    }


# ─── Pillar 2: Holding Pattern ────────────────────────────────────────────────

def _score_holding(rows: list[HoldingPattern]) -> tuple[float, dict]:
    if not rows:
        return 0.0, {'available': False}

    rows = sorted(rows, key=lambda r: r.period_date or datetime.min, reverse=True)
    latest = rows[0]

    promoter    = _safe_float(latest.promoter_pct, 50)
    fii         = _safe_float(latest.fii_pct, 20)
    dii         = _safe_float(latest.dii_pct, 15)
    pledge      = _safe_float(latest.pledged_pct, 0)
    fii_change  = _safe_float(latest.fii_change_pct, 0)
    dii_change  = _safe_float(latest.dii_change_pct, 0)

    # Promoter: 60%+ = excellent, <30% = concern
    promoter_score = _clamp((promoter - 30) / 40 * 100)
    # FII/DII combined: higher is better signal of institutional confidence
    inst_score = _clamp((fii + dii) * 1.25)
    # Pledge: 0% = 100, 50%+ = 0
    pledge_score = _clamp(100 - pledge * 2)
    # FII/DII change momentum (buying = positive, selling = negative)
    momentum_score = _clamp(50 + (fii_change + dii_change) * 5)

    score = (
        promoter_score * 0.30 +
        inst_score     * 0.25 +
        pledge_score   * 0.30 +
        momentum_score * 0.15
    )

    # QoQ change if available
    qoq = {}
    if len(rows) > 1:
        prev = rows[1]
        qoq['promoter_change'] = round(promoter - _safe_float(prev.promoter_pct, promoter), 2)
        qoq['fii_change']      = round(fii - _safe_float(prev.fii_pct, fii), 2)

    return score, {
        'available':     True,
        'promoter_pct':  promoter,
        'fii_pct':       fii,
        'dii_pct':       dii,
        'pledged_pct':   pledge,
        'fii_change':    fii_change,
        'dii_change':    dii_change,
        'qoq':           qoq,
        'score':         round(score, 2),
    }


# ─── Pillar 3: Corporate Events ───────────────────────────────────────────────

_POSITIVE_EVENTS = {
    'bonus_issue', 'stock_split', 'buyback', 'dividend',
    'order_win', 'acquisition', 'partnership', 'capacity_expansion',
    'listing', 'rights_issue',
}
_NEGATIVE_EVENTS = {
    'promoter_selling', 'fii_selling', 'dii_selling', 'recall',
    'litigation', 'fraud', 'downgrade', 'merger_risk', 'delisting',
}
_NEUTRAL_EVENTS = {
    'agm', 'egm', 'board_meeting', 'record_date',
}


def _score_events(rows: list[CorporateEvent]) -> tuple[float, dict]:
    if not rows:
        return 50.0, {'available': False, 'score': 50.0}  # neutral baseline

    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=90)
    recent = [r for r in rows if (r.event_date or datetime.min) >= cutoff]

    score = 50.0
    summary = []
    for ev in recent:
        ev_type = (ev.event_type or '').lower().replace(' ', '_')
        if any(p in ev_type for p in _POSITIVE_EVENTS):
            score += 5.0
            summary.append({'type': ev.event_type, 'sentiment': 'positive'})
        elif any(n in ev_type for n in _NEGATIVE_EVENTS):
            score -= 7.0
            summary.append({'type': ev.event_type, 'sentiment': 'negative'})
        else:
            summary.append({'type': ev.event_type, 'sentiment': 'neutral'})

    score = _clamp(score)
    return score, {
        'available':     True,
        'recent_events': len(recent),
        'summary':       summary[:10],
        'score':         round(score, 2),
    }


# ─── Pillar 4: News Sentiment ─────────────────────────────────────────────────

def _score_sentiment(
    db: Session,
    symbol: str,
    lookback_days: int = 30,
) -> tuple[float, dict]:
    """
    Join Articles → SentimentAnalysis → ArticleEntity for this symbol.
    Weight recent articles more heavily (exponential decay over lookback).
    """
    cutoff = datetime.utcnow() - timedelta(days=lookback_days)
    rows = (
        db.query(Article, SentimentAnalysis)
        .join(SentimentAnalysis, SentimentAnalysis.article_id == Article.id)
        .join(ArticleEntity, ArticleEntity.article_id == Article.id)
        .filter(
            ArticleEntity.nse_symbol == symbol,
            Article.fetched_at >= cutoff,
        )
        .order_by(Article.fetched_at.desc())
        .limit(100)
        .all()
    )

    if not rows:
        # Try by company name match (ArticleEntity.entity_text contains stock name)
        stock_info = get_by_symbol(symbol)
        if stock_info:
            name = stock_info['name']
            rows = (
                db.query(Article, SentimentAnalysis)
                .join(SentimentAnalysis, SentimentAnalysis.article_id == Article.id)
                .join(ArticleEntity, ArticleEntity.article_id == Article.id)
                .filter(
                    ArticleEntity.entity_text.ilike(f'%{name[:15]}%'),
                    Article.fetched_at >= cutoff,
                )
                .order_by(Article.fetched_at.desc())
                .limit(50)
                .all()
            )

    if not rows:
        return 50.0, {'available': False, 'score': 50.0}

    now = datetime.utcnow()
    weighted_score = 0.0
    total_weight = 0.0
    label_counts: dict[str, int] = {'positive': 0, 'negative': 0, 'neutral': 0}

    for article, sent in rows:
        age_days = max(0, (now - (article.fetched_at or now)).days)
        # Exponential decay: weight halves every 7 days
        w = math.exp(-0.693 * age_days / 7)
        raw_score = _safe_float(sent.score, 0)  # -100 to +100
        normalized = _clamp(50 + raw_score * 0.5)  # map to 0–100
        weighted_score += normalized * w
        total_weight += w
        label = (sent.label or 'neutral').lower()
        label_counts[label] = label_counts.get(label, 0) + 1

    score = weighted_score / total_weight if total_weight > 0 else 50.0

    return score, {
        'available':    True,
        'article_count': len(rows),
        'label_counts':  label_counts,
        'lookback_days': lookback_days,
        'score':         round(score, 2),
    }


# ─── Pillar 5: Technical Snapshot ────────────────────────────────────────────

def _score_technical(quote: dict | None) -> tuple[float, dict]:
    if not quote or not quote.get('price'):
        return 50.0, {'available': False, 'score': 50.0}

    price        = _safe_float(quote.get('price'))
    week52_high  = _safe_float(quote.get('week52_high'))
    week52_low   = _safe_float(quote.get('week52_low'))
    prev_close   = _safe_float(quote.get('prev_close'))
    beta         = _safe_float(quote.get('beta'), 1.0)
    pe           = _safe_float(quote.get('pe_ratio'))

    score = 50.0

    # 52-week position: near high = bullish, near low = bearish
    if week52_high and week52_low and week52_high > week52_low:
        position = (price - week52_low) / (week52_high - week52_low)
        score += (position - 0.5) * 40  # -20 to +20

    # Daily change
    if prev_close and prev_close > 0:
        daily_chg = (price - prev_close) / prev_close * 100
        score += _clamp(daily_chg * 3, -10, 10)

    # PE ratio: very high or very low = adjust score slightly
    if pe and pe > 0:
        if pe < 15:
            score += 5   # undervalued
        elif pe > 60:
            score -= 5   # richly valued

    # Beta: low beta = stability bonus
    if beta < 0.8:
        score += 3
    elif beta > 1.5:
        score -= 3

    score = _clamp(score)
    return score, {
        'available':     True,
        'price':         price,
        'week52_high':   week52_high,
        'week52_low':    week52_low,
        'daily_change':  round(price - prev_close, 2) if prev_close else None,
        'daily_change_pct': round((price - prev_close) / prev_close * 100, 2) if prev_close else None,
        'beta':          beta,
        'pe_ratio':      pe,
        'score':         round(score, 2),
    }


# ─── Main: compute_finance_score ─────────────────────────────────────────────

def compute_finance_score(
    db: Session,
    symbol: str,
    quote: dict | None = None,
    lookback_days: int = 30,
) -> dict:
    """
    Compute Finance Model 1 score for a stock.

    Returns a dict with:
      - finance_score  (0–100, higher = stronger fundamentals + sentiment)
      - signal_tier    ('STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL')
      - pillar_scores  (breakdown by pillar)
      - raw_inputs     (all data used)
    """
    sym = symbol.upper()

    # Load DB data
    earnings_rows = (
        db.query(EarningsResult)
        .filter(EarningsResult.symbol == sym)
        .order_by(EarningsResult.period_end.desc())
        .limit(8)
        .all()
    )
    holding_rows = (
        db.query(HoldingPattern)
        .filter(HoldingPattern.symbol == sym)
        .order_by(HoldingPattern.period_date.desc())
        .limit(4)
        .all()
    )
    event_rows = (
        db.query(CorporateEvent)
        .filter(CorporateEvent.symbol == sym)
        .order_by(CorporateEvent.event_date.desc())
        .limit(20)
        .all()
    )

    # Score each pillar
    e_score, e_detail  = _score_earnings(earnings_rows)
    h_score, h_detail  = _score_holding(holding_rows)
    ev_score, ev_detail = _score_events(event_rows)
    s_score, s_detail  = _score_sentiment(db, sym, lookback_days)
    t_score, t_detail  = _score_technical(quote)

    # Compute active weights (zero out unavailable pillars, renormalize)
    active = {
        'earnings':  e_score  if e_detail.get('available') else None,
        'holding':   h_score  if h_detail.get('available') else None,
        'events':    ev_score if ev_detail.get('available') else None,
        'sentiment': s_score  if s_detail.get('available') else None,
        'technical': t_score  if t_detail.get('available') else None,
    }
    w_total = sum(PILLAR_WEIGHTS[k] for k, v in active.items() if v is not None)
    if w_total == 0:
        w_total = 1.0  # fallback: avoid division by zero

    finance_score = sum(
        (v / 100) * PILLAR_WEIGHTS[k] * 100
        for k, v in active.items()
        if v is not None
    ) / w_total * 100 / 100  # normalized back

    # Simpler: weighted average
    numerator = sum(
        v * PILLAR_WEIGHTS[k]
        for k, v in active.items()
        if v is not None
    )
    finance_score = _clamp(numerator / w_total)

    # Signal tier
    if finance_score >= 75:
        signal_tier = 'STRONG_BUY'
    elif finance_score >= 60:
        signal_tier = 'BUY'
    elif finance_score >= 45:
        signal_tier = 'HOLD'
    elif finance_score >= 30:
        signal_tier = 'SELL'
    else:
        signal_tier = 'STRONG_SELL'

    stock_info = get_by_symbol(sym) or {}

    return {
        'symbol':        sym,
        'name':          stock_info.get('name', sym),
        'sector':        stock_info.get('sector', ''),
        'finance_score': round(finance_score, 2),
        'signal_tier':   signal_tier,
        'computed_at':   datetime.utcnow().isoformat(),
        'pillar_scores': {
            'earnings':  round(e_score, 2),
            'holding':   round(h_score, 2),
            'events':    round(ev_score, 2),
            'sentiment': round(s_score, 2),
            'technical': round(t_score, 2),
        },
        'pillar_details': {
            'earnings':  e_detail,
            'holding':   h_detail,
            'events':    ev_detail,
            'sentiment': s_detail,
            'technical': t_detail,
        },
        'weights_used': {k: round(PILLAR_WEIGHTS[k] / w_total, 4) for k in PILLAR_WEIGHTS},
        'quote':         quote,
    }


def batch_compute_finance_scores(
    db: Session,
    symbols: list[str],
    quotes: dict[str, dict] | None = None,
    lookback_days: int = 30,
) -> list[dict]:
    """Compute Finance Model 1 scores for a list of symbols."""
    quotes = quotes or {}
    results = []
    for sym in symbols:
        try:
            result = compute_finance_score(
                db, sym,
                quote=quotes.get(sym),
                lookback_days=lookback_days,
            )
            results.append(result)
        except Exception as ex:
            results.append({
                'symbol': sym,
                'finance_score': 50.0,
                'signal_tier': 'HOLD',
                'error': str(ex),
            })
    return sorted(results, key=lambda r: r.get('finance_score', 50), reverse=True)
