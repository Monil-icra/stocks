from __future__ import annotations

from datetime import datetime
from html import unescape
from pathlib import Path
import re
import traceback

from app.core.config import settings


def _log(message: str) -> None:
    path = Path(settings.selenium_log_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    stamp = datetime.utcnow().isoformat(timespec='seconds')
    with path.open('a', encoding='utf-8') as f:
        f.write(f'[{stamp}Z] {message}\n')


def selenium_available() -> tuple[bool, str]:
    try:
        import selenium  # noqa: F401
        return True, 'selenium import ok'
    except Exception as ex:
        return False, f'selenium import failed: {ex}'


def _build_driver():
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options

    options = Options()
    if settings.selenium_headless:
        options.add_argument('--headless=new')
    options.add_argument('--disable-gpu')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--window-size=1365,900')
    options.add_argument('--lang=en-US')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_experimental_option('excludeSwitches', ['enable-automation'])
    options.add_experimental_option('useAutomationExtension', False)
    options.add_argument(
        'user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
        'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36'
    )
    driver = webdriver.Chrome(options=options)
    driver.set_page_load_timeout(settings.selenium_page_load_timeout_seconds)
    return driver


# JavaScript executed inside Chrome to reliably retrieve raw XML.
#
# WHY THIS IS NEEDED:
# Chrome's built-in XML viewer wraps any XML response in a full HTML page:
#   <html xmlns="http://www.w3.org/1999/xhtml">
#     <head><style id="xml-viewer-style">/* ~6000 chars of CSS */</style></head>
#     <body>
#       <div id="webkit-xml-viewer-source-xml"><?xml ...><sitemapindex>...</sitemapindex></div>
#       ... rendered viewer tree (expand/collapse UI) ...
#     </body>
#   </html>
#
# driver.page_source returns this full HTML (7000–10000 chars).
# document.body.innerText returns only visible text — URL strings and dates —
# with ALL XML tags stripped. Neither gives raw XML directly.
#
# The cleanest fix: execute a synchronous XHR from inside the already-authenticated
# Chrome tab. Moneycontrol sees a normal browser request (same headers/cookies),
# so no 403. The response is the raw XML string.
_JS_XHR_FETCH = """
try {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', window.location.href, false);
    xhr.send(null);
    if (xhr.status === 200) return xhr.responseText || '';
    return '';
} catch(e) { return ''; }
"""

# Fallback: extract XML from the viewer div (present in page_source without XHR)
_JS_GET_SOURCE_DIV = """
try {
    var el = document.getElementById('webkit-xml-viewer-source-xml');
    if (el && el.innerHTML) return el.innerHTML;
    var pre = document.querySelector('pre');
    if (pre && pre.textContent) return pre.textContent;
    return '';
} catch(e) { return ''; }
"""


def _extract_xml_from_pagesource(page_source: str) -> str:
    """Last-resort XML extraction from Chrome's HTML page_source.

    Tries three strategies in order:
    1. Regex extract from #webkit-xml-viewer-source-xml div (raw XML, no entity encoding)
    2. unescape() the whole page then find XML markers
    3. Plain text search for XML markers (catches edge cases)
    """
    # Strategy 1: extract directly from the viewer source div
    m = re.search(
        r'id=["\']webkit-xml-viewer-source-xml["\'][^>]*>(.*?)</div',
        page_source,
        re.DOTALL | re.IGNORECASE,
    )
    if m:
        content = m.group(1).strip()
        if '<sitemapindex' in content or '<urlset' in content:
            return content

    # Strategy 2: unescape entity-encoded XML and find markers
    unescaped = unescape(page_source)
    for marker in ['<?xml', '<sitemapindex', '<urlset']:
        idx = unescaped.find(marker)
        if idx >= 0:
            text = unescaped[idx:]
            for end_tag in ['</sitemapindex>', '</urlset>']:
                end_idx = text.rfind(end_tag)
                if end_idx >= 0:
                    return text[: end_idx + len(end_tag)].strip()
            # No closing tag found — return truncated (parser will handle it)
            return text[:20000].strip()

    return ''


def selenium_fetch_page_source(url: str, wait_text: str | None = None) -> str:
    """Fetch a public page using a real Chrome browser and return raw XML.

    For XML sitemaps Chrome renders a styled viewer page rather than returning
    raw XML through driver.page_source or document.body.innerText.

    Extraction strategy (in order of reliability):
    1. XHR re-fetch: execute a synchronous XMLHttpRequest from inside the
       already-loaded Chrome tab. The browser sends the request with the same
       headers as a normal page load, so Moneycontrol does not block it.
       Returns raw XML with no HTML wrapping.
    2. JS div extraction: read innerHTML of #webkit-xml-viewer-source-xml
       which Chrome injects before its viewer script runs.
    3. Regex + unescape on page_source: last resort for edge cases.

    Does NOT use cookies, credentials, CAPTCHA solving, or proxy bypass.
    """
    ok, msg = selenium_available()
    _log(f'CHECK selenium_available={ok} message={msg}')
    if not ok:
        raise RuntimeError(msg)

    driver = None
    try:
        _log(f'START driver url={url} headless={settings.selenium_headless}')
        driver = _build_driver()
        driver.get(url)

        current_url = driver.current_url
        title = driver.title
        page_source = driver.page_source or ''

        xml_content = ''

        # --- Strategy 1: XHR re-fetch (most reliable) ---
        try:
            xhr_result = driver.execute_script(_JS_XHR_FETCH) or ''
            if xhr_result and ('<sitemapindex' in xhr_result or '<urlset' in xhr_result):
                xml_content = xhr_result
                _log(f'XHR_SUCCESS len={len(xml_content)} has_sitemapindex={"<sitemapindex" in xml_content} has_urlset={"<urlset" in xml_content}')
            else:
                _log(f'XHR_MISS len={len(xhr_result)} preview={xhr_result[:200]!r}')
        except Exception as xhr_ex:
            _log(f'XHR_ERROR {xhr_ex}')

        # --- Strategy 2: JS div extraction ---
        if not xml_content:
            try:
                div_result = driver.execute_script(_JS_GET_SOURCE_DIV) or ''
                if div_result and ('<sitemapindex' in div_result or '<urlset' in div_result):
                    xml_content = div_result
                    _log(f'DIV_SUCCESS len={len(xml_content)}')
                else:
                    _log(f'DIV_MISS len={len(div_result)} preview={div_result[:200]!r}')
            except Exception as div_ex:
                _log(f'DIV_ERROR {div_ex}')

        # --- Strategy 3: Regex on page_source ---
        if not xml_content:
            xml_content = _extract_xml_from_pagesource(page_source)
            if xml_content:
                _log(f'REGEX_SUCCESS len={len(xml_content)}')
            else:
                _log(f'REGEX_MISS page_source_preview={page_source[:300]!r}')

        _log(
            f'DONE url={url} current_url={current_url} title={title!r} '
            f'page_source_len={len(page_source)} '
            f'xml_content_len={len(xml_content)} '
            f'contains_sitemapindex={"<sitemapindex" in xml_content} '
            f'contains_urlset={"<urlset" in xml_content}'
        )

        if wait_text and wait_text not in xml_content:
            _log(f'WARN wait_text={wait_text!r} not found in xml_content. preview={xml_content[:400]!r}')

        return xml_content

    except Exception as ex:
        _log(f'ERROR url={url} error={ex}\n{traceback.format_exc()}')
        raise
    finally:
        if driver is not None:
            try:
                driver.quit()
                _log('CLOSED driver')
            except Exception as ex:
                _log(f'WARN driver quit failed: {ex}')


def selenium_warmup() -> dict:
    """Lightweight startup check. Failure is logged but does not stop FastAPI."""
    ok, msg = selenium_available()
    if not ok:
        _log(f'WARMUP skipped: {msg}')
        return {'ok': False, 'message': msg}
    try:
        text = selenium_fetch_page_source('about:blank')
        return {'ok': True, 'message': 'selenium warmup ok', 'length': len(text)}
    except Exception as ex:
        return {'ok': False, 'message': str(ex)}
