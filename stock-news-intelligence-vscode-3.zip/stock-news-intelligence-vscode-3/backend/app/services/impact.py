def calculate(sentiment_score: float, company_importance: float = 50, sector_relevance: float = 50, source_credibility: float = 70, freshness: float = 90):
    weights = {'sentiment': 0.25, 'company': 0.25, 'sector': 0.15, 'source': 0.20, 'freshness': 0.15}
    score = abs(sentiment_score)*weights['sentiment'] + company_importance*weights['company'] + sector_relevance*weights['sector'] + source_credibility*weights['source'] + freshness*weights['freshness']
    explanation = {'weights': weights, 'inputs': {'sentiment_abs': abs(sentiment_score), 'company_importance': company_importance, 'sector_relevance': sector_relevance, 'source_credibility': source_credibility, 'freshness': freshness}}
    return round(max(0, min(100, score)), 2), explanation
