"""
scheduler.py — APScheduler background jobs.

Jobs registered:
  1. rss_ingestion_due     — run ingest_all(due_only=True) every ingestion_interval_seconds
  2. quote_refresh         — refresh Nifty 250 quotes every quote_refresh_interval_seconds
  3. signal_refresh        — regenerate trade signals every signal_refresh_interval_seconds
  4. signal_retrain        — retrain signal model on feedback data every signal_retrain_interval_seconds
"""
import traceback

from apscheduler.schedulers.background import BackgroundScheduler

from app.core.config import settings
from app.db.session import SessionLocal
from app.services.ingest import ingest_all
from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

scheduler = BackgroundScheduler(timezone='Asia/Kolkata')


# ── Job 1: RSS/Selenium ingestion ─────────────────────────────────────────────

def scheduled_ingestion_job():
    db = SessionLocal()
    owner = 'apscheduler'
    acquired = False
    try:
        acquired = acquire_ingestion_lock(db, owner)
        if not acquired:
            return {'skipped': True, 'reason': 'ingestion_already_running'}
        return ingest_all(db, mode='apscheduler', due_only=True)
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
        raise
    finally:
        if acquired:
            try:
                release_ingestion_lock(db, owner)
            except Exception:
                try:
                    db.rollback()
                except Exception:
                    pass
        db.close()


# ── Job 2: Quote refresh ───────────────────────────────────────────────────────

def quote_refresh_job():
    """Refresh real-time quotes for all Nifty 250 stocks via yfinance.

    Runs in a background thread so it never blocks the API server.
    Failures are logged but never crash the scheduler.
    """
    try:
        from app.services.quote_service import get_all_nifty250_quotes
        get_all_nifty250_quotes(force_refresh=True)
    except Exception as ex:
        import logging
        logging.getLogger('scheduler').warning(f'quote_refresh_job failed: {ex}')


# ── Job 3: Signal refresh ──────────────────────────────────────────────────────

def signal_refresh_job():
    """Re-run Finance Model 1 + Signal Model 2 for all tracked stocks.

    Persists new signals to the trade_signals table.
    Failures are logged but never crash the scheduler.
    """
    try:
        from app.services.nifty250 import NIFTY_250
        from app.services.quote_service import get_quotes_batch
        from app.services.finance_model import batch_compute_finance_scores
        from app.services.signal_model import generate_signals_batch
        from app.api.stock_routes import _save_signal

        syms = [s['symbol'] for s in NIFTY_250[:settings.signal_batch_size]]
        quotes = get_quotes_batch(syms)

        db = SessionLocal()
        try:
            finance_results = batch_compute_finance_scores(
                db, syms, quotes=quotes,
                lookback_days=settings.sentiment_lookback_days,
            )
            signals = generate_signals_batch(finance_results)
            for sig in signals:
                _save_signal(db, sig)
        finally:
            db.close()

    except Exception as ex:
        import logging
        logging.getLogger('scheduler').warning(f'signal_refresh_job failed: {ex}\n{traceback.format_exc()}')


# ── Job 4: Signal model retrain ────────────────────────────────────────────────

def signal_retrain_job():
    """Retrain Signal Model 2 using historical feedback rows from trade_signals.

    Only meaningful once actual_signal feedback has been filled in (after
    horizon_days elapse).  Falls back to synthetic data when real rows < 50.
    """
    try:
        from app.services.signal_model import retrain_from_db
        db = SessionLocal()
        try:
            result = retrain_from_db(db)
            import logging
            logging.getLogger('scheduler').info(f'signal_retrain_job: {result}')
        finally:
            db.close()
    except Exception as ex:
        import logging
        logging.getLogger('scheduler').warning(f'signal_retrain_job failed: {ex}')


# ── Scheduler lifecycle ────────────────────────────────────────────────────────

def start_scheduler():
    if not settings.app_scheduler_enabled:
        return
    if scheduler.running:
        return

    # Job 1: ingestion
    scheduler.add_job(
        scheduled_ingestion_job,
        'interval',
        seconds=settings.ingestion_interval_seconds,
        id='rss_ingestion_due',
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    # Job 2: quote refresh
    scheduler.add_job(
        quote_refresh_job,
        'interval',
        seconds=settings.quote_refresh_interval_seconds,
        id='quote_refresh',
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    # Job 3: signal refresh
    scheduler.add_job(
        signal_refresh_job,
        'interval',
        seconds=settings.signal_refresh_interval_seconds,
        id='signal_refresh',
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    # Job 4: daily model retrain
    scheduler.add_job(
        signal_retrain_job,
        'interval',
        seconds=settings.signal_retrain_interval_seconds,
        id='signal_retrain',
        replace_existing=True,
        max_instances=1,
        coalesce=True,
    )

    scheduler.start()


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown(wait=False)
