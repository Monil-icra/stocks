"""
quote_service.py — Real-time stock data via yfinance.
verify=False applied to all external HTTP calls per IT policy.
"""
from __future__ import annotations

import ssl
import traceback
from datetime import datetime, timezone
from typing import Any

from app.core.config import settings
from app.services.cache import cache_get_json, cache_set_json
from app.services.nifty250 import NIFTY_250, yf_symbol


def _utcnow_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _yf_available() -> bool:
    try:
        import yfinance  # noqa: F401
        return True
    except ImportError:
        return False


def _no_verify_session():
    """Return a requests.Session with TLS verification disabled.
    yfinance uses requests under the hood; patching the session
    applies verify=False to all Yahoo Finance calls."""
    try:
        import requests
        session = requests.Session()
        session.verify = False
        # Suppress InsecureRequestWarning
        import urllib3
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        return session
    except Exception:
        return None


def _safe(value) -> float | None:
    if value is None:
        return None
    try:
        f = float(value)
        return None if (f != f) else round(f, 4)
    except (TypeError, ValueError):
        return None


def _fetch_ticker_info(yf_sym: str) -> dict:
    try:
        import yfinance as yf
        session = _no_verify_session()
        ticker = yf.Ticker(yf_sym, session=session) if session else yf.Ticker(yf_sym)
        info = ticker.info or {}
        fast = ticker.fast_info
        return {
            'price':             _safe(getattr(fast, 'last_price', None)),
            'prev_close':        _safe(getattr(fast, 'previous_close', None)),
            'open':              _safe(getattr(fast, 'open', None)),
            'day_high':          _safe(getattr(fast, 'day_high', None)),
            'day_low':           _safe(getattr(fast, 'day_low', None)),
            'week52_high':       _safe(getattr(fast, 'year_high', None)),
            'week52_low':        _safe(getattr(fast, 'year_low', None)),
            'volume':            _safe(getattr(fast, 'three_month_average_volume', None)),
            'market_cap':        _safe(getattr(fast, 'market_cap', None)),
            'pe_ratio':          _safe(info.get('trailingPE')),
            'eps':               _safe(info.get('trailingEps')),
            'book_value':        _safe(info.get('bookValue')),
            'dividend_yield':    _safe(info.get('dividendYield')),
            'roe':               _safe(info.get('returnOnEquity')),
            'debt_to_equity':    _safe(info.get('debtToEquity')),
            'revenue_growth':    _safe(info.get('revenueGrowth')),
            'earnings_growth':   _safe(info.get('earningsGrowth')),
            'profit_margins':    _safe(info.get('profitMargins')),
            'gross_margins':     _safe(info.get('grossMargins')),
            'operating_margins': _safe(info.get('operatingMargins')),
            'shares_outstanding':_safe(info.get('sharesOutstanding')),
            'beta':              _safe(info.get('beta')),
            'currency':          info.get('currency', 'INR'),
            'exchange':          info.get('exchange', 'NSE'),
            'fetched_at':        _utcnow_iso(),
            'yf_symbol':         yf_sym,
        }
    except Exception as ex:
        return {'error': str(ex), 'yf_symbol': yf_sym, 'fetched_at': _utcnow_iso()}


def _fetch_history(yf_sym: str, period: str = '3mo') -> list[dict]:
    try:
        import yfinance as yf
        session = _no_verify_session()
        ticker = yf.Ticker(yf_sym, session=session) if session else yf.Ticker(yf_sym)
        hist = ticker.history(period=period, auto_adjust=True)
        if hist.empty:
            return []
        rows = []
        for ts, row in hist.iterrows():
            rows.append({
                'date':   ts.strftime('%Y-%m-%d'),
                'open':   _safe(row.get('Open')),
                'high':   _safe(row.get('High')),
                'low':    _safe(row.get('Low')),
                'close':  _safe(row.get('Close')),
                'volume': _safe(row.get('Volume')),
            })
        return rows
    except Exception:
        return []


def _fetch_holders(yf_sym: str) -> dict:
    try:
        import yfinance as yf
        session = _no_verify_session()
        t = yf.Ticker(yf_sym, session=session) if session else yf.Ticker(yf_sym)
        out: dict[str, Any] = {}
        inst = t.institutional_holders
        if inst is not None and not inst.empty:
            out['institutional'] = inst.head(10).to_dict(orient='records')
        mf = t.mutualfund_holders
        if mf is not None and not mf.empty:
            out['mutual_fund'] = mf.head(10).to_dict(orient='records')
        info = t.info or {}
        out['promoter_pct']    = _safe(info.get('heldPercentInsiders'))
        out['institution_pct'] = _safe(info.get('heldPercentInstitutions'))
        return out
    except Exception:
        return {}


def _fetch_earnings(yf_sym: str) -> list[dict]:
    try:
        import yfinance as yf
        session = _no_verify_session()
        t = yf.Ticker(yf_sym, session=session) if session else yf.Ticker(yf_sym)
        q = t.quarterly_earnings
        if q is None or q.empty:
            return []
        rows = []
        for ts, row in q.iterrows():
            rows.append({'quarter': str(ts), 'revenue': _safe(row.get('Revenue')), 'earnings': _safe(row.get('Earnings'))})
        return rows[-8:]
    except Exception:
        return []


def get_quote(nse_symbol: str, force_refresh: bool = False) -> dict:
    sym = nse_symbol.upper().replace('.NS', '')
    yfk = yf_symbol(sym)
    cache_key = f'quote:{sym}'
    if not force_refresh:
        cached = cache_get_json(cache_key, None)
        if cached:
            return cached
    if not _yf_available():
        return {'symbol': sym, 'yf_symbol': yfk, 'error': 'yfinance not installed', 'price': None, 'fetched_at': _utcnow_iso()}
    data = _fetch_ticker_info(yfk)
    result = {'symbol': sym, **data}
    if result.get('price'):
        cache_set_json(cache_key, result, settings.quote_cache_ttl_seconds)
    return result


def get_quotes_batch(symbols: list[str], force_refresh: bool = False) -> dict[str, dict]:
    if not symbols:
        return {}
    symbols = [s.upper().replace('.NS', '') for s in symbols]
    if not _yf_available():
        return {sym: {'symbol': sym, 'price': None, 'error': 'yfinance not installed', 'fetched_at': _utcnow_iso()} for sym in symbols}
    result: dict[str, dict] = {}
    missing: list[str] = []
    for sym in symbols:
        if not force_refresh:
            cached = cache_get_json(f'quote:{sym}', None)
            if cached:
                result[sym] = cached
                continue
        missing.append(sym)
    if not missing:
        return result
    try:
        import yfinance as yf
        import pandas as pd
        session = _no_verify_session()
        yf_syms = [yf_symbol(s) for s in missing]
        raw = yf.download(
            tickers=yf_syms, period='2d', interval='1d',
            auto_adjust=True, progress=False, group_by='ticker',
            session=session,
        )
        for sym in missing:
            yfk = yf_symbol(sym)
            try:
                if len(missing) == 1:
                    last = raw.iloc[-1] if not raw.empty else pd.Series()
                    prev = raw.iloc[-2] if len(raw) > 1 else pd.Series()
                else:
                    cols = raw[yfk] if yfk in raw.columns.get_level_values(0) else pd.DataFrame()
                    last = cols.iloc[-1] if not cols.empty else pd.Series()
                    prev = cols.iloc[-2] if len(cols) > 1 else pd.Series()
                price = _safe(last.get('Close'))
                prev_close = _safe(prev.get('Close'))
                q = {
                    'symbol': sym, 'yf_symbol': yfk,
                    'price': price, 'prev_close': prev_close,
                    'open': _safe(last.get('Open')),
                    'day_high': _safe(last.get('High')),
                    'day_low': _safe(last.get('Low')),
                    'volume': _safe(last.get('Volume')),
                    'change': round(price - prev_close, 2) if price and prev_close else None,
                    'change_pct': round((price - prev_close) / prev_close * 100, 2) if price and prev_close else None,
                    'fetched_at': _utcnow_iso(),
                }
                result[sym] = q
                if price:
                    cache_set_json(f'quote:{sym}', q, settings.quote_cache_ttl_seconds)
            except Exception as ex:
                result[sym] = {'symbol': sym, 'price': None, 'error': f'parse: {ex}', 'fetched_at': _utcnow_iso()}
    except Exception:
        for sym in missing:
            result[sym] = get_quote(sym, force_refresh=True)
    return result


def get_history(nse_symbol: str, period: str = '3mo') -> list[dict]:
    sym = nse_symbol.upper().replace('.NS', '')
    cache_key = f'history:{sym}:{period}'
    cached = cache_get_json(cache_key, None)
    if cached:
        return cached
    data = _fetch_history(yf_symbol(sym), period)
    if data:
        cache_set_json(cache_key, data, 21600)
    return data


def get_holders(nse_symbol: str) -> dict:
    sym = nse_symbol.upper().replace('.NS', '')
    cache_key = f'holders:{sym}'
    cached = cache_get_json(cache_key, None)
    if cached:
        return cached
    data = _fetch_holders(yf_symbol(sym))
    if data:
        cache_set_json(cache_key, data, 21600)
    return data


def get_earnings_history(nse_symbol: str) -> list[dict]:
    sym = nse_symbol.upper().replace('.NS', '')
    cache_key = f'earnings:{sym}'
    cached = cache_get_json(cache_key, None)
    if cached:
        return cached
    data = _fetch_earnings(yf_symbol(sym))
    if data:
        cache_set_json(cache_key, data, 21600)
    return data


def get_all_nifty250_quotes(force_refresh: bool = False) -> dict[str, dict]:
    all_syms = [s['symbol'] for s in NIFTY_250]
    result: dict[str, dict] = {}
    for i in range(0, len(all_syms), 50):
        result.update(get_quotes_batch(all_syms[i:i + 50], force_refresh=force_refresh))
    return result
