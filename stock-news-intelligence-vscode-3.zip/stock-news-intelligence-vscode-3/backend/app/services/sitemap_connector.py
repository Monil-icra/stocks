from __future__ import annotations

from datetime import datetime, timezone, timedelta
from html import unescape
import xml.etree.ElementTree as ET

import httpx

from app.core.config import settings
from app.services.html_connector import BROWSER_HEADERS, extract_article, fetch_html, polite_sleep
from app.services.selenium_connector import selenium_fetch_page_source


def _local_name(tag: str) -> str:
    return tag.split('}', 1)[-1] if '}' in tag else tag


def _parse_sitemap_date(value: str | None):
    if not value:
        return None
    try:
        return (
            datetime.fromisoformat(value.replace('Z', '+00:00'))
            .astimezone(timezone.utc)
            .replace(tzinfo=None)
        )
    except Exception:
        return None


def _to_xml_text(raw: str) -> str:
    """Normalise whatever string we have into a parseable XML string.

    selenium_fetch_page_source now returns raw XML directly (via XHR or JS
    div extraction), so this function primarily handles:
      A) Raw XML from httpx — already clean, just strip whitespace
      B) Raw XML from Selenium XHR — may have a leading browser message
         'This XML file does not appear to have any style information...'
         before the <?xml declaration
      C) Edge-case: HTML-entity-encoded XML (old page_source fallback) —
         unescape() converts &lt; → < so it becomes case A/B
    """
    text = unescape(raw or '').strip()

    # Find the earliest valid XML root opener
    markers = ['<?xml', '<sitemapindex', '<urlset']
    start = -1
    for m in markers:
        idx = text.find(m)
        if idx >= 0 and (start < 0 or idx < start):
            start = idx

    if start < 0:
        return ''

    text = text[start:]

    # Trim after the closing root tag
    for end_tag in ['</sitemapindex>', '</urlset>']:
        idx = text.rfind(end_tag)
        if idx >= 0:
            text = text[: idx + len(end_tag)]
            break

    return text.strip()


def fetch_sitemap_xml(url: str, force_selenium: bool = False) -> str:
    """Fetch a sitemap URL and return the raw XML string.

    When force_selenium=True (all Moneycontrol selenium_sitemap* sources),
    Selenium is mandatory — httpx is never attempted.
    selenium_fetch_page_source now returns the raw XML (not HTML) via the
    XHR-inside-Chrome strategy, so _to_xml_text only does light cleanup.
    """
    if force_selenium:
        raw = selenium_fetch_page_source(url, wait_text='sitemap')
        return _to_xml_text(raw)

    headers = {**BROWSER_HEADERS, 'Accept': 'application/xml,text/xml,*/*;q=0.8'}
    try:
        with httpx.Client(
            timeout=settings.html_article_timeout_seconds,
            headers=headers,
            follow_redirects=True,
            verify=False,
        ) as client:
            response = client.get(url)
            response.raise_for_status()
            return _to_xml_text(response.text)
    except httpx.HTTPStatusError as ex:
        status = ex.response.status_code if ex.response is not None else None
        if status == 403 and settings.enable_selenium_fallback:
            raw = selenium_fetch_page_source(url, wait_text='sitemap')
            return _to_xml_text(raw)
        raise


def parse_sitemap_index(xml_text: str, max_sitemaps: int = 8, backfill_days: int = 6) -> list:
    """Parse a <sitemapindex> and return child sitemap entries within backfill window."""
    text = _to_xml_text(xml_text)
    if not text:
        return []
    try:
        root = ET.fromstring(text.encode('utf-8'))
    except ET.ParseError as e:
        return []

    cutoff = datetime.utcnow() - timedelta(days=backfill_days)
    items = []
    for node in root.iter():
        if _local_name(node.tag) != 'sitemap':
            continue
        loc = None
        lastmod = None
        for child in list(node):
            name = _local_name(child.tag)
            if name == 'loc':
                loc = (child.text or '').strip()
            elif name == 'lastmod':
                lastmod = _parse_sitemap_date((child.text or '').strip())
        if loc and (lastmod is None or lastmod >= cutoff):
            items.append({'url': loc, 'lastmod': lastmod})
        if len(items) >= max_sitemaps:
            break
    return items


def parse_sitemap_urls(xml_text: str, max_links: int = 80) -> list:
    """Parse a <urlset> sitemap and return article entries with news/image metadata."""
    text = _to_xml_text(xml_text)
    if not text:
        return []
    try:
        root = ET.fromstring(text.encode('utf-8'))
    except ET.ParseError:
        return []

    urls = []
    for node in root.iter():
        if _local_name(node.tag) != 'url':
            continue
        item = {
            'url': None,
            'lastmod': None,
            'publication_date': None,
            'title': None,
            'keywords': None,
            'image_url': None,
        }
        for child in list(node):
            name = _local_name(child.tag)
            if name == 'loc':
                item['url'] = (child.text or '').strip()
            elif name == 'lastmod':
                item['lastmod'] = _parse_sitemap_date((child.text or '').strip())
            elif name == 'news':
                for nc in child.iter():
                    nn = _local_name(nc.tag)
                    tv = (nc.text or '').strip()
                    if nn == 'publication_date':
                        item['publication_date'] = _parse_sitemap_date(tv)
                    elif nn == 'title':
                        item['title'] = tv
                    elif nn == 'keywords':
                        item['keywords'] = tv
            elif name == 'image':
                for ic in child.iter():
                    if _local_name(ic.tag) == 'loc' and ic.text:
                        item['image_url'] = ic.text.strip()
        if item['url']:
            urls.append(item)
        if len(urls) >= max_links:
            break
    return urls


def _entry_from_link(link: dict) -> dict:
    url = link['url']
    title = (
        link.get('title')
        or url.rsplit('/', 1)[-1]
        .replace('-', ' ')
        .replace('.html', '')
        .strip()
        .title()
    )
    keywords = link.get('keywords') or ''
    published_at = link.get('publication_date') or link.get('lastmod')
    content = f'{title}. {keywords}'.strip()
    return {
        'url': url,
        'title': title,
        'summary': keywords,
        'content': content,
        'published_at': published_at,
        'image_url': link.get('image_url'),
    }


# Non-financial Moneycontrol paths to exclude
_MC_BLOCKED_PATHS = [
    '/news/india/',
    '/news/world/',
    '/news/technology/',
    '/news/lifestyle/',
    '/news/sports/',
    '/news/sport/',
    '/news/entertainment/',
    '/news/education/',
    '/news/health/',
    '/news/auto/',
    '/news/science/',
    '/news/art/',
    '/news/travel/',
]


def _is_financial_url(url: str) -> bool:
    """Return True if the URL is a financial/market article.

    Uses a blocklist: exclude known non-financial paths, accept everything
    else. More robust than allowlist because Moneycontrol adds sub-paths
    (/news/business/ipo, /news/business/earnings, etc.) regularly.
    """
    return not any(blocked in url for blocked in _MC_BLOCKED_PATHS)


def sitemap_entries_for_source(db, src) -> tuple[list, int]:
    """Fetch and parse all article entries for a sitemap-type source."""
    force_selenium = (src.source_type or '') in {'selenium_sitemap', 'selenium_sitemap_index'}
    article_limit = src.article_limit or settings.html_connector_max_links

    xml_text = fetch_sitemap_xml(src.url, force_selenium=force_selenium)
    all_links: list[dict] = []

    if '<sitemapindex' in xml_text:
        child_sitemaps = parse_sitemap_index(
            xml_text,
            max_sitemaps=settings.moneycontrol_selenium_child_sitemap_limit,
            backfill_days=settings.startup_bootstrap_backfill_days,
        )
        for child in child_sitemaps:
            child_xml = fetch_sitemap_xml(child['url'], force_selenium=force_selenium)
            all_links.extend(parse_sitemap_urls(child_xml, max_links=article_limit))
            if len(all_links) >= article_limit:
                break
    else:
        all_links = parse_sitemap_urls(xml_text, max_links=article_limit)

    # Financial URL filter with fallback (if filter drops all → keep all)
    financial = [link for link in all_links if _is_financial_url(link['url'])]
    links = financial if financial else all_links

    entries: list[dict] = []
    for link in links[:article_limit]:
        article = _entry_from_link(link)
        if settings.moneycontrol_selenium_article_enrichment:
            try:
                polite_sleep(src.polite_delay_ms or 200)
                parsed = extract_article(
                    fetch_html(article['url']),
                    article['url'],
                    fallback_title=article['title'],
                )
                article['title'] = parsed.get('title') or article['title']
                article['summary'] = parsed.get('summary') or article['summary']
                article['content'] = parsed.get('content') or article['content']
                article['published_at'] = parsed.get('published_at') or article['published_at']
            except Exception:
                pass
        if article.get('title') and article.get('url'):
            entries.append(article)

    return entries, len(links)
