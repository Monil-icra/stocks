import re

def normalize_story(title: str | None) -> str:
    t = (title or '').lower()
    t = re.sub(r'[^a-z0-9 ]+', ' ', t)
    t = re.sub(r'(live|latest|update|updates|news|market|stock|stocks|share|shares)', ' ', t)
    t = re.sub(r'\s+', ' ', t).strip()
    return t[:160]

def unique_articles(articles):
    seen = set()
    out = []
    for article in articles:
        key = normalize_story(getattr(article, 'title', ''))
        if not key or key not in seen:
            out.append(article)
            if key:
                seen.add(key)
    return out
