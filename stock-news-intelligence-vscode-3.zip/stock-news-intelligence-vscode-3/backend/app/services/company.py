import re
from rapidfuzz import fuzz

COMPANIES = [
    {'name':'Reliance Industries','aliases':['Reliance','RIL'],'nse':'RELIANCE','bse':'500325','sector':'Energy','importance':95},
    {'name':'Tata Consultancy Services','aliases':['TCS'],'nse':'TCS','bse':'532540','sector':'IT','importance':95},
    {'name':'Infosys','aliases':['Infy','Infosys Technologies'],'nse':'INFY','bse':'500209','sector':'IT','importance':90},
    {'name':'HDFC Bank','aliases':['HDFCBANK'],'nse':'HDFCBANK','bse':'500180','sector':'Banking','importance':95},
    {'name':'ICICI Bank','aliases':['ICICI','ICICIBANK'],'nse':'ICICIBANK','bse':'532174','sector':'Banking','importance':92},
    {'name':'State Bank of India','aliases':['SBI'],'nse':'SBIN','bse':'500112','sector':'Banking','importance':90},
    {'name':'Larsen and Toubro','aliases':['L&T','Larsen','LT'],'nse':'LT','bse':'500510','sector':'Infrastructure','importance':86},
    {'name':'Bharti Airtel','aliases':['Airtel'],'nse':'BHARTIARTL','bse':'532454','sector':'Telecom','importance':88},
]

def detect_companies(text: str):
    low = text.lower()
    out = []
    for c in COMPANIES:
        names = [c['name']] + c['aliases']
        exact = any(re.search(r'(?<![A-Za-z0-9])' + re.escape(n.lower()) + r'(?![A-Za-z0-9])', low) for n in names)
        fuzzy = max(fuzz.partial_ratio(n.lower(), low) for n in names)
        if exact or fuzzy >= 88:
            out.append({**c, 'confidence': 100 if exact else float(fuzzy)})
    return out
