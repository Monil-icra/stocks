from celery import Celery
from celery.schedules import schedule
from app.core.config import settings
from app.db.session import SessionLocal
from app.services.ingest import ingest_all
from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

celery_app = Celery('newsintel', broker=settings.celery_broker_url, backend=settings.celery_result_backend)
celery_app.conf.timezone = 'Asia/Kolkata'
celery_app.conf.beat_schedule = {
    'rss-ingestion-every-2-minutes': {
        'task': 'app.worker.scheduled_ingestion',
        'schedule': schedule(run_every=settings.ingestion_interval_seconds),
    }
}

@celery_app.task(name='app.worker.scheduled_ingestion')
def scheduled_ingestion():
    db = SessionLocal()
    owner = 'celery-beat-worker'
    try:
        if not acquire_ingestion_lock(db, owner):
            return {'skipped': True, 'reason': 'ingestion_already_running'}
        try:
            return ingest_all(db, mode='celery', due_only=True)
        finally:
            release_ingestion_lock(db, owner)
    finally:
        db.close()
