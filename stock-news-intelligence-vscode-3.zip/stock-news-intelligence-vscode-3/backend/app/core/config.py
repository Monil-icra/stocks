from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = 'Indian Stock Market News Intelligence'
    environment: str = 'local'

    database_url: str = 'sqlite:///C:/monil/stock-news-intelligence-data/newsintel.db'

    redis_url: str = 'redis://localhost:6379/0'
    celery_broker_url: str = 'redis://localhost:6379/1'
    celery_result_backend: str = 'redis://localhost:6379/2'
    use_redis_cache: bool = True
    redis_cache_ttl_seconds: int = 86400
    api_cache_ttl_seconds: int = 30
    news_cache_ttl_seconds: int = 60

    jwt_secret: str = 'change-this-secret'
    cors_origins: str = 'http://127.0.0.1:5173,http://localhost:5173'

    enable_spacy: bool = True
    enable_transformers: bool = True

    fetch_timeout_seconds: int = 20
    # TLS verification disabled globally – IT team policy
    ssl_verify: bool = False
    rss_entries_per_source: int = 500
    live_search_on_empty: bool = True
    user_agent: str = 'IndianNewsIntelBot/1.0'
    html_article_timeout_seconds: int = 20
    html_connector_max_links: int = 80
    debug_html_sample_articles: int = 3

    app_scheduler_enabled: bool = True
    ingestion_interval_seconds: int = 60
    ingestion_lock_ttl_seconds: int = 300
    ingestion_worker_count: int = 6
    sse_refresh_seconds: int = 15

    enable_selenium_fallback: bool = True
    selenium_headless: bool = True
    selenium_start_on_app_start: bool = True
    selenium_page_load_timeout_seconds: int = 30
    selenium_wait_seconds: int = 12
    selenium_log_path: str = './logs/selenium_moneycontrol.log'

    startup_bootstrap_ingest: bool = True
    startup_bootstrap_backfill_days: int = 6
    startup_bootstrap_min_articles: int = 500

    moneycontrol_selenium_child_sitemap_limit: int = 8
    moneycontrol_selenium_article_enrichment: bool = False

    # yfinance / quotes
    quote_cache_ttl_seconds: int = 90
    quote_refresh_interval_seconds: int = 300
    signal_refresh_interval_seconds: int = 1800
    signal_retrain_interval_seconds: int = 86400
    signal_batch_size: int = 50
    sentiment_lookback_days: int = 30

    stable_data_dir: str = 'C:/monil/stock-news-intelligence-data'

    model_config = SettingsConfigDict(env_file='.env', extra='ignore')


settings = Settings()
