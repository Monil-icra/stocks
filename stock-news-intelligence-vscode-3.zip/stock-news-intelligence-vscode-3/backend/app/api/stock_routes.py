"""
stock_routes.py — API routes for the stock intelligence layer.

Mount this router in main.py:
    from app.api.stock_routes import router as stock_router
    app.include_router(stock_router)
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

from fastapi import APIRouter, BackgroundTasks, Depends, Query
from fastapi.encoders import jsonable_encoder
from sqlalchemy import desc, func
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.models_extended import (
    CorporateEvent,
    EarningsResult,
    HoldingPattern,
    StockQuote,
    StockUniverse,
    TradeSignal,
)
from app.db.session import SessionLocal, get_db
from app.services.cache import cache_get_json, cache_set_json, cached_or_compute
from app.services.finance_model import batch_compute_finance_scores, compute_finance_score
from app.services.nifty250 import NIFTY_250, get_by_symbol
from app.services.quote_service import (
    get_all_nifty250_quotes,
    get_earnings_history,
    get_history,
    get_holders,
    get_quote,
    get_quotes_batch,
)
from app.services.signal_model import (
    generate_signal,
    generate_signals_batch,
    model_info,
    retrain_from_db,
)

router = APIRouter(prefix='/api/stocks')


# ─── Universe ─────────────────────────────────────────────────────────────────

@router.get('/universe')
def get_universe(
    sector:  Optional[str] = None,
    index:   Optional[str] = None,
    enabled: bool = True,
    db: Session = Depends(get_db),
):
    """Return all stocks in the tracked universe."""
    def compute():
        q = db.query(StockUniverse)
        if enabled:
            q = q.filter(StockUniverse.enabled == True)
        if sector:
            q = q.filter(StockUniverse.sector == sector)
        rows = q.order_by(desc(StockUniverse.importance)).all()
        if index:
            rows = [r for r in rows if index in (r.indices or [])]
        return jsonable_encoder(rows)

    key = f'api:universe:sector={sector}:index={index}:enabled={enabled}'
    return cached_or_compute(key, compute, 300, allow_empty=True)


@router.get('/universe/sectors')
def get_sectors(db: Session = Depends(get_db)):
    rows = (
        db.query(StockUniverse.sector, func.count())
        .filter(StockUniverse.enabled == True)
        .group_by(StockUniverse.sector)
        .order_by(desc(func.count()))
        .all()
    )
    return [{'sector': r[0], 'count': r[1]} for r in rows if r[0]]


# ─── Quotes ───────────────────────────────────────────────────────────────────

@router.get('/quote/{symbol}')
def quote_single(symbol: str, force: bool = False):
    """Real-time quote for a single NSE symbol via yfinance."""
    return get_quote(symbol.upper(), force_refresh=force)


@router.get('/quotes')
def quotes_batch(
    symbols: str = Query(..., description='Comma-separated NSE symbols'),
    force:   bool = False,
):
    """Batch quotes for multiple symbols."""
    syms = [s.strip().upper() for s in symbols.split(',') if s.strip()][:50]
    return get_quotes_batch(syms, force_refresh=force)


@router.get('/quotes/nifty250')
def quotes_nifty250(force: bool = False):
    """Quotes for all 250 stocks. Cached 90 s. May take 20–30 s on first call."""
    cache_key = 'api:quotes:nifty250'
    cached = cache_get_json(cache_key, None)
    if cached and not force:
        return cached
    data = get_all_nifty250_quotes(force_refresh=force)
    if data:
        cache_set_json(cache_key, data, getattr(settings, 'quote_cache_ttl_seconds', 90))
    return data


@router.get('/history/{symbol}')
def price_history(
    symbol: str,
    period: str = Query('3mo', regex='^(1d|5d|1mo|3mo|6mo|1y|2y|5y)$'),
):
    """OHLCV history for a symbol. Used for chart rendering."""
    return get_history(symbol.upper(), period=period)


# ─── Earnings ─────────────────────────────────────────────────────────────────

@router.get('/earnings/{symbol}')
def earnings(symbol: str, db: Session = Depends(get_db)):
    """Earnings results for a symbol (DB + yfinance fallback)."""
    sym = symbol.upper()
    rows = (
        db.query(EarningsResult)
        .filter(EarningsResult.symbol == sym)
        .order_by(desc(EarningsResult.period_end))
        .limit(12)
        .all()
    )
    db_data = jsonable_encoder(rows)

    # Supplement with yfinance quarterly earnings
    yf_data = get_earnings_history(sym)

    return {'symbol': sym, 'db_records': db_data, 'yfinance_quarterly': yf_data}


@router.post('/earnings/{symbol}')
def add_earnings(symbol: str, body: dict, db: Session = Depends(get_db)):
    """Manually add an earnings result row (for news-scraped results)."""
    sym = symbol.upper()
    row = EarningsResult(
        symbol=sym,
        period_end=datetime.fromisoformat(body['period_end']) if body.get('period_end') else None,
        quarter_label=body.get('quarter_label'),
        revenue_cr=body.get('revenue_cr'),
        revenue_yoy_pct=body.get('revenue_yoy_pct'),
        net_profit_cr=body.get('net_profit_cr'),
        net_profit_yoy_pct=body.get('net_profit_yoy_pct'),
        net_margin_pct=body.get('net_margin_pct'),
        eps=body.get('eps'),
        eps_yoy_pct=body.get('eps_yoy_pct'),
        beat_estimate=body.get('beat_estimate'),
        source=body.get('source', 'manual'),
        article_id=body.get('article_id'),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return jsonable_encoder(row)


# ─── Holdings ─────────────────────────────────────────────────────────────────

@router.get('/holdings/{symbol}')
def holdings(symbol: str, db: Session = Depends(get_db)):
    """Shareholding pattern for a symbol (DB + yfinance fallback)."""
    sym = symbol.upper()
    rows = (
        db.query(HoldingPattern)
        .filter(HoldingPattern.symbol == sym)
        .order_by(desc(HoldingPattern.period_date))
        .limit(8)
        .all()
    )
    yf_data = get_holders(sym)
    return {'symbol': sym, 'db_records': jsonable_encoder(rows), 'yfinance': yf_data}


@router.post('/holdings/{symbol}')
def add_holding(symbol: str, body: dict, db: Session = Depends(get_db)):
    """Manually add a holding pattern row."""
    sym = symbol.upper()
    row = HoldingPattern(
        symbol=sym,
        period_date=datetime.fromisoformat(body['period_date']) if body.get('period_date') else None,
        quarter_label=body.get('quarter_label'),
        promoter_pct=body.get('promoter_pct'),
        promoter_pledge=body.get('promoter_pledge'),
        pledged_pct=body.get('pledged_pct'),
        fii_pct=body.get('fii_pct'),
        dii_pct=body.get('dii_pct'),
        mutual_fund_pct=body.get('mutual_fund_pct'),
        public_pct=body.get('public_pct'),
        fii_change_pct=body.get('fii_change_pct'),
        dii_change_pct=body.get('dii_change_pct'),
        source=body.get('source', 'manual'),
        article_id=body.get('article_id'),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return jsonable_encoder(row)


# ─── Corporate Events ─────────────────────────────────────────────────────────

@router.get('/events/{symbol}')
def corporate_events(
    symbol: str,
    days:   int = Query(90, le=365),
    db: Session = Depends(get_db),
):
    """Corporate events for a symbol in the last N days."""
    sym = symbol.upper()
    cutoff = datetime.utcnow().replace(microsecond=0)
    from datetime import timedelta
    cutoff -= timedelta(days=days)
    rows = (
        db.query(CorporateEvent)
        .filter(CorporateEvent.symbol == sym, CorporateEvent.event_date >= cutoff)
        .order_by(desc(CorporateEvent.event_date))
        .all()
    )
    return jsonable_encoder(rows)


@router.get('/events')
def all_events(
    days:        int = Query(30, le=365),
    event_type:  Optional[str] = None,
    db: Session = Depends(get_db),
):
    """All corporate events across all stocks."""
    from datetime import timedelta
    cutoff = datetime.utcnow() - timedelta(days=days)
    q = db.query(CorporateEvent).filter(CorporateEvent.event_date >= cutoff)
    if event_type:
        q = q.filter(CorporateEvent.event_type.ilike(f'%{event_type}%'))
    rows = q.order_by(desc(CorporateEvent.event_date)).limit(200).all()
    return jsonable_encoder(rows)


@router.post('/events/{symbol}')
def add_event(symbol: str, body: dict, db: Session = Depends(get_db)):
    """Manually add a corporate event."""
    sym = symbol.upper()
    row = CorporateEvent(
        symbol=sym,
        event_date=datetime.fromisoformat(body['event_date']) if body.get('event_date') else None,
        event_type=body.get('event_type', 'board_meeting'),
        description=body.get('description'),
        amount=body.get('amount'),
        ratio=body.get('ratio'),
        ex_date=datetime.fromisoformat(body['ex_date']) if body.get('ex_date') else None,
        record_date=datetime.fromisoformat(body['record_date']) if body.get('record_date') else None,
        source=body.get('source', 'manual'),
        article_id=body.get('article_id'),
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return jsonable_encoder(row)


# ─── Finance Model 1 ──────────────────────────────────────────────────────────

@router.get('/finance-score/{symbol}')
def finance_score(
    symbol:        str,
    lookback_days: int = Query(30, le=180),
    db: Session = Depends(get_db),
):
    """Finance Model 1 score for a single stock."""
    sym = symbol.upper()
    quote = get_quote(sym)
    return compute_finance_score(db, sym, quote=quote, lookback_days=lookback_days)


@router.get('/finance-scores')
def finance_scores_all(
    limit:         int = Query(50, le=250),
    lookback_days: int = Query(30, le=180),
    db: Session = Depends(get_db),
):
    """Finance Model 1 scores for all tracked stocks (top N by importance)."""
    cache_key = f'api:finance-scores:limit={limit}:lookback={lookback_days}'
    cached = cache_get_json(cache_key, None)
    if cached:
        return cached

    syms = [s['symbol'] for s in NIFTY_250[:limit]]
    quotes = get_quotes_batch(syms)
    results = batch_compute_finance_scores(db, syms, quotes=quotes, lookback_days=lookback_days)

    cache_set_json(cache_key, results, 300)
    return results


# ─── Signal Model 2 ───────────────────────────────────────────────────────────

@router.get('/signal/{symbol}')
def trade_signal(
    symbol:        str,
    lookback_days: int = Query(30, le=180),
    db: Session = Depends(get_db),
):
    """Generate trade signal for a single stock."""
    sym   = symbol.upper()
    cache_key = f'signal:{sym}:ld={lookback_days}'
    cached = cache_get_json(cache_key, None)
    if cached:
        return cached

    quote   = get_quote(sym)
    history = get_history(sym, period='3mo')
    finance = compute_finance_score(db, sym, quote=quote, lookback_days=lookback_days)
    signal  = generate_signal(finance, history=history)

    # Persist signal to DB
    _save_signal(db, signal, feature_vector=None)

    cache_set_json(cache_key, signal, 300)
    return signal


@router.get('/signals')
def trade_signals_all(
    limit:         int = Query(50, le=250),
    lookback_days: int = Query(30, le=180),
    signal_filter: Optional[str] = Query(None, regex='^(BULLISH|BEARISH|NEUTRAL)$'),
    db: Session = Depends(get_db),
):
    """Generate trade signals for all Nifty 250 stocks. Cached 5 min."""
    cache_key = f'api:signals:limit={limit}:ld={lookback_days}:filter={signal_filter}'
    cached = cache_get_json(cache_key, None)
    if cached:
        return {'signals': cached, 'from_cache': True}

    syms    = [s['symbol'] for s in NIFTY_250[:limit]]
    quotes  = get_quotes_batch(syms)
    finance = batch_compute_finance_scores(db, syms, quotes=quotes, lookback_days=lookback_days)
    signals = generate_signals_batch(finance)

    if signal_filter:
        signals = [s for s in signals if s.get('signal') == signal_filter]

    cache_set_json(cache_key, signals, 300)
    return {'signals': signals, 'from_cache': False,
            'generated_at': datetime.utcnow().isoformat()}


@router.get('/signals/history/{symbol}')
def signal_history(symbol: str, limit: int = Query(20, le=100), db: Session = Depends(get_db)):
    """Historical signals for a stock."""
    rows = (
        db.query(TradeSignal)
        .filter(TradeSignal.symbol == symbol.upper())
        .order_by(desc(TradeSignal.generated_at))
        .limit(limit)
        .all()
    )
    return jsonable_encoder(rows)


@router.get('/signals/summary')
def signals_summary(db: Session = Depends(get_db)):
    """Count of BULLISH/NEUTRAL/BEARISH from most recent signal run."""
    from sqlalchemy import text
    rows = (
        db.query(TradeSignal.signal, func.count())
        .filter(
            TradeSignal.generated_at >= datetime.utcnow().replace(hour=0, minute=0, second=0)
        )
        .group_by(TradeSignal.signal)
        .all()
    )
    return {r[0]: r[1] for r in rows}


@router.post('/signals/retrain')
def retrain_model(db: Session = Depends(get_db)):
    """Retrain Signal Model 2 on historical feedback data."""
    return retrain_from_db(db)


@router.get('/model/info')
def get_model_info():
    """Signal Model 2 metadata."""
    return model_info()


# ─── Stock detail ─────────────────────────────────────────────────────────────

@router.get('/detail/{symbol}')
def stock_detail(
    symbol:        str,
    lookback_days: int = Query(30, le=180),
    db: Session = Depends(get_db),
):
    """Full intelligence package for a single stock: quote + score + signal +
    earnings + holdings + events + news articles."""
    sym     = symbol.upper()
    stock   = get_by_symbol(sym)
    quote   = get_quote(sym)
    history = get_history(sym, period='3mo')
    holders = get_holders(sym)
    finance = compute_finance_score(db, sym, quote=quote, lookback_days=lookback_days)
    signal  = generate_signal(finance, history=history)

    from datetime import timedelta
    from app.db.models import Article, ArticleEntity
    cutoff = datetime.utcnow() - timedelta(days=lookback_days)
    articles = (
        db.query(Article)
        .join(ArticleEntity, ArticleEntity.article_id == Article.id)
        .filter(
            ArticleEntity.nse_symbol == sym,
            Article.fetched_at >= cutoff,
        )
        .order_by(desc(Article.fetched_at))
        .limit(20)
        .all()
    )

    return {
        'symbol':         sym,
        'stock_info':     stock,
        'quote':          quote,
        'finance_score':  finance,
        'signal':         signal,
        'price_history':  history[-30:] if history else [],
        'holding_data':   holders,
        'recent_articles':jsonable_encoder(articles),
    }


# ─── Helper ───────────────────────────────────────────────────────────────────

def _save_signal(db: Session, signal: dict, feature_vector=None) -> None:
    """Persist a generated signal to the trade_signals table."""
    try:
        pr = signal.get('price_range') or {}
        row = TradeSignal(
            symbol=signal.get('symbol', ''),
            signal=signal.get('signal', 'NEUTRAL'),
            confidence=signal.get('confidence', 0.0),
            finance_score=signal.get('finance_score'),
            price_at_signal=pr.get('current_price'),
            target_low=pr.get('target_low'),
            target_high=pr.get('target_high'),
            target_mid=pr.get('target_mid'),
            horizon_days=pr.get('horizon_days'),
            feature_vector=feature_vector,
            pillar_scores=signal.get('pillar_scores'),
            class_proba=signal.get('class_proba'),
        )
        db.add(row)
        db.commit()
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
