from datetime import datetime, timedelta
import asyncio
import json

from fastapi import APIRouter, Depends, Query, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import StreamingResponse
from sqlalchemy import desc, func, or_
from sqlalchemy.orm import Session

from app.core.config import settings
from app.db.session import get_db, SessionLocal
from app.db.models import Article, SentimentAnalysis, ArticleEntity, IPOEvent, TradeEvent, ImpactScore, RSSSource
from app.services.cache import cache_get_json, cache_set_json, cached_or_compute, invalidate_api_cache
from app.services.display import unique_articles
from app.services.ingest import ingest_all
from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

router = APIRouter(prefix='/api')


def _json(value):
    return jsonable_encoder(value)


def _article_order():
    return desc(func.coalesce(Article.published_at, Article.fetched_at))


def _api_ttl():
    return getattr(settings, 'api_cache_ttl_seconds', 30)


def _news_ttl():
    return getattr(settings, 'news_cache_ttl_seconds', 60)


@router.get('/dashboard')
def dashboard(db: Session = Depends(get_db)):
    def compute():
        latest = unique_articles(db.query(Article).order_by(_article_order()).limit(100).all())[:20]
        sentiment = [
            {'label': r[0], 'count': r[1]}
            for r in db.query(SentimentAnalysis.label, func.count()).group_by(SentimentAnalysis.label).all()
        ]
        impacts = db.query(ImpactScore).order_by(desc(ImpactScore.score)).limit(20).all()
        ipo = db.query(IPOEvent).order_by(desc(IPOEvent.id)).limit(10).all()
        trade = db.query(TradeEvent).order_by(desc(TradeEvent.id)).limit(10).all()
        output = {
            'latest_news': _json(latest),
            'sentiment_counts': sentiment,
            'top_impacts': _json(impacts),
            'ipo_events': _json(ipo),
            'trade_events': _json(trade),
        }
        if latest or sentiment or impacts or ipo or trade:
            cache_set_json('last:dashboard', output, settings.redis_cache_ttl_seconds)
        return output

    output = cached_or_compute('api:dashboard', compute, _api_ttl(), allow_empty=True)
    if not output.get('latest_news') and not output.get('sentiment_counts'):
        return cache_get_json('last:dashboard', output)
    return output


@router.get('/news')
def news(
    limit: int = Query(200, le=1000),
    offset: int = 0,
    category: str | None = None,
    unique: bool = True,
    db: Session = Depends(get_db),
):
    key = f'api:news:limit={limit}:offset={offset}:category={category or "all"}:unique={unique}'

    def compute():
        q = db.query(Article).order_by(_article_order()).offset(offset).limit(limit)
        if category:
            q = q.filter(Article.category == category)
        items = q.all()
        if unique:
            items = unique_articles(items)
        output = _json(items)
        if output:
            cache_set_json('last:news', output, settings.redis_cache_ttl_seconds)
        return output

    output = cached_or_compute(key, compute, _news_ttl(), allow_empty=True)
    return output or cache_get_json('last:news', [])


def _search_articles(db: Session, q: str, limit: int = 200):
    like = f'%{q}%'
    return (
        db.query(Article)
        .outerjoin(ArticleEntity, Article.id == ArticleEntity.article_id)
        .filter(
            or_(
                Article.title.ilike(like),
                Article.summary.ilike(like),
                Article.content.ilike(like),
                Article.category.ilike(like),
                ArticleEntity.entity_text.ilike(like),
                ArticleEntity.nse_symbol.ilike(like),
                ArticleEntity.bse_symbol.ilike(like),
                ArticleEntity.sector.ilike(like),
            )
        )
        .order_by(_article_order())
        .distinct()
        .limit(limit)
        .all()
    )


@router.get('/news/search')
def search(
    q: str,
    limit: int = Query(200, le=1000),
    live: bool = False,
    db: Session = Depends(get_db),
):
    cache_key = f'api:search:q={q}:limit={limit}:live={live}'
    cached = cache_get_json(cache_key, None)
    if cached is not None and not live:
        return cached
    results = _search_articles(db, q, limit)
    inserted = None
    if live and not results:
        inserted = ingest_all(db, mode='search-live', due_only=False)
        invalidate_api_cache()
        results = _search_articles(db, q, limit)
    results = _json(unique_articles(results))
    output = {'query': q, 'count': len(results), 'live_ingest': inserted, 'results': results}
    cache_set_json(cache_key, output, _api_ttl())
    return output


@router.get('/news/sentiment')
def by_sentiment(label: str, db: Session = Depends(get_db)):
    return db.query(Article).join(SentimentAnalysis).filter(SentimentAnalysis.label == label).order_by(_article_order()).limit(200).all()


@router.get('/news/company/{name}')
def by_company(name: str, db: Session = Depends(get_db)):
    like = f'%{name}%'
    return db.query(Article).join(ArticleEntity).filter(ArticleEntity.entity_text.ilike(like)).order_by(_article_order()).limit(200).all()


@router.get('/news/sector/{sector}')
def by_sector(sector: str, db: Session = Depends(get_db)):
    return db.query(Article).join(ArticleEntity).filter(ArticleEntity.sector == sector).order_by(_article_order()).limit(200).all()


@router.get('/news/ipo')
def ipo_news(db: Session = Depends(get_db)):
    return cached_or_compute(
        'api:ipo-news',
        lambda: _json(db.query(IPOEvent).order_by(desc(IPOEvent.id)).limit(200).all()),
        _api_ttl(),
        allow_empty=True,
    )


@router.get('/news/trade-impact')
def trade_news(db: Session = Depends(get_db)):
    return cached_or_compute(
        'api:trade-news',
        lambda: _json(db.query(TradeEvent).order_by(desc(TradeEvent.id)).limit(200).all()),
        _api_ttl(),
        allow_empty=True,
    )


@router.get('/rss-sources')
def sources(db: Session = Depends(get_db)):
    return cached_or_compute('api:rss-sources', lambda: _json(db.query(RSSSource).all()), _api_ttl(), allow_empty=True)


@router.get('/categories')
def categories(db: Session = Depends(get_db)):
    return cached_or_compute(
        'api:categories',
        lambda: [
            {'category': r[0] or 'unknown', 'count': r[1]}
            for r in db.query(Article.category, func.count()).group_by(Article.category).all()
        ],
        _api_ttl(),
        allow_empty=True,
    )


@router.get('/source-stats')
def source_stats(db: Session = Depends(get_db)):
    return cached_or_compute(
        'api:source-stats',
        lambda: [
            {'source': r[0], 'articles': r[1]}
            for r in db.query(RSSSource.name, func.count(Article.id))
            .outerjoin(Article, Article.source_id == RSSSource.id)
            .filter(RSSSource.enabled == True)
            .group_by(RSSSource.id)
            .order_by(desc(func.count(Article.id)))
            .all()
        ],
        _api_ttl(),
        allow_empty=True,
    )


@router.post('/admin/ingest')
def ingest(db: Session = Depends(get_db)):
    owner = 'manual-api'
    if not acquire_ingestion_lock(db, owner):
        return {'inserted': 0, 'skipped': True, 'reason': 'ingestion_already_running'}
    try:
        result = ingest_all(db, mode='manual', due_only=False)
        invalidate_api_cache()
        return jsonable_encoder(result)
    except Exception:
        # FIX: rollback before lock release so session is in a clean state
        try:
            db.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            release_ingestion_lock(db, owner)
        except Exception:
            try:
                db.rollback()
            except Exception:
                pass


@router.get('/stats')
def stats(db: Session = Depends(get_db)):
    def compute():
        output = {
            'articles': db.query(Article).count(),
            'sources': db.query(RSSSource).filter(RSSSource.enabled == True).count(),
            'ipo_events': db.query(IPOEvent).count(),
            'trade_events': db.query(TradeEvent).count(),
            'impact_scores': db.query(ImpactScore).count(),
        }
        if output['articles']:
            cache_set_json('last:stats', output, settings.redis_cache_ttl_seconds)
        return output

    output = cached_or_compute('api:stats', compute, _api_ttl(), allow_empty=True)
    return output if output.get('articles') else cache_get_json('last:stats', output)


@router.post('/admin/ingest-due')
def ingest_due(db: Session = Depends(get_db)):
    owner = 'scheduled-api'
    if not acquire_ingestion_lock(db, owner):
        return {'inserted': 0, 'skipped': True, 'reason': 'ingestion_already_running'}
    try:
        result = ingest_all(db, mode='scheduled', due_only=True)
        invalidate_api_cache()
        return jsonable_encoder(result)
    except Exception:
        try:
            db.rollback()
        except Exception:
            pass
        raise
    finally:
        try:
            release_ingestion_lock(db, owner)
        except Exception:
            try:
                db.rollback()
            except Exception:
                pass


@router.get('/source-health')
def source_health(include_disabled: bool = False, db: Session = Depends(get_db)):
    def compute():
        q = db.query(RSSSource)
        if not include_disabled:
            q = q.filter(RSSSource.enabled == True)
        rows = q.order_by(desc(RSSSource.credibility)).all()
        return [
            {
                'id': r.id,
                'source': r.name,
                'source_type': r.source_type,
                'enabled': r.enabled,
                'status': r.status,
                # FIX: serialise datetime fields as ISO strings, not raw datetime objects,
                # so the JSON response is valid and the UI can parse them.
                'last_checked_at': r.last_checked_at.isoformat() if r.last_checked_at else None,
                'last_success_at': r.last_success_at.isoformat() if r.last_success_at else None,
                'last_error_at': r.last_error_at.isoformat() if r.last_error_at else None,
                'last_error': r.last_error,
                'consecutive_failures': r.consecutive_failures,
                'next_run_at': r.next_run_at.isoformat() if r.next_run_at else None,
                'interval_seconds': r.interval_seconds,
            }
            for r in rows
        ]

    return cached_or_compute(
        f'api:source-health:disabled={include_disabled}',
        compute,
        _api_ttl(),
        allow_empty=True,
    )


@router.get('/ingestion-runs')
def ingestion_runs(limit: int = Query(20, le=100), db: Session = Depends(get_db)):
    from app.db.models import IngestionRun

    stale_before = datetime.utcnow() - timedelta(seconds=settings.ingestion_lock_ttl_seconds)
    stale_rows = (
        db.query(IngestionRun)
        .filter(IngestionRun.status == 'running', IngestionRun.started_at < stale_before)
        .all()
    )
    if stale_rows:
        for run in stale_rows:
            run.status = 'stale'
            run.finished_at = run.finished_at or datetime.utcnow()
        db.commit()
        invalidate_api_cache()

    def compute():
        rows = db.query(IngestionRun).order_by(desc(IngestionRun.id)).limit(limit).all()
        # FIX: use jsonable_encoder so the IngestionRun.summary JSON column
        # (which may contain datetime strings embedded during ingest) and all
        # datetime fields on the model are safely serialised. Without this,
        # FastAPI's default encoder raises "Object of type datetime is not
        # JSON serializable" for any datetime stored inside the JSON column.
        return jsonable_encoder(rows)

    return cached_or_compute(f'api:ingestion-runs:{limit}', compute, _api_ttl(), allow_empty=True)


@router.get('/debug/selenium-moneycontrol')
def debug_selenium_moneycontrol(url: str = 'https://www.moneycontrol.com/news/index-sitemap-2026.xml'):
    from app.services.selenium_connector import selenium_fetch_page_source, selenium_available

    ok, msg = selenium_available()
    result = {
        'selenium_import_ok': ok,
        'message': msg,
        'url': url,
        'log_path': settings.selenium_log_path,
    }
    if not ok:
        return result
    try:
        text = selenium_fetch_page_source(url, wait_text='urlset')
        result.update({
            'ok': True,
            'length': len(text),
            'contains_urlset': '<urlset' in text,
            'preview': text[:1000],
        })
    except Exception as ex:
        result.update({'ok': False, 'error': str(ex)})
    return result


@router.get('/debug/html-source/{source_id}')
def debug_html_source(source_id: int, fetch_articles: bool = False, db: Session = Depends(get_db)):
    from app.services.html_connector import fetch_html, extract_index_links, extract_article, polite_sleep

    source = db.query(RSSSource).filter(RSSSource.id == source_id).first()
    if not source:
        return {'ok': False, 'error': 'source_not_found'}
    result = {
        'ok': True,
        'source': source.name,
        'source_type': source.source_type,
        'url': source.url,
        'allowed_patterns': source.allowed_patterns,
        'blocked_patterns': source.blocked_patterns,
    }
    try:
        if source.source_type == 'sitemap_xml':
            from app.services.sitemap_connector import fetch_sitemap_xml, parse_sitemap_urls

            xml_text = fetch_sitemap_xml(source.url)
            links = parse_sitemap_urls(xml_text, max_links=source.article_limit or settings.html_connector_max_links)
            result['index_fetch'] = 'ok'
            result['sitemap_fetch'] = 'ok'
            result['links_count'] = len(links)
            result['sample_links'] = links[:10]
            if fetch_articles:
                articles = []
                for link in links[: settings.debug_html_sample_articles]:
                    try:
                        polite_sleep(source.polite_delay_ms or 500)
                        article_html = fetch_html(link['url'])
                        article = extract_article(article_html, link['url'], fallback_title=link.get('title') or '')
                        articles.append({
                            'url': article['url'],
                            'title': article['title'] or link.get('title'),
                            'summary_length': len(article.get('summary') or link.get('keywords') or ''),
                            'content_length': len(article.get('content') or link.get('title') or ''),
                            'published_at': (
                                article.get('published_at') or link.get('publication_date') or link.get('lastmod')
                            ),
                        })
                    except Exception as ex:
                        articles.append({
                            'url': link['url'],
                            'title': link.get('title'),
                            'published_at': link.get('publication_date') or link.get('lastmod'),
                            'error': str(ex),
                            'fallback_available': True,
                        })
                result['sample_articles'] = articles
        else:
            html = fetch_html(source.url)
            links = extract_index_links(
                html,
                source.url,
                source.allowed_patterns or [],
                source.blocked_patterns or [],
                max_links=source.article_limit or 40,
            )
            result['index_fetch'] = 'ok'
            result['links_count'] = len(links)
            result['sample_links'] = links[:10]
            if fetch_articles:
                articles = []
                for link in links[: settings.debug_html_sample_articles]:
                    try:
                        polite_sleep(source.polite_delay_ms or 500)
                        article_html = fetch_html(link['url'])
                        article = extract_article(article_html, link['url'], fallback_title=link.get('anchor_text') or '')
                        articles.append({
                            'url': article['url'],
                            'title': article['title'],
                            'summary_length': len(article.get('summary') or ''),
                            'content_length': len(article.get('content') or ''),
                            'published_at': article.get('published_at'),
                        })
                    except Exception as ex:
                        articles.append({'url': link['url'], 'error': str(ex)})
                result['sample_articles'] = articles
    except Exception as ex:
        result['ok'] = False
        result['index_fetch'] = 'failed'
        result['error'] = str(ex)
    return result


# FIX: The SSE /events endpoint previously called stats(db) and source_health(False, db)
# directly. Those are FastAPI route functions that expect to be called via dependency
# injection by the framework. Calling them directly inside an async generator:
#   (a) bypasses SlowAPI rate limiting which requires a Request object and raises
#       AttributeError when it tries to read request.state
#   (b) passes a Session object as the first positional arg, which those functions
#       interpret as the wrong parameter
# The fix uses a fresh SessionLocal() per tick and calls the underlying DB queries
# directly, avoiding all dependency-injection machinery inside the streaming generator.
@router.get('/events')
async def events():
    async def stream():
        while True:
            db = SessionLocal()
            try:
                stats_data = {
                    'articles': db.query(Article).count(),
                    'sources': db.query(RSSSource).filter(RSSSource.enabled == True).count(),
                    'ipo_events': db.query(IPOEvent).count(),
                    'trade_events': db.query(TradeEvent).count(),
                }
                health_rows = db.query(RSSSource).filter(RSSSource.enabled == True).order_by(desc(RSSSource.credibility)).all()
                health_data = [
                    {
                        'id': r.id,
                        'source': r.name,
                        'source_type': r.source_type,
                        'status': r.status,
                        'consecutive_failures': r.consecutive_failures,
                        'last_success_at': r.last_success_at.isoformat() if r.last_success_at else None,
                        'next_run_at': r.next_run_at.isoformat() if r.next_run_at else None,
                    }
                    for r in health_rows
                ]
                payload = {'stats': stats_data, 'source_health': health_data}
                yield f"event: dashboard\ndata: {json.dumps(payload, default=str)}\n\n"
            except Exception:
                yield f"event: dashboard\ndata: {json.dumps({'error': 'tick_failed'})}\n\n"
            finally:
                db.close()
            await asyncio.sleep(settings.sse_refresh_seconds)

    return StreamingResponse(stream(), media_type='text/event-stream')


@router.get('/debug/selenium-moneycontrol-deep')
def debug_selenium_moneycontrol_deep(
    url: str = 'https://www.moneycontrol.com/news/index-sitemap-2026.xml',
    fetch_children: bool = True,
    max_children: int = 2,
):
    """Step-by-step Moneycontrol Selenium pipeline debugger.

    Runs each stage independently and reports what was found at each step,
    so you can see exactly where articles are being lost.

    Stages:
      1. selenium_available() — can Chrome be started?
      2. selenium_fetch_page_source() — raw content from Chrome
      3. _to_xml_text() — XML extraction from Chrome output
      4. parse_sitemap_index() — child sitemap URLs
      5. For each child: fetch → parse → article count
    """
    from app.services.selenium_connector import selenium_available, selenium_fetch_page_source
    from app.services.sitemap_connector import (
        _to_xml_text,
        parse_sitemap_index,
        parse_sitemap_urls,
        fetch_sitemap_xml,
        _is_financial_url,
    )

    result = {
        'url': url,
        'stages': {},
        'final_article_count': 0,
        'verdict': '',
    }

    # Stage 1: Selenium import
    ok, msg = selenium_available()
    result['stages']['1_selenium_import'] = {'ok': ok, 'message': msg}
    if not ok:
        result['verdict'] = 'FAIL: Selenium not installed. pip install selenium>=4.21.0'
        return result

    # Stage 2: Fetch root URL
    try:
        raw = selenium_fetch_page_source(url, wait_text='sitemap')
        result['stages']['2_raw_fetch'] = {
            'ok': True,
            'length': len(raw),
            'has_sitemapindex': '<sitemapindex' in raw,
            'has_urlset': '<urlset' in raw,
            'preview': raw[:600],
        }
    except Exception as ex:
        result['stages']['2_raw_fetch'] = {'ok': False, 'error': str(ex)}
        result['verdict'] = 'FAIL: Selenium fetch failed — check ChromeDriver PATH and version'
        return result

    # Stage 3: XML extraction
    xml_text = _to_xml_text(raw)
    result['stages']['3_xml_extract'] = {
        'ok': bool(xml_text),
        'length': len(xml_text),
        'has_sitemapindex': '<sitemapindex' in xml_text,
        'has_urlset': '<urlset' in xml_text,
        'preview': xml_text[:600],
    }
    if not xml_text:
        result['verdict'] = (
            'FAIL: _to_xml_text returned empty. '
            'Chrome page_source has neither <sitemapindex> nor <urlset> after unescape. '
            'Check stage 2 preview — if it is plain text (just URLs and dates, no XML tags), '
            'you are running the OLD selenium_connector.py. Deploy the fixed version.'
        )
        return result

    # Stage 4: Parse as index or urlset
    articles_from_root = []
    child_results = []

    if '<sitemapindex' in xml_text:
        children = parse_sitemap_index(
            xml_text,
            max_sitemaps=max(max_children, 2),
            backfill_days=settings.startup_bootstrap_backfill_days,
        )
        result['stages']['4_parse_index'] = {
            'ok': True,
            'child_count': len(children),
            'children': [{'url': c['url'], 'lastmod': c['lastmod'].isoformat() if c.get('lastmod') else None} for c in children],
        }
        if not children:
            result['verdict'] = (
                'FAIL: sitemapindex parsed but 0 child sitemaps found within backfill window. '
                f'Backfill window = {settings.startup_bootstrap_backfill_days} days. '
                'Try increasing STARTUP_BOOTSTRAP_BACKFILL_DAYS in .env.'
            )
            return result

        # Stage 5: Fetch and parse each child
        for i, child in enumerate(children[:max_children]):
            child_stage = {'url': child['url'], 'ok': False}
            try:
                child_xml = fetch_sitemap_xml(child['url'], force_selenium=True)
                child_stage['raw_length'] = len(child_xml)
                child_stage['has_urlset'] = '<urlset' in child_xml
                links = parse_sitemap_urls(child_xml, max_links=20)
                financial = [l for l in links if _is_financial_url(l['url'])]
                child_stage['ok'] = True
                child_stage['total_links'] = len(links)
                child_stage['financial_links'] = len(financial)
                child_stage['sample_urls'] = [l['url'] for l in (financial or links)[:5]]
                child_stage['sample_titles'] = [l.get('title') for l in (financial or links)[:5]]
                articles_from_root.extend(financial or links)
            except Exception as ex:
                child_stage['error'] = str(ex)
            child_results.append(child_stage)

        result['stages']['5_child_fetches'] = child_results

    else:
        links = parse_sitemap_urls(xml_text, max_links=20)
        financial = [l for l in links if _is_financial_url(l['url'])]
        articles_from_root = financial or links
        result['stages']['4_parse_urlset'] = {
            'ok': True,
            'total_links': len(links),
            'financial_links': len(financial),
            'sample_urls': [l['url'] for l in articles_from_root[:5]],
        }

    result['final_article_count'] = len(articles_from_root)

    if result['final_article_count'] == 0:
        result['verdict'] = (
            'FAIL: 0 articles parsed. Check stage 5 child_fetches — if child raw_length is 0 '
            'or has_urlset is false, child sitemaps are failing. '
            'If financial_links=0 but total_links>0, the URL filter may be too strict '
            '(all URLs are being blocked). Check sample_urls to verify URL patterns.'
        )
    else:
        result['verdict'] = (
            f'OK: {result["final_article_count"]} articles ready to insert. '
            'If they are not appearing in /api/news, run POST /api/admin/ingest and check '
            '/api/ingestion-runs for errors.'
        )

    return result
