from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from prometheus_fastapi_instrumentator import Instrumentator
from slowapi import Limiter
from slowapi.middleware import SlowAPIMiddleware
from slowapi.util import get_remote_address

from app.api.routes import router
from app.api.stock_routes import router as stock_router
from app.core.config import settings
from app.services.bootstrap import start_startup_bootstrap
from app.services.scheduler import start_scheduler, stop_scheduler
from app.services.selenium_connector import selenium_available


def _startup_log(msg: str) -> None:
    path = Path('./logs/startup.log')
    path.parent.mkdir(parents=True, exist_ok=True)
    from datetime import datetime
    with path.open('a', encoding='utf-8') as f:
        f.write(f'[{datetime.utcnow().isoformat(timespec="seconds")}Z] {msg}\n')


@asynccontextmanager
async def lifespan(app: FastAPI):
    _startup_log('=== app startup begin ===')

    if settings.selenium_start_on_app_start:
        ok, message = selenium_available()
        app.state.selenium_warmup = {'ok': ok, 'message': message}
        _startup_log(f'selenium_available={ok} message={message}')
    else:
        app.state.selenium_warmup = {'ok': False, 'message': 'disabled'}

    start_scheduler()
    _startup_log(f'scheduler started interval={settings.ingestion_interval_seconds}s')

    result = start_startup_bootstrap()
    app.state.startup_bootstrap = result
    _startup_log(f'startup_bootstrap={result}')

    # Pre-warm signal model
    try:
        from app.services.signal_model import ensure_trained
        ensure_trained()
        _startup_log('signal model pre-warmed')
    except Exception as ex:
        _startup_log(f'signal model warmup error: {ex}')

    _startup_log('=== app startup complete ===')
    yield
    stop_scheduler()
    _startup_log('=== app shutdown complete ===')


app = FastAPI(title=settings.app_name, version='3.0.0', lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[x.strip() for x in settings.cors_origins.split(',')],
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

app.state.limiter = Limiter(key_func=get_remote_address, default_limits=['180/minute'])
app.add_middleware(SlowAPIMiddleware)


@app.middleware('http')
async def secure_headers(request, call_next):
    response = await call_next(request)
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'no-referrer'
    return response


@app.get('/health')
def health():
    return {
        'status': 'ok',
        'app': settings.app_name,
        'version': '3.0.0',
        'environment': settings.environment,
        'selenium_warmup': getattr(app.state, 'selenium_warmup', None),
        'startup_bootstrap': getattr(app.state, 'startup_bootstrap', None),
    }


app.include_router(router)
app.include_router(stock_router)
Instrumentator().instrument(app).expose(app)
