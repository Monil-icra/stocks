"""
models.py — Core ORM models.

Extended models (StockUniverse, StockQuote, EarningsResult, HoldingPattern,
CorporateEvent, TradeSignal) live in models_extended.py but are imported here
so that Base.metadata.create_all() creates ALL tables in one call.
"""
from datetime import datetime, timezone
from sqlalchemy import (
    Boolean, DateTime, Float, ForeignKey, Index,
    Integer, String, Text, JSON,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


def utcnow():
    return datetime.now(timezone.utc)


class User(Base):
    __tablename__ = 'users'
    id: Mapped[int]       = mapped_column(Integer, primary_key=True)
    email: Mapped[str]    = mapped_column(String(255), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255))
    role: Mapped[str]     = mapped_column(String(50), default='viewer')
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class RSSSource(Base):
    __tablename__ = 'rss_sources'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    name: Mapped[str]         = mapped_column(String(160), unique=True)
    url: Mapped[str]          = mapped_column(Text)
    credibility: Mapped[float]= mapped_column(Float, default=70)
    category: Mapped[str|None]= mapped_column(String(80))
    enabled: Mapped[bool]     = mapped_column(Boolean, default=True)
    interval_seconds: Mapped[int] = mapped_column(Integer, default=300)
    next_run_at: Mapped[datetime|None]    = mapped_column(DateTime(timezone=True), nullable=True)
    last_checked_at: Mapped[datetime|None]= mapped_column(DateTime(timezone=True), nullable=True)
    last_success_at: Mapped[datetime|None]= mapped_column(DateTime(timezone=True), nullable=True)
    last_error_at: Mapped[datetime|None]  = mapped_column(DateTime(timezone=True), nullable=True)
    last_error: Mapped[str|None]          = mapped_column(Text, nullable=True)
    consecutive_failures: Mapped[int]     = mapped_column(Integer, default=0)
    status: Mapped[str]       = mapped_column(String(40), default='healthy')
    source_type: Mapped[str]  = mapped_column(String(40), default='rss')
    allowed_patterns: Mapped[dict] = mapped_column(JSON, default=list)
    blocked_patterns: Mapped[dict] = mapped_column(JSON, default=list)
    article_limit: Mapped[int]     = mapped_column(Integer, default=50)
    polite_delay_ms: Mapped[int]   = mapped_column(Integer, default=500)


class Article(Base):
    __tablename__ = 'articles'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    source_id: Mapped[int|None] = mapped_column(ForeignKey('rss_sources.id'))
    title: Mapped[str]        = mapped_column(Text)
    url: Mapped[str]          = mapped_column(Text)
    url_hash: Mapped[str]     = mapped_column(String(64), unique=True, index=True)
    content_hash: Mapped[str] = mapped_column(String(64), index=True)
    summary: Mapped[str|None] = mapped_column(Text)
    content: Mapped[str|None] = mapped_column(Text)
    language: Mapped[str]     = mapped_column(String(16), default='en')
    published_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True), index=True)
    fetched_at: Mapped[datetime]        = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    category: Mapped[str|None]= mapped_column(String(80), index=True)
    source = relationship('RSSSource')


class ArticleEntity(Base):
    __tablename__ = 'article_entities'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int]   = mapped_column(ForeignKey('articles.id'), index=True)
    entity_text: Mapped[str]  = mapped_column(String(255), index=True)
    entity_type: Mapped[str]  = mapped_column(String(50),  index=True)
    nse_symbol: Mapped[str|None] = mapped_column(String(40), index=True)
    bse_symbol: Mapped[str|None] = mapped_column(String(40), index=True)
    sector: Mapped[str|None]  = mapped_column(String(120),  index=True)
    confidence: Mapped[float] = mapped_column(Float, default=0)


class SentimentAnalysis(Base):
    __tablename__ = 'sentiment_analysis'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int]   = mapped_column(ForeignKey('articles.id'), unique=True)
    label: Mapped[str]        = mapped_column(String(20), index=True)
    score: Mapped[float]      = mapped_column(Float)
    engine: Mapped[str]       = mapped_column(String(50), default='vader')


class ImpactScore(Base):
    __tablename__ = 'impact_scores'
    id: Mapped[int]              = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int]      = mapped_column(ForeignKey('articles.id'), index=True)
    company_name: Mapped[str|None]= mapped_column(String(255), index=True)
    sector: Mapped[str|None]     = mapped_column(String(120), index=True)
    score: Mapped[float]         = mapped_column(Float, index=True)
    explanation: Mapped[dict]    = mapped_column(JSON, default=dict)


class IPOEvent(Base):
    __tablename__ = 'ipo_events'
    id: Mapped[int]              = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int|None] = mapped_column(ForeignKey('articles.id'))
    company_name: Mapped[str]    = mapped_column(String(255), index=True)
    event_type: Mapped[str]      = mapped_column(String(80),  index=True)
    status: Mapped[str]          = mapped_column(String(80),  index=True)
    event_date: Mapped[datetime|None] = mapped_column(DateTime(timezone=True))


class TradeEvent(Base):
    __tablename__ = 'trade_events'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int]   = mapped_column(ForeignKey('articles.id'), index=True)
    event_type: Mapped[str]   = mapped_column(String(120), index=True)
    affected_sectors: Mapped[dict] = mapped_column(JSON, default=list)
    direction: Mapped[str]    = mapped_column(String(20))
    confidence: Mapped[float] = mapped_column(Float, default=0)


class Alert(Base):
    __tablename__ = 'alerts'
    id: Mapped[int]              = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int|None] = mapped_column(ForeignKey('articles.id'))
    alert_type: Mapped[str]      = mapped_column(String(80), index=True)
    message: Mapped[str]         = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    delivered: Mapped[bool]      = mapped_column(Boolean, default=False)


class NewsEmbedding(Base):
    __tablename__ = 'news_embeddings'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True)
    article_id: Mapped[int]   = mapped_column(ForeignKey('articles.id'), unique=True)
    vector: Mapped[list|None] = mapped_column(JSON, default=list)
    engine: Mapped[str]       = mapped_column(String(80), default='fallback')


Index('ix_articles_category_fetched', Article.category, Article.fetched_at)


class IngestionLock(Base):
    __tablename__ = 'ingestion_locks'
    id: Mapped[int]           = mapped_column(Integer, primary_key=True, default=1)
    owner: Mapped[str]        = mapped_column(String(120), default='scheduler')
    locked_until: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    created_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at: Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=utcnow)


class IngestionRun(Base):
    __tablename__ = 'ingestion_runs'
    id: Mapped[int]              = mapped_column(Integer, primary_key=True)
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    finished_at: Mapped[datetime|None] = mapped_column(DateTime(timezone=True), nullable=True)
    mode: Mapped[str]            = mapped_column(String(40), default='scheduled')
    inserted: Mapped[int]        = mapped_column(Integer, default=0)
    status: Mapped[str]          = mapped_column(String(40), default='running')
    summary: Mapped[dict]        = mapped_column(JSON, default=dict)


# ── Import extended models so Base.metadata sees all tables ───────────────────
# This must be at the bottom AFTER Base is defined so the import
# resolves without circular dependency.
from app.db.models_extended import (  # noqa: E402, F401
    StockUniverse,
    StockQuote,
    EarningsResult,
    HoldingPattern,
    CorporateEvent,
    TradeSignal,
)
