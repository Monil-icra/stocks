from pathlib import Path
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.core.config import settings


def _sqlite_path_from_url(url: str):
    if not url.startswith('sqlite:///'):
        return None
    db_path = url.replace('sqlite:///', '', 1)
    if not db_path or db_path == ':memory:':
        return None
    return db_path


db_path = _sqlite_path_from_url(settings.database_url)
if db_path:
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)

connect_args = (
    {'check_same_thread': False, 'timeout': 30}
    if settings.database_url.startswith('sqlite')
    else {}
)

engine = create_engine(
    settings.database_url,
    pool_pre_ping=True,
    future=True,
    connect_args=connect_args,
)

SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
