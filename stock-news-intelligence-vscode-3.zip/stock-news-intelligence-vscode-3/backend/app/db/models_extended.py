"""
models_extended.py — Additional ORM models for the stock intelligence layer.

Import these alongside the existing models.py models.
Add to db/models.py imports:
    from app.db.models_extended import (
        StockUniverse, StockQuote, EarningsResult,
        HoldingPattern, CorporateEvent, TradeSignal,
    )
"""
from datetime import datetime, timezone
from sqlalchemy import (
    Boolean, DateTime, Float, ForeignKey, Index,
    Integer, String, Text, JSON,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.models import Base


def utcnow():
    return datetime.now(timezone.utc)


class StockUniverse(Base):
    """Master list of all tracked stocks (Nifty 250 + additions)."""
    __tablename__ = 'stock_universe'

    id:        Mapped[int]       = mapped_column(Integer, primary_key=True)
    symbol:    Mapped[str]       = mapped_column(String(20),  unique=True, index=True)
    name:      Mapped[str]       = mapped_column(String(255))
    sector:    Mapped[str|None]  = mapped_column(String(120), index=True)
    industry:  Mapped[str|None]  = mapped_column(String(120))
    indices:   Mapped[dict]      = mapped_column(JSON, default=list)   # ["NIFTY50", ...]
    importance:Mapped[float]     = mapped_column(Float, default=50)
    enabled:   Mapped[bool]      = mapped_column(Boolean, default=True)
    created_at:Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=utcnow)
    updated_at:Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=utcnow,
                                                  onupdate=utcnow)


class StockQuote(Base):
    """Real-time and end-of-day price snapshots from yfinance."""
    __tablename__ = 'stock_quotes'

    id:               Mapped[int]       = mapped_column(Integer, primary_key=True)
    symbol:           Mapped[str]       = mapped_column(String(20), index=True)
    fetched_at:       Mapped[datetime]  = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    price:            Mapped[float|None]= mapped_column(Float)
    prev_close:       Mapped[float|None]= mapped_column(Float)
    open:             Mapped[float|None]= mapped_column(Float)
    day_high:         Mapped[float|None]= mapped_column(Float)
    day_low:          Mapped[float|None]= mapped_column(Float)
    volume:           Mapped[float|None]= mapped_column(Float)
    week52_high:      Mapped[float|None]= mapped_column(Float)
    week52_low:       Mapped[float|None]= mapped_column(Float)
    market_cap:       Mapped[float|None]= mapped_column(Float)
    pe_ratio:         Mapped[float|None]= mapped_column(Float)
    eps:              Mapped[float|None]= mapped_column(Float)
    book_value:       Mapped[float|None]= mapped_column(Float)
    dividend_yield:   Mapped[float|None]= mapped_column(Float)
    roe:              Mapped[float|None]= mapped_column(Float)
    debt_to_equity:   Mapped[float|None]= mapped_column(Float)
    revenue_growth:   Mapped[float|None]= mapped_column(Float)
    earnings_growth:  Mapped[float|None]= mapped_column(Float)
    profit_margins:   Mapped[float|None]= mapped_column(Float)
    beta:             Mapped[float|None]= mapped_column(Float)
    change:           Mapped[float|None]= mapped_column(Float)
    change_pct:       Mapped[float|None]= mapped_column(Float)
    currency:         Mapped[str]       = mapped_column(String(10), default='INR')
    source:           Mapped[str]       = mapped_column(String(40), default='yfinance')

    __table_args__ = (
        Index('ix_stock_quotes_symbol_fetched', 'symbol', 'fetched_at'),
    )


class EarningsResult(Base):
    """Quarterly earnings results: revenue, net profit, YoY change, EPS."""
    __tablename__ = 'earnings_results'

    id:                  Mapped[int]        = mapped_column(Integer, primary_key=True)
    symbol:              Mapped[str]        = mapped_column(String(20), index=True)
    period_end:          Mapped[datetime|None] = mapped_column(DateTime(timezone=True), index=True)
    quarter_label:       Mapped[str|None]   = mapped_column(String(20))   # e.g. "Q1FY26"
    revenue_cr:          Mapped[float|None] = mapped_column(Float)         # ₹ crore
    revenue_yoy_pct:     Mapped[float|None] = mapped_column(Float)         # %
    net_profit_cr:       Mapped[float|None] = mapped_column(Float)
    net_profit_yoy_pct:  Mapped[float|None] = mapped_column(Float)
    net_margin_pct:      Mapped[float|None] = mapped_column(Float)
    eps:                 Mapped[float|None] = mapped_column(Float)
    eps_yoy_pct:         Mapped[float|None] = mapped_column(Float)
    ebitda_cr:           Mapped[float|None] = mapped_column(Float)
    ebitda_margin_pct:   Mapped[float|None] = mapped_column(Float)
    revenue_estimate_cr: Mapped[float|None] = mapped_column(Float)         # analyst estimate
    eps_estimate:        Mapped[float|None] = mapped_column(Float)
    beat_estimate:       Mapped[bool|None]  = mapped_column(Boolean)       # True/False/None
    source:              Mapped[str]        = mapped_column(String(80), default='manual')
    article_id:          Mapped[int|None]   = mapped_column(ForeignKey('articles.id'))
    created_at:          Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (
        Index('ix_earnings_symbol_period', 'symbol', 'period_end'),
    )


class HoldingPattern(Base):
    """Quarterly shareholding pattern: promoter, FII, DII, public."""
    __tablename__ = 'holding_patterns'

    id:               Mapped[int]        = mapped_column(Integer, primary_key=True)
    symbol:           Mapped[str]        = mapped_column(String(20), index=True)
    period_date:      Mapped[datetime|None] = mapped_column(DateTime(timezone=True), index=True)
    quarter_label:    Mapped[str|None]   = mapped_column(String(20))       # e.g. "Sep-2025"
    promoter_pct:     Mapped[float|None] = mapped_column(Float)
    promoter_pledge:  Mapped[float|None] = mapped_column(Float)            # % of promoter holding pledged
    pledged_pct:      Mapped[float|None] = mapped_column(Float)            # % of total shares pledged
    fii_pct:          Mapped[float|None] = mapped_column(Float)
    dii_pct:          Mapped[float|None] = mapped_column(Float)
    mutual_fund_pct:  Mapped[float|None] = mapped_column(Float)
    public_pct:       Mapped[float|None] = mapped_column(Float)
    fii_change_pct:   Mapped[float|None] = mapped_column(Float)            # QoQ change
    dii_change_pct:   Mapped[float|None] = mapped_column(Float)
    source:           Mapped[str]        = mapped_column(String(80), default='manual')
    article_id:       Mapped[int|None]   = mapped_column(ForeignKey('articles.id'))
    created_at:       Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (
        Index('ix_holding_symbol_period', 'symbol', 'period_date'),
    )


class CorporateEvent(Base):
    """Corporate actions: dividends, splits, buybacks, board meetings, AGM, orders."""
    __tablename__ = 'corporate_events'

    id:           Mapped[int]        = mapped_column(Integer, primary_key=True)
    symbol:       Mapped[str]        = mapped_column(String(20), index=True)
    event_date:   Mapped[datetime|None] = mapped_column(DateTime(timezone=True), index=True)
    event_type:   Mapped[str]        = mapped_column(String(80), index=True)
    # Types: dividend | bonus_issue | stock_split | buyback | agm | egm |
    #        board_meeting | record_date | order_win | acquisition |
    #        capacity_expansion | rights_issue | promoter_selling |
    #        fii_selling | merger | delisting | listing | partnership
    description:  Mapped[str|None]   = mapped_column(Text)
    amount:       Mapped[float|None] = mapped_column(Float)               # ₹ value if applicable
    ratio:        Mapped[str|None]   = mapped_column(String(40))          # e.g. "1:5" for split
    ex_date:      Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
    record_date:  Mapped[datetime|None] = mapped_column(DateTime(timezone=True))
    source:       Mapped[str]        = mapped_column(String(80), default='manual')
    article_id:   Mapped[int|None]   = mapped_column(ForeignKey('articles.id'))
    created_at:   Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=utcnow)

    __table_args__ = (
        Index('ix_corp_events_symbol_date', 'symbol', 'event_date'),
    )


class TradeSignal(Base):
    """
    Generated trade signals from Signal Model 2.
    Stores feature vector, signal, confidence, price range.
    actual_signal is filled later (for model retraining feedback loop).
    """
    __tablename__ = 'trade_signals'

    id:               Mapped[int]        = mapped_column(Integer, primary_key=True)
    symbol:           Mapped[str]        = mapped_column(String(20), index=True)
    generated_at:     Mapped[datetime]   = mapped_column(DateTime(timezone=True), default=utcnow, index=True)
    signal:           Mapped[str]        = mapped_column(String(20), index=True)  # BULLISH|NEUTRAL|BEARISH
    confidence:       Mapped[float]      = mapped_column(Float)
    finance_score:    Mapped[float|None] = mapped_column(Float)
    price_at_signal:  Mapped[float|None] = mapped_column(Float)
    target_low:       Mapped[float|None] = mapped_column(Float)
    target_high:      Mapped[float|None] = mapped_column(Float)
    target_mid:       Mapped[float|None] = mapped_column(Float)
    horizon_days:     Mapped[int|None]   = mapped_column(Integer)
    feature_vector:   Mapped[list|None]  = mapped_column(JSON)            # for retraining
    pillar_scores:    Mapped[dict|None]  = mapped_column(JSON)
    class_proba:      Mapped[dict|None]  = mapped_column(JSON)
    actual_signal:    Mapped[str|None]   = mapped_column(String(20))      # filled after horizon elapses
    actual_return_pct:Mapped[float|None] = mapped_column(Float)           # actual price change %
    model_version:    Mapped[str|None]   = mapped_column(String(40))

    __table_args__ = (
        Index('ix_trade_signals_symbol_generated', 'symbol', 'generated_at'),
    )
