"""
init_db.py — Database initialisation and source seeding.

Run once (or after any schema change):
    python -m app.db.init_db

Safe to re-run on an existing database (idempotent upserts).
"""
from app.db.session import engine, SessionLocal
from app.core.config import settings
from app.db.models import Base, RSSSource
from app.db.models_extended import (
    StockUniverse, StockQuote, EarningsResult,
    HoldingPattern, CorporateEvent, TradeSignal,
)
from app.services.nifty250 import NIFTY_250
from app.services.cache import invalidate_api_cache, cache_delete_pattern

RSS = [
    ('Economic Times Markets',
     'https://economictimes.indiatimes.com/markets/rssfeeds/1977021501.cms',     90, 'markets'),
    ('ET Foreign Trade',
     'https://economictimes.indiatimes.com/news/economy/foreign-trade/rssfeeds/13357270.cms', 88, 'trade'),
    ('ET Earnings',
     'https://economictimes.indiatimes.com/markets/earnings/rssfeeds/2143008.cms', 88, 'earnings'),
    ('ET Companies',
     'https://economictimes.indiatimes.com/markets/stocks/rssfeeds/2146842.cms',  87, 'companies'),
    ('CNBC TV18 Markets',   'https://www.cnbctv18.com/rss/market.xml',    88, 'markets'),
    ('CNBC TV18 Economy',   'https://www.cnbctv18.com/rss/economy.xml',   85, 'economy'),
    ('CNBC TV18 Companies', 'https://www.cnbctv18.com/rss/companies.xml', 85, 'companies'),
    ('NDTV Profit Markets', 'https://www.ndtvprofit.com/rss/market.xml',  84, 'markets'),
    ('NDTV Profit Economy', 'https://www.ndtvprofit.com/rss/economy.xml', 82, 'economy'),
    ('NDTV Profit Results', 'https://www.ndtvprofit.com/rss/results.xml', 84, 'earnings'),
    ('Zee Business Markets',   'https://www.zeebiz.com/rss/markets.xml',   80, 'markets'),
    ('Zee Business Companies', 'https://www.zeebiz.com/rss/companies.xml', 78, 'companies'),
    ('Zee Business IPO',       'https://www.zeebiz.com/rss/ipo.xml',       78, 'ipo'),
    ('Business Standard Markets',
     'https://www.business-standard.com/rss/markets-10601.rss', 82, 'markets'),
    ('Business Standard Economy',
     'https://www.business-standard.com/rss/economy-10201.rss', 80, 'economy'),
    ('Business Standard Companies',
     'https://www.business-standard.com/rss/companies-101.rss', 80, 'companies'),
    ('Mint RSS',             'https://www.livemint.com/rss/markets',    80, 'markets'),
    ('BusinessLine RSS',     'https://www.thehindubusinessline.com/feeder/default.rss', 80, 'markets'),
    ('Trade Brains RSS',     'https://tradebrains.in/feed/', 65, 'analysis'),
    ('Investing Global News','https://www.investing.com/rss/news.rss', 70, 'global'),
]

DISABLED_OLD_MONEYCONTROL = {
    'Moneycontrol Top News', 'Moneycontrol Business',
    'Moneycontrol HTML Index', 'Moneycontrol News Sitemap',
}
DISABLED_BAD_FEEDS: set = set()


def _ensure_sqlite_columns() -> None:
    if not str(engine.url).startswith('sqlite'):
        return
    with engine.begin() as conn:
        cols = {row[1] for row in conn.exec_driver_sql('PRAGMA table_info(rss_sources)').fetchall()}
        additions = {
            'interval_seconds': 'INTEGER DEFAULT 60',
            'next_run_at': 'DATETIME', 'last_checked_at': 'DATETIME',
            'last_success_at': 'DATETIME', 'last_error_at': 'DATETIME',
            'last_error': 'TEXT', 'consecutive_failures': 'INTEGER DEFAULT 0',
            'status': "VARCHAR(40) DEFAULT 'healthy'",
            'source_type': "VARCHAR(40) DEFAULT 'rss'",
            'allowed_patterns': 'JSON', 'blocked_patterns': 'JSON',
            'article_limit': 'INTEGER DEFAULT 50', 'polite_delay_ms': 'INTEGER DEFAULT 500',
        }
        for col, ddl in additions.items():
            if col not in cols:
                conn.exec_driver_sql(f'ALTER TABLE rss_sources ADD COLUMN {col} {ddl}')


def _upsert_source(db, payload, enabled=True, status='healthy'):
    existing = db.query(RSSSource).filter(RSSSource.name == payload['name']).first()
    if not existing:
        db.add(RSSSource(**payload, enabled=enabled, status=status))
        return
    for k, v in payload.items():
        setattr(existing, k, v)
    existing.enabled = enabled
    existing.status  = status
    existing.interval_seconds = payload.get('interval_seconds', settings.ingestion_interval_seconds)
    if enabled and status == 'healthy':
        existing.last_error = None
        existing.consecutive_failures = 0


def _upsert_stock(db, stock):
    existing = db.query(StockUniverse).filter(StockUniverse.symbol == stock['symbol']).first()
    if not existing:
        db.add(StockUniverse(
            symbol=stock['symbol'], name=stock['name'],
            sector=stock.get('sector'), industry=stock.get('industry'),
            indices=stock.get('indices', []), importance=stock.get('importance', 50),
            enabled=True,
        ))
    else:
        existing.name = stock['name']
        existing.sector = stock.get('sector', existing.sector)
        existing.industry = stock.get('industry', existing.industry)
        existing.indices = stock.get('indices', existing.indices)
        existing.importance = stock.get('importance', existing.importance)
        existing.enabled = True


def main():
    Base.metadata.create_all(bind=engine)
    _ensure_sqlite_columns()

    with SessionLocal() as db:
        for name, url, cred, cat in RSS:
            payload = {
                'name': name, 'url': url, 'credibility': cred, 'category': cat,
                'interval_seconds': settings.ingestion_interval_seconds,
                'source_type': 'rss', 'allowed_patterns': [], 'blocked_patterns': [],
                'article_limit': 500, 'polite_delay_ms': 250,
            }
            enabled = name not in DISABLED_BAD_FEEDS
            _upsert_source(db, payload, enabled=enabled, status='healthy' if enabled else 'disabled')

        mc = {
            'name': 'Moneycontrol Selenium News',
            'url': 'https://www.moneycontrol.com/news/index-sitemap-2026.xml',
            'credibility': 84, 'category': 'markets',
            'interval_seconds': settings.ingestion_interval_seconds,
            'source_type': 'selenium_sitemap_index', 'article_limit': 500,
            'polite_delay_ms': 100,
            'allowed_patterns': ['/news/business/', '/news/business/markets/',
                                  '/news/business/companies/', '/news/business/ipo/',
                                  '/news/business/commodities/', '/news/business/earnings/'],
            'blocked_patterns': ['/lifestyle/', '/sports/', '/entertainment/',
                                   '/india/', '/world/', '/technology/'],
        }
        _upsert_source(db, mc, enabled=True, status='healthy')

        for legacy in DISABLED_OLD_MONEYCONTROL:
            row = db.query(RSSSource).filter(RSSSource.name == legacy).first()
            if row:
                row.enabled = False
                row.status = 'disabled'

        for stock in NIFTY_250:
            _upsert_stock(db, stock)

        db.commit()

        try:
            invalidate_api_cache()
            cache_delete_pattern('last:*')
            cache_delete_pattern('quote:*')
            cache_delete_pattern('signal:*')
        except Exception:
            pass

        rss_count   = db.query(RSSSource).filter(RSSSource.enabled == True).count()
        stock_count = db.query(StockUniverse).filter(StockUniverse.enabled == True).count()
        print(f'\nDatabase initialised.\n'
              f'  RSS sources enabled: {rss_count} (incl. CNBC TV18, NDTV Profit, Zee Business)\n'
              f'  Stocks in universe:  {stock_count} (Nifty 250)\n'
              f'  DB path:             {settings.database_url}')


if __name__ == '__main__':
    main()
