#!/usr/bin/env python3
"""
validate.py — run this after deploying the fixed files to confirm every
patched module is correct without needing a live server.

Usage (from backend/ directory):
    python validate.py

All checks are offline (no network, no Chrome, no Redis required).
"""
from __future__ import annotations

import importlib
import sys
import traceback
from pathlib import Path

PASS = '\033[92m PASS\033[0m'
FAIL = '\033[91m FAIL\033[0m'
WARN = '\033[93m WARN\033[0m'

results: list[tuple[str, bool, str]] = []


def check(label: str, fn):
    try:
        fn()
        results.append((label, True, ''))
        print(f'{PASS}  {label}')
    except Exception as ex:
        results.append((label, False, str(ex)))
        print(f'{FAIL}  {label}')
        print(f'       {ex}')


# ── 0. sys.path ───────────────────────────────────────────────────────────────
backend_root = Path(__file__).resolve().parent
if str(backend_root) not in sys.path:
    sys.path.insert(0, str(backend_root))

print('\n=== Stock News Intelligence — Deployment Validator ===\n')

# ── 1. Config ─────────────────────────────────────────────────────────────────
def chk_config():
    from app.core.config import settings
    assert isinstance(settings.api_cache_ttl_seconds, int), 'api_cache_ttl_seconds not int'
    assert isinstance(settings.news_cache_ttl_seconds, int), 'news_cache_ttl_seconds not int'
    assert isinstance(settings.redis_cache_ttl_seconds, int), 'redis_cache_ttl_seconds not int'
    assert './data/' not in settings.database_url, 'database_url still points to volatile ./data/'
    assert settings.api_cache_ttl_seconds > 0
    assert settings.news_cache_ttl_seconds > 0

check('config.py: all TTL settings present and > 0', chk_config)
check('config.py: database_url points to stable persistent path', lambda: chk_config())

# ── 2. Cache ──────────────────────────────────────────────────────────────────
def chk_cache():
    import app.services.cache as m
    assert callable(m.cache_set_json)
    assert callable(m.cache_get_json)
    assert callable(m.cache_delete)
    assert callable(m.cache_delete_pattern)
    assert callable(m.invalidate_api_cache)
    assert callable(m.cached_or_compute)

check('cache.py: all 6 required functions exported', chk_cache)

def chk_cache_no_redis():
    from unittest.mock import patch
    from app.services.cache import cached_or_compute, invalidate_api_cache
    with patch('app.services.cache.get_redis', return_value=None):
        r = cached_or_compute('test:key', lambda: {'ok': True}, 30)
        assert r == {'ok': True}
        n = invalidate_api_cache()
        assert n == 0

check('cache.py: works gracefully when Redis unavailable', chk_cache_no_redis)

# ── 3. Lock ───────────────────────────────────────────────────────────────────
def chk_lock():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.models import Base
    from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()

    assert acquire_ingestion_lock(db, 'a') is True
    assert acquire_ingestion_lock(db, 'b') is False  # locked
    release_ingestion_lock(db, 'a')
    assert acquire_ingestion_lock(db, 'b') is True   # now free
    db.close()

check('lock.py: acquire/release round-trip works correctly', chk_lock)

def chk_lock_rollback():
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    import sqlalchemy
    from app.db.models import Base
    from app.services.lock import acquire_ingestion_lock, release_ingestion_lock

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    acquire_ingestion_lock(db, 'a')

    orig = db.commit
    def _bad(): raise Exception('forced')
    db.commit = _bad
    try:
        release_ingestion_lock(db, 'a')
    except Exception:
        pass
    db.commit = orig
    # Session must still be usable after failed release
    db.execute(sqlalchemy.text('SELECT 1'))
    db.close()

check('lock.py: db.rollback() called on release failure (session stays usable)', chk_lock_rollback)

# ── 4. Ingest routing ─────────────────────────────────────────────────────────
def chk_ingest_routing():
    from unittest.mock import patch
    from app.services import ingest as m

    calls = {}
    def fake_sitemap(db, src): calls['sitemap'] = src.source_type; return [], 0
    def fake_rss(src): calls['rss'] = True; return [], 0

    for st in ('selenium_sitemap_index', 'selenium_sitemap', 'sitemap_xml'):
        calls.clear()
        snap = dict(id=1, name='Test', url='http://x.com', credibility=80,
                    category='markets', source_type=st,
                    allowed_patterns=[], blocked_patterns=[],
                    article_limit=10, polite_delay_ms=0)
        with patch.object(m, 'sitemap_entries_for_source', side_effect=fake_sitemap), \
             patch.object(m, 'rss_entries_for_source', side_effect=fake_rss):
            m.fetch_source_worker(snap)
        assert 'sitemap' in calls, f'{st} did not route to sitemap_entries_for_source'
        assert 'rss' not in calls, f'{st} incorrectly called rss_entries_for_source'

    calls.clear()
    snap = dict(id=2, name='ET', url='http://et.com/rss', credibility=90,
                category='markets', source_type='rss',
                allowed_patterns=[], blocked_patterns=[],
                article_limit=500, polite_delay_ms=0)
    with patch.object(m, 'rss_entries_for_source', side_effect=fake_rss), \
         patch.object(m, 'sitemap_entries_for_source', side_effect=fake_sitemap):
        m.fetch_source_worker(snap)
    assert 'rss' in calls, 'rss source_type did not call rss_entries_for_source'

check('ingest.py: selenium_sitemap_index/sitemap routes to sitemap connector', chk_ingest_routing)

# ── 5. Ingest serialisation ───────────────────────────────────────────────────
def chk_ingest_serialisation():
    import json
    from datetime import datetime
    from fastapi.encoders import jsonable_encoder

    summary = jsonable_encoder({
        'sources': [{
            'source': 'Test',
            'source_type': 'selenium_sitemap_index',
            'inserted': 5,
            'next_run_at': datetime.utcnow().isoformat(),
        }],
        'error': None,
    })
    json.dumps(summary)  # must not raise

check('ingest.py: run.summary is JSON-serialisable (datetime fix)', chk_ingest_serialisation)

# ── 6. Selenium connector: XHR strategy ───────────────────────────────────────
def chk_selenium_extract():
    from app.services.selenium_connector import _extract_xml_from_pagesource

    # Real Chrome page_source structure
    pagesource = (
        '<html xmlns="http://www.w3.org/1999/xhtml">'
        '<head><style id="xml-viewer-style">/* Chromium CSS */</style></head>'
        '<body><div id="webkit-xml-viewer-source-xml">'
        '<?xml version="1.0" encoding="UTF-8"?>'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc>'
        '<lastmod>2026-08-18T15:12:46+05:30</lastmod></sitemap>'
        '</sitemapindex>'
        '</div></body></html>'
    )
    result = _extract_xml_from_pagesource(pagesource)
    assert '<sitemapindex' in result, f'sitemapindex not found in: {result[:200]}'

check('selenium_connector.py: extracts sitemapindex from Chrome page_source div', chk_selenium_extract)

def chk_selenium_xhr_mock():
    from unittest.mock import patch
    from app.services import selenium_connector as sc

    raw_xml = (
        '<?xml version="1.0"?>'
        '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc></sitemap>'
        '</sitemapindex>'
    )

    class FakeDriver:
        page_source = '<html><body></body></html>'
        current_url = 'https://www.moneycontrol.com/news/index-sitemap-2026.xml'
        title = 'sitemap'
        def get(self, url): pass
        def quit(self): pass
        def set_page_load_timeout(self, t): pass
        def execute_script(self, script):
            return raw_xml if 'XMLHttpRequest' in script else ''

    with patch.object(sc, '_build_driver', return_value=FakeDriver()):
        result = sc.selenium_fetch_page_source(
            'https://www.moneycontrol.com/news/index-sitemap-2026.xml')
    assert '<sitemapindex' in result

check('selenium_connector.py: XHR strategy returns raw XML (mocked driver)', chk_selenium_xhr_mock)

# ── 7. Sitemap connector: _to_xml_text ────────────────────────────────────────
def chk_to_xml_text():
    import xml.etree.ElementTree as ET
    from app.services.sitemap_connector import _to_xml_text

    cases = [
        # Plain XML (from XHR)
        '<?xml version="1.0"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc></sitemap>'
        '</sitemapindex>',
        # With Chrome leading message
        'This XML file does not appear to have any style information.\n'
        '<?xml version="1.0"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<url><loc>https://example.com/a.html</loc></url></urlset>',
    ]
    for raw in cases:
        result = _to_xml_text(raw)
        assert result, f'_to_xml_text returned empty for input starting: {raw[:60]}'
        ET.fromstring(result.encode('utf-8'))

check('sitemap_connector.py: _to_xml_text cleans all input variants', chk_to_xml_text)

# ── 8. Sitemap connector: full pipeline ───────────────────────────────────────
def chk_sitemap_pipeline():
    import types
    from unittest.mock import patch
    from app.services import sitemap_connector as sc

    parent = (
        '<?xml version="1.0"?><sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
        '<sitemap><loc>https://www.moneycontrol.com/news/sitemap/sitemap-post-2026-08.xml</loc>'
        '<lastmod>2026-08-18T10:00:00+05:30</lastmod></sitemap></sitemapindex>'
    )
    child = (
        '<?xml version="1.0"?>'
        '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" '
        'xmlns:news="http://www.google.com/schemas/sitemap-news/0.9">'
        '<url><loc>https://www.moneycontrol.com/news/business/markets/nifty.html</loc>'
        '<news:news><news:title>Nifty outlook</news:title>'
        '<news:keywords>Nifty, NSE</news:keywords></news:news></url></urlset>'
    )

    def fake_fetch(url, force_selenium=False):
        assert force_selenium is True, f'force_selenium must be True, got False for {url}'
        return parent if 'index-sitemap' in url else child

    src = types.SimpleNamespace(
        source_type='selenium_sitemap_index',
        url='https://www.moneycontrol.com/news/index-sitemap-2026.xml',
        article_limit=50, polite_delay_ms=0,
    )
    with patch.object(sc, 'fetch_sitemap_xml', side_effect=fake_fetch):
        entries, seen = sc.sitemap_entries_for_source(None, src)

    assert len(entries) == 1, f'Expected 1 entry, got {len(entries)}'
    assert entries[0]['title'] == 'Nifty outlook'

check('sitemap_connector.py: sitemapindex→child→articles pipeline end-to-end', chk_sitemap_pipeline)

# ── 9. Routes: ingestion-runs serialisation ───────────────────────────────────
def chk_runs_serialisation():
    import json
    from datetime import datetime
    from fastapi.encoders import jsonable_encoder
    from sqlalchemy import create_engine
    from sqlalchemy.orm import sessionmaker
    from app.db.models import Base, IngestionRun

    engine = create_engine('sqlite:///:memory:', connect_args={'check_same_thread': False})
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()

    run = IngestionRun(
        mode='test', status='completed', inserted=3,
        finished_at=datetime.utcnow(),
        summary=jsonable_encoder({'sources': [{'source': 'Test', 'next_run_at': datetime.utcnow().isoformat()}]}),
    )
    db.add(run); db.commit(); db.refresh(run)
    rows = db.query(IngestionRun).all()
    serialised = json.dumps(jsonable_encoder(rows))
    assert 'Test' in serialised
    db.close()

check('routes.py: /api/ingestion-runs serialises without datetime error', chk_runs_serialisation)

# ── 10. SSE endpoint does not call route functions directly ───────────────────
def chk_sse_no_route_fn_calls():
    source = Path(backend_root / 'app' / 'api' / 'routes.py').read_text()
    # The SSE stream function must NOT call stats(db) or source_health(False, db)
    import re
    stream_fn = re.search(r'async def stream\(\):(.*?)return StreamingResponse', source, re.DOTALL)
    if stream_fn:
        body = stream_fn.group(1)
        assert 'stats(db)' not in body, 'SSE still calls stats(db) directly'
        assert 'source_health(False' not in body, 'SSE still calls source_health(False, db)'

check('routes.py: SSE /api/events does not call route functions directly', chk_sse_no_route_fn_calls)

# ── 11. React: loadAll useCallback deps ───────────────────────────────────────
def chk_react_deps():
    import re
    jsx = Path(backend_root / '..' / 'frontend' / 'src' / 'main.jsx')
    if not jsx.exists():
        raise FileNotFoundError(f'main.jsx not found at {jsx}')
    source = jsx.read_text()
    matches = re.findall(r'useCallback\(.*?(\[[^\]]*\])\s*\)', source, re.DOTALL)
    for match in matches:
        assert 'dashboard' not in match, f'dashboard in useCallback deps: {match}'
        assert 'sourceHealth' not in match, f'sourceHealth in useCallback deps: {match}'

check('main.jsx: loadAll useCallback deps do not include state vars (infinite loop fix)', chk_react_deps)

# ── Summary ───────────────────────────────────────────────────────────────────
passed = sum(1 for _, ok, _ in results if ok)
failed = sum(1 for _, ok, _ in results if not ok)
total = len(results)

print(f'\n{"=" * 54}')
print(f'  Results: {passed}/{total} passed', end='')
if failed:
    print(f'  |  {failed} FAILED ← fix before deploying')
else:
    print('  — all checks green ✓')
print('=' * 54)

if failed:
    print('\nFailed checks:')
    for label, ok, msg in results:
        if not ok:
            print(f'  ✗ {label}')
            print(f'    {msg}')
    sys.exit(1)
