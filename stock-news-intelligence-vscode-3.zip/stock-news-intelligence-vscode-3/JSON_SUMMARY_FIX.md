# JSON Summary Fix

## Fixed error

`Object of type datetime is not JSON serializable` occurred because `ingestion_runs.summary` is a JSON column and the summary payload contained Python `datetime` objects such as `next_run_at`.

## Fix

- `backend/app/services/ingest.py` now wraps run summaries with `jsonable_encoder()` before saving to the JSON column.
- Ingestion API routes now rollback the SQLAlchemy session on failure before releasing the ingestion lock.
- Ingestion API responses are also encoded with `jsonable_encoder()`.

## Required after applying

Restart backend. If a failed transaction left the app stuck, stop backend and start again.

```powershell
cd backend
python -m app.db.init_db
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

Then test:

```powershell
curl -X POST http://127.0.0.1:8000/api/admin/ingest
curl http://127.0.0.1:8000/api/ingestion-runs
```
