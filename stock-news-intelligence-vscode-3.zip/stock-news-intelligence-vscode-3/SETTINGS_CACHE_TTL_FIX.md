# Settings TTL Fallback Fix

## Fixed error

`AttributeError: 'Settings' object has no attribute 'api_cache_ttl_seconds'`

This happened because `routes.py` used Redis API cache TTL fields but the local `core/config.py` was still old.

## Fix

- `routes.py` now uses safe fallbacks with `getattr()`.
- `core/config.py` includes `api_cache_ttl_seconds`, `news_cache_ttl_seconds`, `ingestion_worker_count`, and `use_redis_cache`.

## Run

```powershell
cd backend
python -m app.db.init_db
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```
